import React, { useState } from 'react';
import {
  Search,
  Plus,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Eye,
  Columns,
  Settings,
  HelpCircle,
  Mail,
  Calendar as CalendarIcon,
  Users,
  CalendarCheck,
  HardDrive,
  CheckSquare,
  Sparkles,
  PenTool,
  LayoutTemplate,
  FileSpreadsheet,
  Compass,
  FlaskConical,
  FolderPlus,
  UserPlus,
  Check,
  X,
  Send,
  Trash2,
  Reply,
  Forward,
  Star,
  Maximize2,
  Minimize2,
  Paperclip,
  CheckCircle2,
  Clock,
  ExternalLink,
  Archive,
  RefreshCw,
  Folder,
  Tag,
  AlertCircle,
  Printer,
  MoreVertical,
  Download,
  FileText,
  Copy,
  Moon,
  Sun,
  Bug,
  Filter,
  Menu,
} from 'lucide-react';

export interface TitanEmailItem {
  id: string;
  sender: string;
  subject: string;
  snippet: string;
  date: string;
  unread: boolean;
  category: 'priority' | 'other';
  selected?: boolean;
  avatarBg?: string;
  body?: string;
  starred?: boolean;
}

interface CalendarEvent {
  id: string;
  title: string;
  timeSlot: string;
  color: string;
}

export const FunctionalTitanEmailDashboard: React.FC = () => {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<'priority' | 'other'>('other');
  const [activeApp, setActiveApp] = useState<'mail' | 'calendar' | 'contacts' | 'bookings' | 'drive' | 'tasks'>('mail');
  const [rightPanelTab, setRightPanelTab] = useState<'calendar' | 'tasks'>('calendar');
  const [showRightPanel, setShowRightPanel] = useState(false); // Collapsed by default for clean horizontal fit
  const [desktopSidebarOpen, setDesktopSidebarOpen] = useState(true); // Desktop toggle for left sidebar
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false); // Mobile drawer for left sidebar
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [activeFolder, setActiveFolder] = useState<string>('inbox');
  const [filterType, setFilterType] = useState<'all' | 'unread' | 'starred'>('all');
  const [showFilterDropdown, setShowFilterDropdown] = useState(false);

  // Search input
  const [searchQuery, setSearchQuery] = useState('');

  // Split view mode: 'list' (full list) or 'split' (master-detail side by side on desktop)
  const [isSplitView, setIsSplitView] = useState(false);

  // Compose Modal State
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [composeTo, setComposeTo] = useState('');
  const [composeSubject, setComposeSubject] = useState('');
  const [composeBody, setComposeBody] = useState('');
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [aiTone, setAiTone] = useState<'professional' | 'polite' | 'sales' | 'urgent'>('professional');

  // Tool Dialog state
  const [activeToolModal, setActiveToolModal] = useState<'signature' | 'invoice' | 'settings' | 'help' | 'newFolder' | 'newAccount' | null>(null);
  const [newFolderName, setNewFolderName] = useState('');
  const [newAccountEmail, setNewAccountEmail] = useState('');

  // Selected email for reading view
  const [readingEmail, setReadingEmail] = useState<TitanEmailItem | null>(null);

  // Toast feedback
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  // Custom User Folders
  const [customFolders, setCustomFolders] = useState<string[]>(['Client Invoices', 'Server Alerts']);

  // Interactive Tasks list for right panel
  const [taskList, setTaskList] = useState([
    { id: 't1', text: 'Approve DLT header for Titan Mail', done: true },
    { id: 't2', text: 'Verify SPF, DKIM and DMARC DNS records', done: true },
    { id: 't3', text: 'Onboard 10 founding team mailboxes', done: false },
    { id: 't4', text: 'Send Q4 Client Enterprise Proposal', done: false },
    { id: 't5', text: 'Review Titan Drive storage quotas', done: false },
  ]);
  const [newTaskInput, setNewTaskInput] = useState('');

  // Calendar Scheduled Events
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([
    { id: 'e1', title: 'DLT Header Sync & Telecom Review', timeSlot: '10 AM', color: 'bg-blue-100 text-blue-800 border-blue-300' },
    { id: 'e2', title: 'Team DevOps Standup', timeSlot: '2 PM', color: 'bg-emerald-100 text-emerald-800 border-emerald-300' },
  ]);
  const [newEventModal, setNewEventModal] = useState<{ open: boolean; slot: string }>({ open: false, slot: '' });
  const [newEventTitle, setNewEventTitle] = useState('');

  // RANDOM DIVERSE PROFESSIONAL BUSINESS EMAILS
  const [emails, setEmails] = useState<TitanEmailItem[]>([
    {
      id: 'em-1',
      sender: 'Priya Sharma (Acme Global)',
      subject: 'Contract Proposal: Enterprise Cloud Migration for Q4',
      snippet: 'Hi Ishwar, attached is the revised proposal with the updated mailbox allocation and SLA terms for your team review...',
      date: '10:42 AM',
      unread: true,
      category: 'other',
      avatarBg: 'bg-indigo-600',
      body: 'Hi Ishwar,\n\nHope you are having a productive week. We have updated the Cloud Migration Proposal following our discussion yesterday.\n\nKey highlights in this version:\n• Dedicated migration window with zero email downtime\n• Auto-syncing of contacts, calendar items, and mailbox aliases\n• Custom DKIM, SPF, and DMARC enforcement for compliance\n\nPlease review the attached document and let us know if we can schedule the kickoff call for this Thursday.\n\nBest regards,\nPriya Sharma\nDirector of Enterprise Partnerships, Acme Global',
    },
    {
      id: 'em-2',
      sender: 'Stripe Payments',
      subject: 'Payout of $4,920.00 USD initiated to your bank account',
      snippet: 'Your scheduled payout has been processed and initiated. Funds are scheduled to arrive in 1-2 business days...',
      date: '9:15 AM',
      unread: true,
      category: 'other',
      avatarBg: 'bg-emerald-600',
      body: 'Stripe Billing Operations:\n\nYour automated payout of $4,920.00 USD has been initiated to your designated business bank account ending in **4128.\n\nPayout ID: po_1Oxf84Lkd83k\nEstimated Arrival: October 1, 2026\nNet Volume: $5,190.00 | Processing Fees: $270.00\n\nYou can view the full reconciliation breakdown and invoice items in your Stripe Dashboard.\n\nThank you for choosing Stripe.',
    },
    {
      id: 'em-3',
      sender: 'David Miller (Apex Cloud)',
      subject: 'Executed NDA & Master Services Agreement for 2026-2027',
      snippet: 'The legal team has countersigned the SLA agreement. All audit and security credentials have been archived...',
      date: '8:30 AM',
      unread: true,
      category: 'other',
      avatarBg: 'bg-blue-600',
      body: 'Hello Ishwar,\n\nWe are pleased to inform you that the Master Services Agreement (MSA) and Mutual Non-Disclosure Agreement (NDA) have been fully executed by our General Counsel.\n\nAttached:\n1. Apex_Cloud_Executed_MSA_2026.pdf\n2. Mutual_NDA_Executed.pdf\n\nLooking forward to a mutually fruitful partnership!\n\nDavid Miller\nVP Business Affairs, Apex Cloud Systems',
    },
    {
      id: 'em-4',
      sender: 'Cloudflare Security',
      subject: 'Universal SSL/TLS certificate auto-renewed for *.yourdomain.com',
      snippet: 'The edge certificate for your custom domains has been renewed automatically with zero downtime. All cipher suites verified...',
      date: 'Yesterday',
      unread: true,
      category: 'other',
      avatarBg: 'bg-orange-600',
      body: 'Cloudflare Edge Certificate Automation:\n\nDomain: *.yourdomain.com\nCertificate Type: Universal SSL (ECDSA + RSA 2048)\nValid Until: September 30, 2027\nDeployment Status: 100% Global Edge POP Distribution\n\nNo manual configuration required. Encrypted HTTPS and TLS 1.3 traffic will continue without disruption.',
    },
    {
      id: 'em-5',
      sender: 'Sophia Chen (Product Lead)',
      subject: 'New UX Prototypes ready: Business Webmail Client Portal v3',
      snippet: 'Hey team, please review the latest interactive Figma prototypes for the user settings and alias management flow...',
      date: 'Yesterday',
      unread: true,
      category: 'other',
      avatarBg: 'bg-pink-600',
      body: 'Hey Team,\n\nI have published the revised high-fidelity screens for the Business Email User Portal in Figma.\n\nWhat is new:\n1. Simplified 1-click DKIM record generation\n2. Streamlined mailbox alias assignment wizard\n3. Responsive laptop frame styling for hero showcase\n\nPlease test the interactive prototype link and leave your comments before the sprint planning tomorrow.\n\nCheers,\nSophia Chen',
    },
    {
      id: 'em-6',
      sender: 'GitHub Security Alerts',
      subject: '[Resolved] Dependabot patched 2 dependencies in main branch',
      snippet: 'Security advisory resolved in repository cloud-infra/email-gateway. Automated test suite passed with 100% coverage...',
      date: 'Sep 29',
      unread: false,
      category: 'other',
      avatarBg: 'bg-slate-900',
      body: 'GitHub Security Automation:\n\nRepository: cloud-infra/email-gateway\nFixed CVE: Dependabot advisory alert #49\nPull Request: #208 (Auto-merged)\nStatus: Build Passed & Deployed to Canary\n\nNo regressions or performance impacts detected.',
    },
    {
      id: 'em-7',
      sender: 'Dr. Marcus Vance (FinTech Labs)',
      subject: 'API integration performance report: 99.98% success rate',
      snippet: 'Weekly benchmark results are in. Latency on high-volume transactional relays clocked in at 14ms average...',
      date: 'Sep 29',
      unread: true,
      category: 'other',
      avatarBg: 'bg-purple-600',
      body: 'Dear Ishwar,\n\nOur DevOps team ran load simulations on the Titan high-speed SMTP relays this past weekend:\n\n• Total emails processed: 250,000\n• Delivery rate: 99.98%\n• Mean latency: 14.2ms\n• Zero bounce or spam flagging observed\n\nThe infrastructure is ready for full production rollout.\n\nWarm regards,\nDr. Marcus Vance\nLead Infrastructure Scientist, FinTech Labs',
    },
    {
      id: 'em-8',
      sender: 'Karan Malhotra (Nexus Digital)',
      subject: 'Payment Confirmation: Invoice #INV-2026-448 settled',
      snippet: 'Payment of ₹48,500 has been credited via NEFT/RTGS. Transaction Reference: UTR88492019482. Thank you...',
      date: 'Sep 28',
      unread: false,
      category: 'other',
      avatarBg: 'bg-teal-600',
      body: 'Hi Accounts Team,\n\nWe have initiated the bank transfer for Invoice #INV-2026-448 for our annual Business Email hosting package.\n\nPayment Details:\n• Amount: ₹48,500 INR\n• UTR Number: UTR88492019482\n• Bank: HDFC Bank Corporate\n• Invoice: #INV-2026-448\n\nPlease acknowledge receipt and issue the official tax invoice.\n\nThanks & regards,\nKaran Malhotra\nFinance Manager, Nexus Digital Pvt Ltd',
    },
    {
      id: 'em-9',
      sender: 'AWS Cloud Billing',
      subject: 'Monthly Cloud Infrastructure & Storage Statement (Sept 2026)',
      snippet: 'Your monthly billing invoice is ready for download. Total charges: $192.40 USD. Applied tier credits: $50.00...',
      date: 'Sep 28',
      unread: true,
      category: 'other',
      avatarBg: 'bg-amber-700',
      body: 'Amazon Web Services Invoice Notification:\n\nAccount: 4728-9205-0112\nBilling Period: September 1 - September 30, 2026\nTotal Amount: $192.40 USD\nPayment Method: Corporate Visa ending in **8920\n\nResource Summary:\n• Amazon SES Email Delivery: $24.10\n• Amazon S3 Encrypted Backups: $38.30\n• Amazon EC2 Edge Nodes: $130.00\n\nDetailed PDF statement attached.',
    },
    {
      id: 'em-10',
      sender: 'Linear App Team',
      subject: 'Sprint 42 closed: 26 user stories completed ahead of deadline',
      snippet: 'Sprint retrospective scheduled for tomorrow 2:00 PM. Team velocity reached an all-time high of 68 story points...',
      date: 'Sep 27',
      unread: false,
      category: 'other',
      avatarBg: 'bg-purple-700',
      body: 'Linear Sprint Retrospective:\n\nSprint 42: Mail Delivery Engine & Webmail UI\n• 26 issues completed\n• 4 issues moved to backlog\n• Velocity: 68 points (112% of forecast)\n\nTop Contributors: Ishwar Kumar, Sophia Chen, Marcus Vance\nCheck out the sprint burnup chart in Linear.',
    },
    {
      id: 'em-11',
      sender: 'Sarah Jenkins (Legal Counsel)',
      subject: 'Review requested: DLT Telecom Entity Agreement v2',
      snippet: 'Attached is the finalized compliance agreement for TRAI DLT registration and Principal Entity verification...',
      date: 'Sep 27',
      unread: false,
      category: 'other',
      avatarBg: 'bg-rose-600',
      body: 'Hi Ishwar,\n\nI have thoroughly reviewed the DLT Telecom Principal Entity agreement and verified that all clauses comply with TRAI regulations.\n\nAction required: Please add your digital signature on page 4 and return the signed PDF so we can file the compliance certificate.\n\nBest,\nSarah Jenkins\nLegal Counsel',
    },
    {
      id: 'em-12',
      sender: 'Slack Notifications',
      subject: 'Weekly workspace digest: 58 discussions across #devops and #sales',
      snippet: 'Catch up on highlights while you were away: New enterprise lead signed, DNS automation deployed, and team kudos...',
      date: 'Sep 26',
      unread: true,
      category: 'other',
      avatarBg: 'bg-emerald-600',
      body: 'Slack Weekly Digest for Gitysoft Team:\n\n• #sales: Closed 10-year enterprise email subscription with Apex Cloud\n• #devops: MX records propagation check time reduced to under 30 seconds\n• #product: New Titan AI writing assistant launched with 4 custom tone presets\n\nOpen Slack to view conversations.',
    },
    {
      id: 'em-13',
      sender: 'Vikram Joshi (Vertex Logistics)',
      subject: 'Request for Quotation: 100 Custom Domain Business Mailboxes',
      snippet: 'We are looking to transition our entire logistics and dispatch department from legacy webmail to Titan Business Email...',
      date: 'Sep 26',
      unread: false,
      category: 'other',
      avatarBg: 'bg-blue-700',
      body: 'Dear Sales Team,\n\nOur company Vertex Logistics operates across 18 regional hubs in India. We currently have 100 email accounts hosted on cPanel Roundcube and are suffering from frequent spam and quota issues.\n\nCould you please share a commercial quote for:\n1. 100 Titan Mailboxes (minimum 25GB per user)\n2. Domain-level spam filtering and TLS encryption\n3. 5-year and 10-year pricing plans\n\nLooking forward to your swift response.\n\nVikram Joshi\nHead of IT Infrastructure, Vertex Logistics',
    },
    {
      id: 'em-14',
      sender: 'DocuSign System',
      subject: 'Completed: Enterprise SLA Addendum signed by all parties',
      snippet: 'All required parties have completed signing "Enterprise_SLA_Addendum_2026.pdf". Download verified certificate...',
      date: 'Sep 25',
      unread: false,
      category: 'other',
      avatarBg: 'bg-amber-600',
      body: 'DocuSign Completion Notification:\n\nDocument: Enterprise_SLA_Addendum_2026.pdf\nSigners:\n• Ishwar Kumar (CTO, Gitysoft Technologies)\n• David Miller (VP Operations)\n\nAll signatures cryptographically verified with audit trail.\n\nDownload the completed document from DocuSign.',
    },
    {
      id: 'em-15',
      sender: 'Jessica Taylor (HR Director)',
      subject: 'Candidate shortlist: Senior Cloud & Email Infrastructure Architect',
      snippet: 'Hi Ishwar, we evaluated 24 applicants for the Cloud Architect role. Here are the top 3 candidates for technical rounds...',
      date: 'Sep 25',
      unread: false,
      category: 'other',
      avatarBg: 'bg-violet-600',
      body: 'Hi Ishwar,\n\nHere is the executive shortlist for the Senior Cloud & Email Architect position:\n\n1. Rahul Verma - 8 yrs exp (Ex-Rackspace, SMTP relay and Postfix specialist)\n2. Sneha Kapoor - 6 yrs exp (Kubernetes, AWS SES, Dovecot/IMAP)\n3. Amit Roy - 7 yrs exp (High-availability DNS, BIND, and cybersecurity)\n\nPlease review their resumes and let me know your availability for interviews this Friday.\n\nWarm regards,\nJessica Taylor',
    },
    {
      id: 'em-16',
      sender: 'Notion Notifications',
      subject: 'Alex tagged you in "2027 Infrastructure Roadmap & Scaling"',
      snippet: 'Alex Rivera commented: "@ishwar please check the multi-region failover diagram before tomorrow executive review..."',
      date: 'Sep 24',
      unread: false,
      category: 'other',
      avatarBg: 'bg-slate-800',
      body: 'Notion Workspace Notification:\n\nAlex Rivera mentioned you in "2027 Infrastructure Roadmap":\n\n"@ishwar I added the failover architecture for dual MX records across Mumbai and Singapore datacenters. Could you double-check the priority weights (MX 10 and MX 20)?"\n\nClick to view and reply in Notion.',
    },
    {
      id: 'em-17',
      sender: 'DigitalOcean Alerts',
      subject: 'Automated weekly snapshot verified for prod-mail-replica-01',
      snippet: 'Automated snapshot backup completed successfully. Checksum verified and replicated across 2 standby data zones...',
      date: 'Sep 24',
      unread: false,
      category: 'other',
      avatarBg: 'bg-sky-600',
      body: 'DigitalOcean Cloud Alert:\n\nDroplet: prod-mail-replica-01\nSnapshot: snapshot-weekly-2026-09-24\nSize: 38.6 GB\nStatus: 100% Completed & Verified\nRetention: 30 Days\n\nAll automated data integrity checks passed.',
    },
    {
      id: 'em-18',
      sender: 'Zoom Communications',
      subject: 'Cloud Recording ready: Architecture Review & DNS Migration Call',
      snippet: 'Your cloud meeting recording from September 24 is processed. View video, audio transcript, and AI summary points...',
      date: 'Sep 23',
      unread: false,
      category: 'other',
      avatarBg: 'bg-blue-500',
      body: 'Zoom Cloud Meeting Recording:\n\nTopic: Architecture Review & Enterprise DNS Migration\nHost: Ishwar Kumar\nDuration: 48 minutes\n\nAI Summary:\n• Reviewed seamless migration of 500 mailboxes without bounce errors\n• Outlined automated SPF & DKIM record verification tooling\n• Approved Q4 budget allocation for NVMe storage expansion\n\nWatch recording online with passcode: Titan2026!',
    },
    {
      id: 'em-19',
      sender: 'OpenAI Platform',
      subject: 'Monthly API Usage Summary & Smart Write token quota report',
      snippet: 'Your statement for September 2026 is ready. Total AI tokens processed: 3.4M with average latency of 240ms...',
      date: 'Sep 23',
      unread: false,
      category: 'other',
      avatarBg: 'bg-emerald-700',
      body: 'OpenAI Organization Statement:\n\nOrganization: Gitysoft Technologies\nActive Model: GPT-4o Mini & Embeddings\nTotal Tokens: 3,412,800\nUptime: 99.99%\nEstimated Spend: $28.40 USD\n\nSmart Write Assistant drafted 1,280 professional customer emails with a 94% acceptance rating.',
    },
    {
      id: 'em-20',
      sender: 'Postman Operations',
      subject: 'API Monitoring Suite: All 18 email endpoints healthy (avg 14ms)',
      snippet: 'Scheduled automated synthetic monitor completed across all global regions. Zero failures, 100% uptime recorded...',
      date: 'Sep 22',
      unread: false,
      category: 'other',
      avatarBg: 'bg-orange-500',
      body: 'Postman Monitor Report:\n\nCollection: Titan Mail Gateway API\nMonitored Endpoints: 18\nPass Rate: 100%\nP95 Latency: 16.8ms\nRegions: US-East, EU-Central, AP-South (Mumbai)\n\nAll health probes returned HTTP 200 OK.',
    },
    // Priority Tab items
    {
      id: 'em-21',
      sender: 'Kabir Mehta (CEO Office)',
      subject: 'URGENT: Board of Directors Q4 Strategy Deck Review',
      snippet: 'Please review the slide deck before 4:00 PM today. We need the final numbers for enterprise email recurring revenue...',
      date: '10:45 AM',
      unread: true,
      category: 'priority',
      avatarBg: 'bg-rose-700',
      body: 'Ishwar,\n\nThe Board of Directors meeting is scheduled for tomorrow at 10 AM. We need to finalize the Q4 expansion strategy deck by 4:00 PM today.\n\nCould you please review slides 12 to 16 covering:\n1. 10-Year Business Email subscriber retention rates\n2. Average Mailbox storage consumption across enterprise tiers\n3. Projected revenue from the new DLT and AI writing add-ons\n\nLet us connect for a brief 10-minute sync at 3:30 PM.\n\nBest,\nKabir Mehta\nChief Executive Officer',
    },
    {
      id: 'em-22',
      sender: 'Stripe Enterprise',
      subject: 'High-Value Client Wire Transfer Confirmed ($35,000 USD)',
      snippet: 'Client Apex Global Systems has completed an international wire transfer for a 10-year enterprise contract...',
      date: '10:15 AM',
      unread: true,
      category: 'priority',
      avatarBg: 'bg-emerald-700',
      body: 'Stripe Enterprise Treasury Alert:\n\nTransaction ID: wire_8829410948\nAmount: $35,000.00 USD\nOriginating Bank: JPMorgan Chase NY\nCustomer: Apex Global Systems\nTerm: 10-Year Enterprise Titan Email Subscription (100 Mailboxes)\n\nFunds have cleared and been credited to your settlement account.',
    },
    {
      id: 'em-23',
      sender: 'Titan Security NOC',
      subject: '[Priority 1] Spam heuristics v4.4 active - zero phishing leaks',
      snippet: 'Real-time AI heuristics have blocked 2,400+ malicious links today. Spam false-positive rate under 0.001%...',
      date: '9:00 AM',
      unread: true,
      category: 'priority',
      avatarBg: 'bg-[#0c66e4]',
      body: 'Titan Network Operations Center (NOC):\n\nFilter Engine: NeuralSpam Heuristics v4.4\nStatus: Active & Operational across all MX clusters\nBlocked Malicious Links: 2,410\nZero-Day Phishing Detections: 18\nInbox False-Positive Rate: 0.0008%\n\nAll customer mailboxes are safeguarded with enterprise-grade threat intelligence.',
    },
    {
      id: 'em-24',
      sender: 'Ananya Singhal (Enterprise Client)',
      subject: 'Immediate approval for 5-Year Business Email contract renewal',
      snippet: 'Our executive board has signed off on the 5-year renewal. Thank you for the impeccable 99.99% uptime over the past year...',
      date: '8:45 AM',
      unread: true,
      category: 'priority',
      avatarBg: 'bg-purple-700',
      body: 'Dear Ishwar & Team,\n\nOn behalf of our executive board at Singhal Global Enterprises, I am delighted to share that we have officially approved the 5-year renewal for our 75 business mailboxes.\n\nThe uptime, speed, and mobile responsiveness of the Titan Webmail interface have transformed our team communication.\n\nPlease send across the countersigned invoice so our accounts department can release the advance payment.\n\nWarm regards,\nAnanya Singhal\nChief Operating Officer, Singhal Global Enterprises',
    },
  ]);

  // Filtering emails by search, active category tab, and filter type
  const filteredEmails = emails.filter((em) => {
    const matchesTab = em.category === activeTab;
    const matchesSearch =
      em.sender.toLowerCase().includes(searchQuery.toLowerCase()) ||
      em.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      em.snippet.toLowerCase().includes(searchQuery.toLowerCase());

    let matchesFilter = true;
    if (filterType === 'unread') matchesFilter = em.unread;
    if (filterType === 'starred') matchesFilter = Boolean(em.starred);

    return matchesTab && matchesSearch && matchesFilter;
  });

  const handleToggleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    const isChecked = e.target.checked;
    setEmails((prev) =>
      prev.map((em) => (em.category === activeTab ? { ...em, selected: isChecked } : em))
    );
  };

  const handleToggleEmailCheck = (id: string) => {
    setEmails((prev) =>
      prev.map((em) => (em.id === id ? { ...em, selected: !em.selected } : em))
    );
  };

  const handleToggleStar = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEmails((prev) =>
      prev.map((em) => (em.id === id ? { ...em, starred: !em.starred } : em))
    );
    showToast('Updated Star status');
  };

  const handleDeleteSelected = () => {
    const count = emails.filter((e) => e.selected).length;
    if (count === 0) return;
    setEmails((prev) => prev.filter((e) => !e.selected));
    if (readingEmail && readingEmail.selected) setReadingEmail(null);
    showToast(`✓ ${count} email(s) moved to Trash.`);
  };

  const handleMarkAsRead = () => {
    setEmails((prev) =>
      prev.map((em) => (em.selected ? { ...em, unread: false, selected: false } : em))
    );
    showToast('✓ Selected emails marked as read.');
  };

  const handleMarkAsUnread = () => {
    setEmails((prev) =>
      prev.map((em) => (em.selected ? { ...em, unread: true, selected: false } : em))
    );
    showToast('✓ Selected emails marked as unread.');
  };

  const handleGenerateSmartAi = () => {
    setIsAiGenerating(true);
    setTimeout(() => {
      let generatedDraft = '';
      if (aiTone === 'professional') {
        generatedDraft = `Dear Team,\n\nI hope this email finds you well.\n\nFollowing up on our cloud infrastructure & Titan business email migration, all DNS records (MX, SPF, DKIM, and DMARC) have been successfully verified with a 99.9% uptime SLA.\n\nPlease let us know if your team requires additional mailbox aliases or Titan Drive cloud storage upgrades.\n\nBest regards,\nExecutive Business Communications\nGitysoft Technologies`;
      } else if (aiTone === 'sales') {
        generatedDraft = `Hi there,\n\nAre you looking to eliminate spam and elevate your brand credibility? With Gitysoft Titan Business Email, you get custom domain inboxes, Smart Write AI, and unlimited read receipts starting at just ₹299/year (Save up to 25% with our 10-year plan).\n\nCan we set up a quick 10-minute demo this Thursday?\n\nWarm regards,\nGitysoft Enterprise Sales`;
      } else if (aiTone === 'urgent') {
        generatedDraft = `URGENT NOTICE:\n\nPlease be advised that our secondary support channel is currently live. All ongoing services, IMAP sync, and SMTP relays remain at 100% operational capacity.\n\nKindly acknowledge receipt of this message.\n\nInfrastructure NOC Team`;
      } else {
        generatedDraft = `Hello,\n\nThank you for reaching out to us. We truly appreciate your inquiry and are happy to assist you with configuring your business mailboxes.\n\nPlease find the attached setup guide for Outlook and Android.\n\nWarmest regards,\nCustomer Success Team`;
      }

      setComposeBody(generatedDraft);
      setIsAiGenerating(false);
      showToast(`⚡ Smart Write AI generated a ${aiTone} email draft!`);
    }, 700);
  };

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!composeTo.trim()) return;

    const newEmail: TitanEmailItem = {
      id: `em-${Date.now()}`,
      sender: 'You (admin@yourbrand.com)',
      subject: composeSubject || '(No Subject)',
      snippet: composeBody.slice(0, 85) + '...',
      date: 'Just now',
      unread: false,
      category: activeTab,
      avatarBg: 'bg-emerald-600',
      body: composeBody,
    };

    setEmails([newEmail, ...emails]);
    setIsComposeOpen(false);
    setComposeTo('');
    setComposeSubject('');
    setComposeBody('');
    showToast(`✓ Email successfully sent to ${composeTo} via High-Speed SMTP!`);
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskInput.trim()) return;
    setTaskList([...taskList, { id: `t_${Date.now()}`, text: newTaskInput.trim(), done: false }]);
    setNewTaskInput('');
    showToast('Task added to Titan Calendar/Tasks');
  };

  const toggleTask = (id: string) => {
    setTaskList((prev) =>
      prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t))
    );
  };

  const handleCreateCalendarEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitle.trim()) return;
    const newEv: CalendarEvent = {
      id: `ev-${Date.now()}`,
      title: newEventTitle.trim(),
      timeSlot: newEventModal.slot,
      color: 'bg-blue-100 text-blue-800 border-blue-300',
    };
    setCalendarEvents([...calendarEvents, newEv]);
    setNewEventModal({ open: false, slot: '' });
    setNewEventTitle('');
    showToast(`✓ Meeting "${newEv.title}" scheduled at ${newEv.timeSlot}!`);
  };

  const selectedCount = emails.filter((e) => e.selected).length;
  const unreadCount = emails.filter((e) => e.unread && e.category === activeTab).length;

  // Reusable Sidebar content component
  const renderSidebarContent = () => (
    <div className="flex flex-col justify-between h-full p-2 sm:p-2.5 text-xs select-none">
      <div className="space-y-3">
        {/* 6 App Tiles (3 Columns x 2 Rows) */}
        <div className="grid grid-cols-3 gap-1 pb-2 border-b border-slate-100">
          {/* Mail */}
          <button
            onClick={() => {
              setActiveApp('mail');
              setReadingEmail(null);
              setMobileSidebarOpen(false);
            }}
            className={`flex flex-col items-center justify-center p-1 rounded-xl transition-all cursor-pointer ${
              activeApp === 'mail'
                ? 'bg-blue-50 text-[#0c66e4] font-black shadow-xs ring-1 ring-blue-200'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="w-5 h-5 rounded-lg bg-blue-100 text-[#0c66e4] flex items-center justify-center mb-0.5">
              <Mail className="w-3 h-3" />
            </div>
            <span className="text-[9px] font-bold">Mail</span>
          </button>

          {/* Calendar */}
          <button
            onClick={() => {
              setActiveApp('calendar');
              setShowRightPanel(true);
              setRightPanelTab('calendar');
              setMobileSidebarOpen(false);
            }}
            className={`flex flex-col items-center justify-center p-1 rounded-xl transition-all cursor-pointer ${
              activeApp === 'calendar'
                ? 'bg-amber-50 text-amber-700 font-black ring-1 ring-amber-200'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="w-5 h-5 rounded-lg bg-amber-100 text-amber-600 flex items-center justify-center mb-0.5 font-bold text-[9px]">
              1
            </div>
            <span className="text-[9px] font-bold">Calendar</span>
          </button>

          {/* Contacts */}
          <button
            onClick={() => {
              setActiveApp('contacts');
              showToast('Contacts Directory: 142 enterprise connections loaded');
              setMobileSidebarOpen(false);
            }}
            className={`flex flex-col items-center justify-center p-1 rounded-xl transition-all cursor-pointer ${
              activeApp === 'contacts'
                ? 'bg-purple-50 text-purple-700 font-black ring-1 ring-purple-200'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="w-5 h-5 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center mb-0.5">
              <Users className="w-3 h-3" />
            </div>
            <span className="text-[9px] font-bold">Contacts</span>
          </button>

          {/* Bookings */}
          <button
            onClick={() => {
              setActiveApp('bookings');
              showToast('Titan Bookings: 1-click meeting scheduling link active');
              setMobileSidebarOpen(false);
            }}
            className={`flex flex-col items-center justify-center p-1 rounded-xl transition-all cursor-pointer ${
              activeApp === 'bookings'
                ? 'bg-teal-50 text-teal-700 font-black ring-1 ring-teal-200'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="w-5 h-5 rounded-lg bg-teal-100 text-teal-600 flex items-center justify-center mb-0.5">
              <CalendarCheck className="w-3 h-3" />
            </div>
            <span className="text-[9px] font-bold">Bookings</span>
          </button>

          {/* Drive */}
          <button
            onClick={() => {
              setActiveApp('drive');
              showToast('Titan Drive: 50 GB Cloud Storage attached');
              setMobileSidebarOpen(false);
            }}
            className={`flex flex-col items-center justify-center p-1 rounded-xl transition-all cursor-pointer ${
              activeApp === 'drive'
                ? 'bg-emerald-50 text-emerald-700 font-black ring-1 ring-emerald-200'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="w-5 h-5 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center mb-0.5">
              <HardDrive className="w-3 h-3" />
            </div>
            <span className="text-[9px] font-bold">Drive</span>
          </button>

          {/* Tasks */}
          <button
            onClick={() => {
              setActiveApp('tasks');
              setShowRightPanel(true);
              setRightPanelTab('tasks');
              setMobileSidebarOpen(false);
            }}
            className={`flex flex-col items-center justify-center p-1 rounded-xl transition-all cursor-pointer ${
              activeApp === 'tasks'
                ? 'bg-orange-50 text-orange-700 font-black ring-1 ring-orange-200'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="w-5 h-5 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center mb-0.5">
              <CheckSquare className="w-3 h-3" />
            </div>
            <span className="text-[9px] font-bold">Tasks</span>
          </button>
        </div>

        {/* Feature Tools List */}
        <div className="space-y-0.5 text-slate-700">
          <button
            onClick={() => {
              setActiveToolModal('signature');
              setMobileSidebarOpen(false);
            }}
            className="w-full flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-slate-50 text-left transition-colors cursor-pointer"
          >
            <span className="text-pink-500 font-serif italic font-bold">✍</span>
            <span className="text-[10px] font-medium text-slate-700 truncate">Signature Designer</span>
          </button>

          <button
            onClick={() => {
              setIsComposeOpen(true);
              handleGenerateSmartAi();
              setMobileSidebarOpen(false);
            }}
            className="w-full flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-purple-50 text-left transition-colors cursor-pointer text-purple-700 font-semibold"
          >
            <Sparkles className="w-3 h-3 text-purple-600 shrink-0" />
            <span className="text-[10px] truncate">Smart Write AI</span>
          </button>

          <button
            onClick={() => {
              showToast('Email Designer: 12 responsive marketing templates loaded');
              setMobileSidebarOpen(false);
            }}
            className="w-full flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-slate-50 text-left transition-colors cursor-pointer"
          >
            <LayoutTemplate className="w-3 h-3 text-blue-500 shrink-0" />
            <span className="text-[10px] font-medium text-slate-700 truncate">Email Designer</span>
          </button>

          <button
            onClick={() => {
              setActiveToolModal('invoice');
              setMobileSidebarOpen(false);
            }}
            className="w-full flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-slate-50 text-left transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3 h-3 text-teal-500 shrink-0" />
            <span className="text-[10px] font-medium text-slate-700 truncate">Invoice Builder</span>
          </button>

          <button
            onClick={() => {
              setActiveToolModal('help');
              setMobileSidebarOpen(false);
            }}
            className="w-full flex items-center justify-between px-2 py-1 rounded-lg hover:bg-slate-50 text-left transition-colors cursor-pointer text-blue-600"
          >
            <div className="flex items-center gap-1.5 truncate">
              <Compass className="w-3 h-3 text-blue-500 shrink-0" />
              <span className="text-[10px] truncate">Know your Titan</span>
            </div>
            <span className="text-[10px]">›</span>
          </button>
        </div>

        {/* Folders List */}
        <div className="pt-2 border-t border-slate-100 space-y-0.5 text-slate-700">
          <div
            onClick={() => {
              setActiveFolder('inbox');
              setActiveApp('mail');
              setReadingEmail(null);
              setMobileSidebarOpen(false);
            }}
            className={`flex items-center justify-between px-2 py-1 rounded-lg cursor-pointer transition-colors ${
              activeFolder === 'inbox' ? 'bg-blue-50 text-[#0c66e4] font-bold' : 'hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <Mail className="w-3 h-3" />
              <span className="text-[10px]">Inbox</span>
            </div>
            <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-blue-100 text-blue-700 font-bold">
              {unreadCount}
            </span>
          </div>

          <div
            onClick={() => {
              setActiveFolder('drafts');
              showToast('Drafts folder: 2 pending drafts');
              setMobileSidebarOpen(false);
            }}
            className={`flex items-center justify-between px-2 py-1 rounded-lg cursor-pointer transition-colors ${
              activeFolder === 'drafts' ? 'bg-blue-50 text-[#0c66e4] font-bold' : 'hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <Folder className="w-3 h-3 text-slate-600" />
              <span className="text-[10px]">Drafts</span>
            </div>
            <span className="text-[9px] text-slate-400">2</span>
          </div>

          <div
            onClick={() => {
              setActiveFolder('importants');
              showToast('Importants folder: 4 flagged messages');
              setMobileSidebarOpen(false);
            }}
            className={`flex items-center justify-between px-2 py-1 rounded-lg cursor-pointer transition-colors ${
              activeFolder === 'importants' ? 'bg-blue-50 text-[#0c66e4] font-bold' : 'hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <Star className="w-3 h-3 text-amber-500 fill-amber-400" />
              <span className="text-[10px]">Importants</span>
            </div>
            <span className="text-[9px] text-slate-400">4</span>
          </div>

          {customFolders.map((folder, idx) => (
            <div
              key={idx}
              onClick={() => {
                setActiveFolder(folder);
                showToast(`Opened folder: ${folder}`);
                setMobileSidebarOpen(false);
              }}
              className={`flex items-center justify-between px-2 py-1 rounded-lg cursor-pointer transition-colors ${
                activeFolder === folder ? 'bg-blue-50 text-[#0c66e4] font-bold' : 'hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-1.5 truncate">
                <Folder className="w-3 h-3 text-slate-500 shrink-0" />
                <span className="text-[10px] truncate max-w-[90px]">{folder}</span>
              </div>
            </div>
          ))}

          <button
            onClick={() => {
              setActiveToolModal('newFolder');
              setMobileSidebarOpen(false);
            }}
            className="w-full flex items-center gap-1.5 px-2 py-1 text-[10px] text-slate-500 hover:text-slate-900 cursor-pointer"
          >
            <FolderPlus className="w-3 h-3" />
            <span>+ Add folder</span>
          </button>
        </div>
      </div>

      {/* Lower Telemetry */}
      <div className="pt-2 border-t border-slate-100 space-y-1 text-[9px] text-slate-400">
        <button
          onClick={() => {
            setActiveToolModal('newAccount');
            setMobileSidebarOpen(false);
          }}
          className="flex items-center gap-1 text-slate-700 font-bold hover:text-[#0c66e4] cursor-pointer"
        >
          <UserPlus className="w-3 h-3" />
          <span>+ Add alias</span>
        </button>
        <div className="flex items-center justify-between pt-0.5 text-slate-500">
          <span className="text-[8px] font-bold text-emerald-600">● 100% SSL</span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => showToast('Diagnostics: 0 SSL errors, Ping 14ms')}
              className="hover:text-slate-800 cursor-pointer"
              title="Debug Logs"
            >
              <Bug className="w-2.5 h-2.5" />
            </button>
            <button
              type="button"
              onClick={() => showToast('Inbox refreshed')}
              className="hover:text-slate-800 cursor-pointer"
              title="Refresh Mailbox"
            >
              <RefreshCw className="w-2.5 h-2.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // The core Titan Email application interface
  const renderDashboardCore = () => (
    <div className="w-full h-full flex flex-col bg-white overflow-hidden text-xs">
      {/* 1. TOP TITAN NAVIGATION BAR */}
      <header className="h-8.5 sm:h-9 bg-white border-b border-slate-200 px-2 sm:px-2.5 flex items-center justify-between shrink-0 gap-1.5">
        {/* Left Side: Sidebar Toggle + Brand Logo + New Email Button */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => {
              if (typeof window !== 'undefined' && window.innerWidth < 1024) {
                setMobileSidebarOpen(true);
              } else {
                setDesktopSidebarOpen(!desktopSidebarOpen);
              }
            }}
            className="p-1 rounded hover:bg-slate-100 text-slate-600 cursor-pointer transition-colors"
            title="Toggle Sidebar Navigation"
          >
            <Menu className="w-3.5 h-3.5" />
          </button>

          <div
            onClick={() => {
              setActiveApp('mail');
              setReadingEmail(null);
            }}
            className="flex items-center gap-1 cursor-pointer p-0.5 rounded hover:bg-slate-100"
            title="Titan Mailbox Switcher"
          >
            <div className="w-5 h-5 sm:w-6 sm:h-6 rounded bg-[#0c66e4] text-white flex items-center justify-center shadow-xs shrink-0">
              <Mail className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            </div>
          </div>

          <div
            onClick={() => {
              setActiveApp('mail');
              setReadingEmail(null);
            }}
            className="flex items-center gap-1 pr-1 cursor-pointer"
          >
            <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-900 fill-current shrink-0">
              <path d="M12 2L4 7v10l8 5 8-5V7l-8-5zm0 2.2l6 3.75v7.5l-6 3.75-6-3.75v-7.5l6-3.75z" />
            </svg>
            <span className="font-black text-xs tracking-wider text-slate-900 font-sans hidden xs:inline">
              TITAN
            </span>
          </div>

          <div className="relative">
            <button
              onClick={() => setIsComposeOpen(true)}
              className="flex items-center gap-1 px-2 sm:px-2.5 py-1 rounded bg-[#0c66e4] hover:bg-[#0052cc] text-white font-bold text-[11px] shadow-xs active:scale-95 transition-all cursor-pointer"
              title="Compose New Message"
            >
              <PenTool className="w-3 h-3" />
              <span className="hidden sm:inline">New email</span>
              <span className="sm:hidden">New</span>
            </button>
          </div>
        </div>

        {/* Center: Search Box */}
        <div className="flex-1 max-w-xs sm:max-w-sm mx-1 min-w-0">
          <div className="relative flex items-center">
            <Search className="w-3 h-3 text-slate-400 absolute left-2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-7 pr-6 py-0.5 sm:py-1 rounded bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 text-[11px] text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#0c66e4] transition-colors truncate"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-5 p-0.5 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-2.5 h-2.5" />
              </button>
            )}
            <button
              onClick={() => setShowFilterDropdown(!showFilterDropdown)}
              className="absolute right-1.5 p-0.5 text-slate-400 hover:text-slate-700 cursor-pointer"
              title="Search Filters"
            >
              <ChevronDown className="w-2.5 h-2.5" />
            </button>

            {/* Filter Dropdown */}
            {showFilterDropdown && (
              <div className="absolute top-full right-0 mt-1 w-36 bg-white rounded-xl shadow-xl border border-slate-200 py-1 z-40 text-xs text-slate-700 animate-fade-in">
                <button
                  onClick={() => {
                    setFilterType('all');
                    setShowFilterDropdown(false);
                  }}
                  className={`w-full px-2.5 py-1 text-left flex items-center justify-between hover:bg-slate-50 cursor-pointer text-[11px] ${
                    filterType === 'all' ? 'text-[#0c66e4] font-bold' : ''
                  }`}
                >
                  <span>All Emails</span>
                  {filterType === 'all' && <Check className="w-3 h-3" />}
                </button>
                <button
                  onClick={() => {
                    setFilterType('unread');
                    setShowFilterDropdown(false);
                  }}
                  className={`w-full px-2.5 py-1 text-left flex items-center justify-between hover:bg-slate-50 cursor-pointer text-[11px] ${
                    filterType === 'unread' ? 'text-[#0c66e4] font-bold' : ''
                  }`}
                >
                  <span>Unread Only</span>
                  {filterType === 'unread' && <Check className="w-3 h-3" />}
                </button>
                <button
                  onClick={() => {
                    setFilterType('starred');
                    setShowFilterDropdown(false);
                  }}
                  className={`w-full px-2.5 py-1 text-left flex items-center justify-between hover:bg-slate-50 cursor-pointer text-[11px] ${
                    filterType === 'starred' ? 'text-[#0c66e4] font-bold' : ''
                  }`}
                >
                  <span>Starred Only</span>
                  {filterType === 'starred' && <Check className="w-3 h-3" />}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Utility Icons */}
        <div className="flex items-center gap-1 text-slate-500 shrink-0">
          <button
            onClick={() => setShowRightPanel(!showRightPanel)}
            className={`p-1 rounded hover:bg-slate-100 hover:text-slate-800 cursor-pointer transition-colors ${
              showRightPanel ? 'text-[#0c66e4] bg-blue-50' : 'text-slate-500'
            }`}
            title="Toggle Calendar & Tasks Side Panel"
          >
            <CalendarIcon className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setActiveToolModal('settings')}
            className="p-1 hover:text-slate-800 cursor-pointer"
            title="Email Settings & DNS"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1 hover:text-slate-800 cursor-pointer"
            title={isFullscreen ? 'Exit Fullscreen' : 'Expand Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </header>

      {/* 2. BODY GRID */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* DESKTOP LEFT SIDEBAR */}
        {desktopSidebarOpen && (
          <aside className="hidden lg:flex w-36 xl:w-44 bg-white border-r border-slate-200 flex-col shrink-0 overflow-y-auto">
            {renderSidebarContent()}
          </aside>
        )}

        {/* MOBILE SLIDE-OUT DRAWER */}
        {mobileSidebarOpen && (
          <div className="lg:hidden fixed inset-0 z-50 flex">
            <div
              className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity animate-fade-in"
              onClick={() => setMobileSidebarOpen(false)}
            />
            <div className="relative w-56 max-w-[80vw] bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-right border-r border-slate-200">
              <div className="p-2.5 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="w-5 h-5 rounded bg-[#0c66e4] text-white flex items-center justify-center">
                    <Mail className="w-3 h-3" />
                  </div>
                  <span className="font-black text-xs text-slate-900">TITAN Mail</span>
                </div>
                <button
                  onClick={() => setMobileSidebarOpen(false)}
                  className="p-1 rounded hover:bg-slate-100 text-slate-500 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">
                {renderSidebarContent()}
              </div>
            </div>
          </div>
        )}

        {/* CENTER WORKSPACE */}
        <main className="flex-1 flex flex-col bg-white overflow-hidden min-w-0">
          {/* CALENDAR VIEW */}
          {activeApp === 'calendar' && (
            <div className="flex-1 p-2 sm:p-4 overflow-y-auto space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-black text-[11px]">
                    1
                  </div>
                  <div>
                    <h2 className="text-xs font-black text-slate-900">Titan Integrated Calendar</h2>
                    <p className="text-[9px] text-slate-500">September 2026 · Synced with Google Calendar</p>
                  </div>
                </div>
                <button
                  onClick={() => setActiveApp('mail')}
                  className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 font-bold text-[10px] cursor-pointer"
                >
                  Back to Mail
                </button>
              </div>

              <div className="grid grid-cols-7 gap-1 text-center text-xs">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d, i) => (
                  <div key={i} className="font-bold text-slate-400 py-0.5 text-[9px]">
                    {d}
                  </div>
                ))}
                {Array.from({ length: 30 }).map((_, i) => {
                  const day = i + 1;
                  const isToday = day === 30;
                  return (
                    <div
                      key={i}
                      onClick={() => {
                        setNewEventModal({ open: true, slot: `${day} Sep 11:00 AM` });
                      }}
                      className={`min-h-[40px] sm:min-h-[48px] p-1 rounded-lg border text-left flex flex-col justify-between cursor-pointer transition-colors ${
                        isToday
                          ? 'border-[#0c66e4] bg-blue-50/40 ring-1 ring-[#0c66e4]'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <span className={`text-[9px] font-bold ${isToday ? 'text-[#0c66e4]' : 'text-slate-700'}`}>
                        {day}
                      </span>
                      {day === 30 && (
                        <div className="text-[7px] bg-[#0c66e4] text-white px-0.5 rounded font-bold truncate">
                          Standup
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* CONTACTS VIEW */}
          {activeApp === 'contacts' && (
            <div className="flex-1 p-2 sm:p-4 overflow-y-auto space-y-2.5">
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-200">
                <div>
                  <h2 className="text-xs font-black text-slate-900">Titan Contacts Directory</h2>
                  <p className="text-[9px] text-slate-500">142 verified contacts with 1-click import</p>
                </div>
                <button
                  onClick={() => setActiveApp('mail')}
                  className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 font-bold text-[10px] cursor-pointer"
                >
                  Back to Mail
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {[
                  { name: 'Alex Rivera', role: 'CTO, FinTech Next', email: 'alex@fintechnext.in' },
                  { name: 'Priya Sharma', role: 'Operations Lead, Swiggy', email: 'priya@swiggycorp.in' },
                  { name: 'David Chen', role: 'VP Infrastructure, Wix', email: 'd.chen@wixpartners.com' },
                  { name: 'Ekta Rajput', role: 'Media Specialist, Arab Today', email: 'ekta@arabtoday.media' },
                ].map((c, i) => (
                  <div key={i} className="p-2 rounded-lg border border-slate-200 bg-white hover:border-[#0c66e4] transition-all flex items-center justify-between">
                    <div>
                      <strong className="text-[11px] text-slate-900 block">{c.name}</strong>
                      <span className="text-[9px] font-mono text-[#0c66e4]">{c.email}</span>
                    </div>
                    <button
                      onClick={() => {
                        setIsComposeOpen(true);
                        setComposeTo(c.email);
                        setComposeSubject('Discussion regarding Cloud Hosting & Business Mail');
                      }}
                      className="px-1.5 py-0.5 rounded bg-blue-50 text-[#0c66e4] font-bold text-[10px] hover:bg-blue-100 cursor-pointer"
                    >
                      Email
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TITAN DRIVE VIEW */}
          {activeApp === 'drive' && (
            <div className="flex-1 p-2 sm:p-4 overflow-y-auto space-y-2.5">
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-200">
                <div>
                  <h2 className="text-xs font-black text-slate-900">Titan Drive Cloud Storage</h2>
                  <p className="text-[9px] text-slate-500">50 GB High-Speed Storage · 14.2 GB Used</p>
                </div>
                <button
                  onClick={() => setActiveApp('mail')}
                  className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 font-bold text-[10px] cursor-pointer"
                >
                  Back to Mail
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {[
                  { name: 'PO-2026-894-Signed.pdf', size: '2.4 MB' },
                  { name: 'DNS-SPF-DKIM-Setup-Guide.pdf', size: '1.1 MB' },
                  { name: 'Brand-Signature-Assets.zip', size: '12.8 MB' },
                ].map((f, i) => (
                  <div key={i} className="p-2 rounded-lg border border-slate-200 bg-slate-50 hover:bg-white transition-all flex items-center justify-between">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <FileText className="w-3.5 h-3.5 text-[#0c66e4] shrink-0" />
                      <div className="min-w-0">
                        <strong className="text-[10px] text-slate-800 block truncate">{f.name}</strong>
                        <span className="text-[8px] text-slate-400">{f.size}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => showToast(`Downloaded ${f.name}`)}
                      className="p-0.5 text-slate-400 hover:text-slate-800 cursor-pointer shrink-0"
                    >
                      <Download className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* DEFAULT MAILBOX VIEW */}
          {activeApp === 'mail' && (
            <>
              {/* Subheader: Priority (99+) | Other (99+) | Filter */}
              <div className="h-7 sm:h-7.5 border-b border-slate-200 px-2 sm:px-2.5 flex items-center justify-between shrink-0 bg-white">
                <div className="flex items-center gap-2.5 sm:gap-3.5 h-full text-xs font-bold">
                  <div className="flex items-center gap-1">
                    <input
                      type="checkbox"
                      checked={filteredEmails.length > 0 && filteredEmails.every((e) => e.selected)}
                      onChange={handleToggleSelectAll}
                      className="w-3 h-3 rounded border-slate-300 text-[#0c66e4] focus:ring-0 cursor-pointer"
                      title="Select all"
                    />
                  </div>

                  <button
                    onClick={() => {
                      setActiveTab('priority');
                      setReadingEmail(null);
                    }}
                    className={`h-full border-b-2 transition-colors cursor-pointer text-[11px] ${
                      activeTab === 'priority'
                        ? 'border-[#0c66e4] text-[#0c66e4]'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Priority (99+)
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('other');
                      setReadingEmail(null);
                    }}
                    className={`h-full border-b-2 transition-colors cursor-pointer text-[11px] ${
                      activeTab === 'other'
                        ? 'border-[#0c66e4] text-[#0c66e4]'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Other (99+)
                  </button>

                  <div
                    onClick={() => setShowFilterDropdown(!showFilterDropdown)}
                    className="flex items-center gap-0.5 text-slate-500 hover:text-slate-800 cursor-pointer font-medium text-[10px]"
                  >
                    <span className="capitalize hidden xs:inline">{filterType}</span>
                    <ChevronDown className="w-2.5 h-2.5" />
                  </div>
                </div>

                {/* Bulk Actions */}
                {selectedCount > 0 ? (
                  <div className="flex items-center gap-1 animate-fade-in text-[10px]">
                    <button
                      onClick={handleDeleteSelected}
                      className="px-1.5 py-0.5 rounded bg-rose-50 text-rose-600 hover:bg-rose-100 font-bold flex items-center gap-0.5 cursor-pointer"
                    >
                      <Trash2 className="w-2.5 h-2.5" />
                      <span>Delete</span>
                    </button>
                    <button
                      onClick={handleMarkAsRead}
                      className="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                    >
                      Read
                    </button>
                  </div>
                ) : (
                  <div className="text-[10px] text-slate-400 flex items-center gap-1">
                    <span>
                      <strong>{filteredEmails.length}</strong> msgs
                    </span>
                    <button
                      onClick={() => showToast('Mailbox synced with Titan IMAP server')}
                      className="p-0.5 hover:text-slate-700 cursor-pointer"
                      title="Sync Now"
                    >
                      <RefreshCw className="w-2.5 h-2.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* READING EMAIL VIEW */}
              {readingEmail ? (
                <div className="flex-1 p-2.5 sm:p-4 overflow-y-auto bg-slate-50/50 space-y-2.5 animate-fade-in">
                  <div className="flex items-center justify-between pb-1.5 border-b border-slate-200">
                    <button
                      onClick={() => setReadingEmail(null)}
                      className="flex items-center gap-1 text-[11px] font-bold text-[#0c66e4] hover:underline cursor-pointer"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                      <span>Back to inbox</span>
                    </button>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={(e) => handleToggleStar(readingEmail.id, e)}
                        className="p-1 rounded hover:bg-slate-200 text-amber-500 cursor-pointer"
                      >
                        <Star className={`w-3 h-3 ${readingEmail.starred ? 'fill-amber-400' : ''}`} />
                      </button>
                      <button
                        onClick={() => {
                          setEmails(emails.filter((e) => e.id !== readingEmail.id));
                          setReadingEmail(null);
                          showToast('Email deleted');
                        }}
                        className="p-1 rounded hover:bg-rose-50 text-rose-500 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  <h2 className="text-xs sm:text-sm font-black text-slate-900 leading-tight">
                    {readingEmail.subject}
                  </h2>

                  <div className="flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <div
                        className={`w-6 h-6 rounded-full ${
                          readingEmail.avatarBg || 'bg-[#0c66e4]'
                        } text-white flex items-center justify-center font-bold text-[10px] shrink-0`}
                      >
                        {readingEmail.sender[0]}
                      </div>
                      <div>
                        <strong className="text-[11px] text-slate-900 block truncate max-w-[140px] sm:max-w-xs">{readingEmail.sender}</strong>
                        <span className="text-[9px] text-slate-400">admin@yourdomain.com</span>
                      </div>
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono">{readingEmail.date}</span>
                  </div>

                  <div className="p-2.5 sm:p-3 rounded-lg bg-white border border-slate-200 text-[11px] text-slate-700 leading-relaxed whitespace-pre-line shadow-xs">
                    {readingEmail.body || readingEmail.snippet}
                  </div>

                  <div className="flex items-center gap-1.5 pt-1">
                    <button
                      onClick={() => {
                        setIsComposeOpen(true);
                        setComposeTo(readingEmail.sender);
                        setComposeSubject(`Re: ${readingEmail.subject}`);
                      }}
                      className="px-2.5 py-1 rounded bg-[#0c66e4] hover:bg-[#0052cc] text-white font-bold text-[10px] flex items-center gap-1 cursor-pointer shadow-xs active:scale-95"
                    >
                      <Reply className="w-2.5 h-2.5" />
                      <span>Reply</span>
                    </button>
                    <button
                      onClick={() => {
                        setIsComposeOpen(true);
                        setComposeSubject(`Fwd: ${readingEmail.subject}`);
                        setComposeBody(readingEmail.body || readingEmail.snippet);
                      }}
                      className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[10px] flex items-center gap-1 cursor-pointer"
                    >
                      <Forward className="w-2.5 h-2.5" />
                      <span>Forward</span>
                    </button>
                  </div>
                </div>
              ) : (
                /* RESPONSIVE EMAIL LIST (Touch Cards on Small Screens, Clean Table on Desktop) */
                <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
                  {filteredEmails.map((email) => (
                    <div
                      key={email.id}
                      onClick={() => {
                        setReadingEmail(email);
                        setEmails((prev) =>
                          prev.map((e) => (e.id === email.id ? { ...e, unread: false } : e))
                        );
                      }}
                      className={`px-2 sm:px-3 py-1.5 hover:bg-slate-50 transition-colors cursor-pointer group ${
                        email.selected ? 'bg-blue-50/60' : ''
                      }`}
                    >
                      {/* DESKTOP ROW */}
                      <div className="hidden sm:flex items-center gap-2 text-xs">
                        <input
                          type="checkbox"
                          checked={email.selected || false}
                          onClick={(e) => e.stopPropagation()}
                          onChange={() => handleToggleEmailCheck(email.id)}
                          className="w-3 h-3 rounded border-slate-300 text-[#0c66e4] focus:ring-0 cursor-pointer shrink-0"
                        />

                        {/* Blue Unread Dot */}
                        <div className="w-1.5 flex justify-center shrink-0">
                          {email.unread ? (
                            <span className="w-1.5 h-1.5 rounded-full bg-[#0c66e4]" />
                          ) : (
                            <span className="w-1.5 h-1.5 rounded-full bg-transparent" />
                          )}
                        </div>

                        {/* Sender Name */}
                        <div
                          className={`w-28 lg:w-32 truncate shrink-0 text-[11px] ${
                            email.unread ? 'font-black text-slate-900' : 'text-slate-600 font-medium'
                          }`}
                        >
                          {email.sender}
                        </div>

                        {/* Subject + Snippet Preview */}
                        <div className="flex-1 min-w-0 truncate text-slate-600 text-[10px] lg:text-[11px]">
                          <span
                            className={`mr-1 ${
                              email.unread ? 'font-black text-slate-900' : 'font-semibold text-slate-800'
                            }`}
                          >
                            {email.subject}
                          </span>
                          <span className="text-slate-400 font-normal">{email.snippet}</span>
                        </div>

                        {/* Date */}
                        <div className="text-[9px] text-slate-400 shrink-0 font-mono text-right w-14">
                          {email.date}
                        </div>
                      </div>

                      {/* MOBILE TOUCH CARD */}
                      <div className="sm:hidden space-y-0.5">
                        <div className="flex items-center justify-between gap-1">
                          <div className="flex items-center gap-1 min-w-0">
                            <div className="w-1.5 shrink-0">
                              {email.unread && <span className="w-1.5 h-1.5 rounded-full bg-[#0c66e4] block" />}
                            </div>
                            <span
                              className={`text-[11px] truncate ${
                                email.unread ? 'font-black text-slate-900' : 'font-semibold text-slate-700'
                              }`}
                            >
                              {email.sender}
                            </span>
                          </div>
                          <span className="text-[9px] text-slate-400 font-mono shrink-0">{email.date}</span>
                        </div>
                        <div className="text-[10px] text-slate-800 line-clamp-1 pl-2.5">
                          <span className={email.unread ? 'font-bold' : 'font-medium'}>{email.subject}</span>
                          <span className="text-slate-400 text-[9px] ml-1">— {email.snippet}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </main>

        {/* RIGHT SIDEBAR: CALENDAR & TASKS */}
        {showRightPanel && (
          <aside className="absolute right-0 top-0 bottom-0 z-30 w-56 bg-white border-l border-slate-200 shadow-xl flex flex-col shrink-0 overflow-hidden text-xs animate-slide-left">
            <div className="h-8 border-b border-slate-200 px-2 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3 text-xs font-bold">
                <button
                  onClick={() => setRightPanelTab('calendar')}
                  className={`h-full border-b-2 pt-1 pb-0.5 transition-colors cursor-pointer text-[11px] ${
                    rightPanelTab === 'calendar'
                      ? 'border-[#0c66e4] text-[#0c66e4]'
                      : 'border-transparent text-slate-500'
                  }`}
                >
                  Calendar
                </button>
                <button
                  onClick={() => setRightPanelTab('tasks')}
                  className={`h-full border-b-2 pt-1 pb-0.5 transition-colors cursor-pointer text-[11px] ${
                    rightPanelTab === 'tasks'
                      ? 'border-[#0c66e4] text-[#0c66e4]'
                      : 'border-transparent text-slate-500'
                  }`}
                >
                  Tasks
                </button>
              </div>

              <button
                onClick={() => setShowRightPanel(false)}
                className="p-0.5 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-700 cursor-pointer"
                title="Hide Sidebar"
              >
                <X className="w-3 h-3" />
              </button>
            </div>

            {/* TAB 1: CALENDAR VIEW */}
            {rightPanelTab === 'calendar' && (
              <div className="flex-1 flex flex-col overflow-y-auto">
                <div className="p-2 pb-1 border-b border-slate-100">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-slate-900 text-[11px]">Sep 2026</span>
                    <div className="flex items-center gap-1 text-slate-400">
                      <button onClick={() => showToast('Previous month')} className="p-0.5 hover:text-slate-800 cursor-pointer">
                        <ChevronLeft className="w-3 h-3" />
                      </button>
                      <button onClick={() => showToast('Next month')} className="p-0.5 hover:text-slate-800 cursor-pointer">
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-7 text-center text-[9px] text-slate-400 mb-0.5">
                    <span>S</span><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span>
                  </div>
                  <div className="grid grid-cols-7 text-center text-[10px] font-bold text-slate-700">
                    <span className="text-slate-400">27</span><span>28</span><span>29</span>
                    <span className="w-4 h-4 mx-auto rounded-full bg-[#0c66e4] text-white flex items-center justify-center font-black shadow-xs text-[9px]">
                      30
                    </span>
                    <span>1</span><span>2</span><span>3</span>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-1.5 font-mono text-[9px] text-slate-400 divide-y divide-slate-100">
                  {[
                    '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM',
                  ].map((timeSlot, i) => {
                    const eventInSlot = calendarEvents.find((e) => e.timeSlot === timeSlot);
                    return (
                      <div
                        key={i}
                        onClick={() => setNewEventModal({ open: true, slot: timeSlot })}
                        className="py-1 flex items-center justify-between hover:bg-blue-50/50 cursor-pointer px-1 rounded transition-colors"
                      >
                        <span>{timeSlot}</span>
                        {eventInSlot ? (
                          <span className={`text-[8px] px-1 py-0.2 rounded font-sans font-bold border truncate max-w-[100px] ${eventInSlot.color}`}>
                            {eventInSlot.title}
                          </span>
                        ) : (
                          <span className="text-[8px] text-[#0c66e4] opacity-0 hover:opacity-100 font-sans font-bold">
                            + New
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 2: TASKS VIEW */}
            {rightPanelTab === 'tasks' && (
              <div className="flex-1 p-2 flex flex-col justify-between overflow-y-auto space-y-2">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-extrabold text-slate-800 uppercase tracking-wider">
                      Tasks ({taskList.filter((t) => !t.done).length})
                    </span>
                    <span className="text-emerald-600 font-bold">
                      {taskList.filter((t) => t.done).length} Done
                    </span>
                  </div>

                  <div className="space-y-1">
                    {taskList.map((task) => (
                      <div
                        key={task.id}
                        onClick={() => toggleTask(task.id)}
                        className={`p-1.5 rounded-lg border flex items-center gap-1.5 cursor-pointer transition-colors ${
                          task.done
                            ? 'bg-slate-50 border-slate-200 text-slate-400 line-through'
                            : 'bg-white border-slate-200 text-slate-700 hover:border-[#0c66e4]'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={task.done}
                          onChange={() => toggleTask(task.id)}
                          className="w-3 h-3 rounded text-[#0c66e4] cursor-pointer"
                        />
                        <span className="text-[10px] leading-tight">{task.text}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <form onSubmit={handleAddTask} className="pt-1.5 border-t border-slate-100">
                  <input
                    type="text"
                    placeholder="+ Add quick task..."
                    value={newTaskInput}
                    onChange={(e) => setNewTaskInput(e.target.value)}
                    className="w-full px-2 py-1 rounded border border-slate-300 text-[10px] focus:outline-none focus:border-[#0c66e4]"
                  />
                </form>
              </div>
            )}
          </aside>
        )}
      </div>

      {/* 3. COMPOSE EMAIL MODAL */}
      {isComposeOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
          <div className="w-full max-w-xl max-h-[92vh] bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden animate-fade-in flex flex-col">
            <div className="bg-[#0c66e4] text-white px-3 sm:px-4 py-2 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <PenTool className="w-4 h-4" />
                <span className="font-bold text-xs">New Message · Titan Webmail</span>
              </div>
              <button
                onClick={() => setIsComposeOpen(false)}
                className="p-1 hover:bg-white/20 rounded cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSendEmail} className="p-3 sm:p-4 space-y-2.5 text-xs overflow-y-auto flex-1">
              <div>
                <label className="text-[11px] font-bold text-slate-500 uppercase block mb-0.5">To:</label>
                <input
                  type="email"
                  placeholder="recipient@company.com"
                  value={composeTo}
                  onChange={(e) => setComposeTo(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:border-[#0c66e4]"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-500 uppercase block mb-0.5">Subject:</label>
                <input
                  type="text"
                  placeholder="Subject line"
                  value={composeSubject}
                  onChange={(e) => setComposeSubject(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:border-[#0c66e4]"
                />
              </div>

              <div className="p-2 sm:p-2.5 rounded-xl bg-purple-50 border border-purple-200 space-y-1.5">
                <div className="flex flex-col xs:flex-row xs:items-center justify-between gap-1.5">
                  <div className="flex items-center gap-1.5 text-purple-900 font-bold text-xs">
                    <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
                    <span>Smart Write AI Assistant</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleGenerateSmartAi}
                    disabled={isAiGenerating}
                    className="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-[10px] sm:text-[11px] shadow-xs cursor-pointer flex items-center gap-1 disabled:opacity-50 self-start xs:self-auto"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>{isAiGenerating ? 'Drafting...' : 'Auto-Generate Email'}</span>
                  </button>
                </div>

                <div className="flex items-center gap-1 text-[10px] flex-wrap">
                  <span className="text-purple-700 font-bold">Tone:</span>
                  {(['professional', 'polite', 'sales', 'urgent'] as const).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setAiTone(t)}
                      className={`px-2 py-0.5 rounded-full capitalize cursor-pointer transition-colors ${
                        aiTone === t ? 'bg-purple-700 text-white font-bold' : 'bg-white text-purple-700 border border-purple-200'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <textarea
                rows={5}
                placeholder="Write your email here..."
                value={composeBody}
                onChange={(e) => setComposeBody(e.target.value)}
                className="w-full p-2.5 sm:p-3 rounded-lg border border-slate-300 text-xs focus:outline-none focus:border-[#0c66e4] leading-relaxed font-sans"
              />

              <div className="flex items-center justify-between pt-2 border-t border-slate-200 shrink-0">
                <div className="flex items-center gap-2">
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-[#0c66e4] hover:bg-[#0052cc] text-white font-black text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => showToast('Attachment dialog simulation')}
                    className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 cursor-pointer"
                    title="Attach File"
                  >
                    <Paperclip className="w-4 h-4" />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setIsComposeOpen(false)}
                  className="text-slate-400 hover:text-slate-600 text-xs font-semibold cursor-pointer"
                >
                  Discard
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. MODALS (Signature, Invoice, Settings, Folders, Accounts, Events) */}
      {activeToolModal === 'signature' && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden animate-fade-in p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <div className="flex items-center gap-2 text-slate-900 font-black text-sm">
                <span className="text-pink-500 font-serif italic text-base">✍</span>
                <span>Titan Signature Designer</span>
              </div>
              <button onClick={() => setActiveToolModal(null)} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-500">
              Create an HTML branded signature attached automatically to all outgoing emails.
            </p>
            <div className="p-3 sm:p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
              <strong className="text-slate-900 block font-black text-sm">Ishwar Kumar</strong>
              <span className="text-slate-500 block">Senior Cloud Architect · Gitysoft Technologies</span>
              <div className="text-[11px] text-slate-600 space-y-0.5 font-mono">
                <div>✉ admin@gitysofttechnologies.in</div>
                <div>🌐 www.gitysofttechnologies.in</div>
                <div>📞 +91 98765 43210 (24/7 NOC)</div>
              </div>
              <div className="pt-2 flex items-center gap-2 flex-wrap">
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                  ✓ Verified Titan DKIM
                </span>
                <span className="px-2 py-0.5 rounded bg-blue-100 text-[#0c66e4] text-[10px] font-bold">
                  99.9% Uptime Host
                </span>
              </div>
            </div>
            <button
              onClick={() => {
                setActiveToolModal(null);
                showToast('✓ Custom email signature saved and applied!');
              }}
              className="w-full py-2.5 rounded-xl bg-[#0c66e4] hover:bg-[#0052cc] text-white font-bold text-xs cursor-pointer shadow-md"
            >
              Save &amp; Apply Signature
            </button>
          </div>
        </div>
      )}

      {activeToolModal === 'invoice' && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden animate-fade-in p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <div className="flex items-center gap-2 text-slate-900 font-black text-sm">
                <FileSpreadsheet className="w-4 h-4 text-teal-600" />
                <span>Titan 1-Click Invoice Builder</span>
              </div>
              <button onClick={() => setActiveToolModal(null)} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-500">
              Generate and email professional invoices directly to clients with tracking enabled.
            </p>
            <div className="p-3 sm:p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
              <div className="flex justify-between font-bold text-slate-800 pb-1 border-b border-slate-200">
                <span>Invoice #INV-2026-081</span>
                <span>Due in 15 Days</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>10x Business Mailboxes (Premium 50GB)</span>
                <span className="font-mono font-bold">₹6,990</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>10-Year Long Term Lock-in Discount (25%)</span>
                <span className="font-mono text-emerald-600 font-bold">-₹1,747</span>
              </div>
              <div className="flex justify-between font-black text-slate-900 pt-1 border-t border-slate-200 text-sm">
                <span>Total Due:</span>
                <span className="font-mono text-[#0c66e4]">₹5,243</span>
              </div>
            </div>
            <button
              onClick={() => {
                setActiveToolModal(null);
                showToast('✓ Invoice dispatched to client with Real-time Read Receipt!');
              }}
              className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs cursor-pointer shadow-md"
            >
              Send Invoice PDF to Client
            </button>
          </div>
        </div>
      )}

      {activeToolModal === 'settings' && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden animate-fade-in p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <div className="flex items-center gap-2 text-slate-900 font-black text-sm">
                <Settings className="w-4 h-4 text-slate-700" />
                <span>Titan Mailbox &amp; Server Settings</span>
              </div>
              <button onClick={() => setActiveToolModal(null)} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2.5 text-xs text-slate-700">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <strong className="block font-bold text-slate-900">Incoming Mail (IMAP):</strong>
                <div className="font-mono text-[11px] text-slate-600">imap.titan.email · Port 993 (SSL/TLS)</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <strong className="block font-bold text-slate-900">Outgoing Mail (SMTP):</strong>
                <div className="font-mono text-[11px] text-slate-600">smtp.titan.email · Port 465 (SSL) / 587 (TLS)</div>
              </div>
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 space-y-1">
                <div className="flex items-center gap-1.5 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>DNS Deliverability Records Verified</span>
                </div>
                <div className="text-[11px] space-y-0.5 font-mono text-emerald-700">
                  <div>MX: mx1.titan.email (Priority 10)</div>
                  <div>SPF: v=spf1 include:spf.titan.email ~all</div>
                  <div>DKIM: s1._domainkey.titan.email</div>
                </div>
              </div>
            </div>
            <button
              onClick={() => {
                setActiveToolModal(null);
                showToast('✓ DNS & Server settings verified!');
              }}
              className="w-full py-2.5 rounded-xl bg-[#0c66e4] hover:bg-[#0052cc] text-white font-bold text-xs cursor-pointer shadow-md"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {activeToolModal === 'help' && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden animate-fade-in p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <div className="flex items-center gap-2 text-slate-900 font-black text-sm">
                <Compass className="w-4 h-4 text-[#0c66e4]" />
                <span>Know Your Titan Email Suite</span>
              </div>
              <button onClick={() => setActiveToolModal(null)} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <ul className="space-y-2 text-xs text-slate-600">
              <li className="p-2 rounded-lg bg-slate-50 border border-slate-200 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                <span><strong>Smart Write AI:</strong> Click "+ New email" to generate context-aware replies with one click.</span>
              </li>
              <li className="p-2 rounded-lg bg-slate-50 border border-slate-200 flex items-start gap-2">
                <Eye className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span><strong>Read Receipts:</strong> Know the exact minute your customer opens your quote or invoice.</span>
              </li>
            </ul>
            <button
              onClick={() => setActiveToolModal(null)}
              className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs cursor-pointer shadow-md"
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {activeToolModal === 'newFolder' && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden animate-fade-in p-5 space-y-3">
            <h3 className="text-xs font-black text-slate-900 uppercase">Create New Folder</h3>
            <input
              type="text"
              placeholder="e.g. Legal Documents"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:border-[#0c66e4]"
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setActiveToolModal(null)}
                className="px-3 py-1.5 rounded-lg text-slate-500 text-xs font-bold hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (newFolderName.trim()) {
                    setCustomFolders([...customFolders, newFolderName.trim()]);
                    setNewFolderName('');
                    setActiveToolModal(null);
                    showToast('Folder created!');
                  }
                }}
                className="px-4 py-1.5 rounded-lg bg-[#0c66e4] text-white text-xs font-bold hover:bg-[#0052cc] cursor-pointer"
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}

      {activeToolModal === 'newAccount' && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden animate-fade-in p-5 space-y-3">
            <h3 className="text-xs font-black text-slate-900 uppercase">Add Email Alias or User Account</h3>
            <p className="text-[11px] text-slate-500">
              Create up to 50 free aliases (e.g. support@ or sales@) routing to your main inbox.
            </p>
            <input
              type="email"
              placeholder="alias@yourdomain.com"
              value={newAccountEmail}
              onChange={(e) => setNewAccountEmail(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:border-[#0c66e4]"
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setActiveToolModal(null)}
                className="px-3 py-1.5 rounded-lg text-slate-500 text-xs font-bold hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (newAccountEmail.trim()) {
                    setActiveToolModal(null);
                    setNewAccountEmail('');
                    showToast('Alias successfully added and verified!');
                  }
                }}
                className="px-4 py-1.5 rounded-lg bg-[#0c66e4] text-white text-xs font-bold hover:bg-[#0052cc] cursor-pointer"
              >
                Add Alias
              </button>
            </div>
          </div>
        </div>
      )}

      {newEventModal.open && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden animate-fade-in p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black text-slate-900 uppercase">New Calendar Event</h3>
              <button onClick={() => setNewEventModal({ open: false, slot: '' })} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-[11px] text-slate-500">Time slot: <strong>{newEventModal.slot}</strong></p>
            <form onSubmit={handleCreateCalendarEvent} className="space-y-3">
              <input
                type="text"
                placeholder="Meeting Title (e.g., Client Demo Call)"
                value={newEventTitle}
                onChange={(e) => setNewEventTitle(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:border-[#0c66e4]"
                autoFocus
                required
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setNewEventModal({ open: false, slot: '' })}
                  className="px-3 py-1.5 rounded-lg text-slate-500 text-xs font-bold hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#0c66e4] text-white text-xs font-bold hover:bg-[#0052cc] cursor-pointer shadow-xs"
                >
                  Schedule Event
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );

  // If Fullscreen mode is triggered, render borderless edge-to-edge
  if (isFullscreen) {
    return (
      <div className="fixed inset-0 z-50 h-screen w-screen bg-white overflow-hidden flex flex-col">
        {toastMsg && (
          <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-5 py-2.5 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs font-bold animate-fade-in border border-slate-700">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{toastMsg}</span>
          </div>
        )}
        {renderDashboardCore()}
      </div>
    );
  }

  // STANDARD VIEW: COMPACT & PROPORTIONATE REALISTIC LAPTOP MOCKUP FRAME
  return (
    <div className="w-full max-w-[450px] sm:max-w-[480px] lg:max-w-[500px] xl:max-w-[520px] relative mx-auto group select-none py-1">
      {toastMsg && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-4 py-2 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-bold animate-fade-in border border-slate-700">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. LAPTOP SCREEN LID (MATTE DARK TITANIUM BEZEL + WEBCAM + HARDWARE DETAILS) */}
      {/* ========================================================================= */}
      <div className="bg-[#0b0e14] rounded-t-[16px] sm:rounded-t-[22px] p-1.5 sm:p-2 pb-0 shadow-[0_20px_50px_-12px_rgba(0,0,0,0.3)] ring-1 ring-slate-800 border-t border-x border-slate-700/80 relative">
        {/* Top Screen Bezel: Window Controls + Center Webcam Lens & Status LED */}
        <div className="h-3.5 sm:h-4 flex items-center justify-between px-1.5 relative mb-0.5">
          {/* Left: Classic Window Action Buttons */}
          <div className="flex items-center gap-1.5 opacity-70 hover:opacity-100 transition-opacity">
            <span className="w-2 h-2 rounded-full bg-[#ff5f57] border border-[#e0443e] shadow-xs inline-block" />
            <span className="w-2 h-2 rounded-full bg-[#febc2e] border border-[#d89e24] shadow-xs inline-block" />
            <span className="w-2 h-2 rounded-full bg-[#28c840] border border-[#1aab29] shadow-xs inline-block" />
          </div>

          {/* Center: HD Webcam with Glass Lens Reflection & Camera LED */}
          <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-slate-950/80 ring-1 ring-slate-800 shadow-inner">
            <span className="w-1.5 h-1.5 rounded-full bg-black ring-1 ring-slate-700/80 flex items-center justify-center">
              <span className="w-0.5 h-0.5 rounded-full bg-blue-400/80" />
            </span>
            <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse ring-1 ring-emerald-500/60" title="Webcam active" />
          </div>

          {/* Right: Empty balance spacer */}
          <div className="w-8" />
        </div>

        {/* INNER SCREEN DISPLAY (Houses the Functional Titan Webmail Dashboard) */}
        <div className="w-full bg-white rounded-t-sm sm:rounded-t-md overflow-hidden flex flex-col h-[320px] sm:h-[350px] lg:h-[370px] xl:h-[385px] border border-slate-300 shadow-inner relative">
          {renderDashboardCore()}
        </div>

        {/* Bottom Screen Bezel (Laptop Chin - Clean Unbranded Bezel) */}
        <div className="h-2 sm:h-2.5 bg-[#0b0e14] border-t border-slate-900" />
      </div>

      {/* ========================================================================= */}
      {/* 2. LAPTOP CHASSIS & KEYBOARD BASE (METALLIC UNIBODY + THUMB SCOOP + SHADOW) */}
      {/* ========================================================================= */}
      <div className="relative w-full">
        {/* Hinge Connection Strip */}
        <div className="w-[96%] mx-auto h-1 sm:h-1.5 bg-[#171f2e] border-t border-slate-800 rounded-b-xs" />

        {/* Aluminum Laptop Base Chassis (Extends slightly outward like real MacBook) */}
        <div className="-mx-1.5 sm:-mx-2.5 h-3 sm:h-3.5 bg-gradient-to-b from-[#e2e8f0] via-[#cbd5e1] to-[#94a3b8] rounded-b-lg sm:rounded-b-xl border-t border-slate-200 shadow-lg flex items-start justify-center relative ring-1 ring-slate-400/40">
          {/* Center Thumb Scoop / Display Opener Groove */}
          <div className="w-12 sm:w-16 h-1 bg-slate-500/70 rounded-b-md shadow-inner mx-auto" />
        </div>

        {/* Realistic Desk Shadow beneath Laptop Base */}
        <div className="w-[85%] mx-auto h-3 bg-black/20 blur-md rounded-full -mt-0.5 pointer-events-none" />
      </div>
    </div>
  );
};

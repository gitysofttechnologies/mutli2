import React, { useState } from 'react';
import {
  Globe,
  Settings,
  FileText,
  Image,
  MessageSquare,
  Puzzle,
  Users,
  Wrench,
  Gauge,
  Flame,
  CheckCircle2,
  RefreshCw,
  Plus,
  Trash2,
  ExternalLink,
  ShieldCheck,
  Zap,
  Sliders,
  Check,
  Clock,
  Sparkles,
  ShoppingBag,
  Maximize2,
  Minimize2,
} from 'lucide-react';

interface BlogPost {
  id: string;
  title: string;
  status: 'Published' | 'Draft';
  author: string;
  date: string;
  comments: number;
}

interface PluginItem {
  id: string;
  name: string;
  version: string;
  active: boolean;
  desc: string;
  category: string;
}

export const FunctionalWordPressDashboard: React.FC = () => {
  const [activeMenu, setActiveMenu] = useState<'dashboard' | 'posts' | 'plugins' | 'lscache' | 'settings'>('dashboard');
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  // Operational Posts State
  const [posts, setPosts] = useState<BlogPost[]>([
    {
      id: 'p1',
      title: 'Welcome to Turbocharged WordPress on NVMe LiteSpeed',
      status: 'Published',
      author: 'admin',
      date: 'Today at 09:42',
      comments: 3,
    },
    {
      id: 'p2',
      title: '10 Tips to Score 100/100 on Google Core Web Vitals',
      status: 'Published',
      author: 'admin',
      date: 'Yesterday',
      comments: 5,
    },
    {
      id: 'p3',
      title: 'WooCommerce High-Traffic Black Friday Optimization Guide',
      status: 'Draft',
      author: 'admin',
      date: '3 days ago',
      comments: 0,
    },
  ]);

  // Operational Quick Draft Inputs
  const [draftTitle, setDraftTitle] = useState('');
  const [draftContent, setDraftContent] = useState('');

  // Operational Plugins State
  const [plugins, setPlugins] = useState<PluginItem[]>([
    {
      id: 'lscache',
      name: 'LiteSpeed Cache Enterprise',
      version: '6.5.4',
      active: true,
      desc: 'All-in-one site acceleration, full-page cache, image optimization & critical CSS.',
      category: 'Performance',
    },
    {
      id: 'redis',
      name: 'Redis Object Cache Pro',
      version: '2.5.1',
      active: true,
      desc: 'Persistent RAM cache for instant SQL query and WooCommerce cart retrieval.',
      category: 'Database',
    },
    {
      id: 'elementor',
      name: 'Elementor Website Builder Pro',
      version: '3.24.2',
      active: true,
      desc: 'The leading visual drag-and-drop website design framework.',
      category: 'Design',
    },
    {
      id: 'woocommerce',
      name: 'WooCommerce Store Engine',
      version: '9.3.1',
      active: true,
      desc: 'An open-source, completely customizable e-commerce platform.',
      category: 'E-Commerce',
    },
    {
      id: 'yoast',
      name: 'Yoast SEO Premium',
      version: '23.4',
      active: false,
      desc: 'Advanced search engine optimization and automated XML sitemaps.',
      category: 'SEO',
    },
  ]);

  // Operational Settings
  const [siteTitle, setSiteTitle] = useState('My High-Speed WordPress Store');
  const [tagline, setTagline] = useState('Powered by Enterprise LiteSpeed & NVMe');
  const [stagingSynced, setStagingSynced] = useState(false);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleSaveDraft = (e: React.FormEvent) => {
    e.preventDefault();
    if (!draftTitle.trim()) return;

    const newPost: BlogPost = {
      id: `p_${Date.now()}`,
      title: draftTitle,
      status: 'Draft',
      author: 'admin',
      date: 'Just now',
      comments: 0,
    };

    setPosts([newPost, ...posts]);
    setDraftTitle('');
    setDraftContent('');
    showToast(`Draft "${draftTitle}" saved successfully!`);
  };

  const handleTogglePlugin = (pluginId: string) => {
    setPlugins((prev) =>
      prev.map((pl) => {
        if (pl.id === pluginId) {
          const nextState = !pl.active;
          showToast(`${pl.name} ${nextState ? 'Activated' : 'Deactivated'}`);
          return { ...pl, active: nextState };
        }
        return pl;
      })
    );
  };

  const handlePurgeCache = () => {
    showToast('⚡ LiteSpeed Full Page & Object Cache Purged Successfully (0.02s)!');
  };

  const handlePushStaging = () => {
    setStagingSynced(true);
    showToast('🚀 Staging Environment Cloned to Production with Zero Downtime!');
    setTimeout(() => setStagingSynced(false), 4000);
  };

  const handleDeletePost = (id: string, title: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== id));
    showToast(`Post "${title}" deleted.`);
  };

  const renderWpCore = () => (
    <div className="w-full h-full flex flex-col bg-[#f0f0f1] overflow-hidden font-sans text-slate-800 text-xs">
      {/* 1. AUTHENTIC WORDPRESS TOP ADMIN BAR */}
      <div className="bg-[#1d2327] text-[#c3c4c7] h-8 sm:h-8.5 px-2.5 flex items-center justify-between text-xs border-b border-[#2c3338] select-none shrink-0">
        <div className="flex items-center gap-2 sm:gap-3">
          {/* WP Logo */}
          <div className="flex items-center gap-1 hover:text-white cursor-pointer" title="WordPress 6.7.2">
            <span className="w-4.5 h-4.5 rounded-full bg-white text-[#1d2327] font-serif font-black flex items-center justify-center text-[11px] leading-none">
              W
            </span>
          </div>

          {/* Site Name */}
          <div className="flex items-center gap-1 hover:text-[#72aee6] cursor-pointer font-medium text-[11px]">
            <Globe className="w-3 h-3 text-[#72aee6]" />
            <span className="truncate max-w-[120px] sm:max-w-[160px] font-bold">{siteTitle}</span>
          </div>

          {/* LiteSpeed Purge Quick Link */}
          <button
            onClick={handlePurgeCache}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 transition-colors cursor-pointer text-[10px] font-bold"
            title="Purge All Caches"
          >
            <Flame className="w-3 h-3 text-amber-400" />
            <span className="hidden xs:inline">Purge</span>
          </button>

          {/* + New Button */}
          <button
            onClick={() => setActiveMenu('posts')}
            className="hidden sm:flex items-center gap-1 hover:text-white cursor-pointer text-[10px]"
          >
            <Plus className="w-3 h-3 text-[#72aee6]" />
            <span>New</span>
          </button>
        </div>

        {/* User Info & Fullscreen Toggle */}
        <div className="flex items-center gap-2 text-[10px] sm:text-[11px]">
          <span className="text-[#a7aaad] hidden sm:inline">Howdy, <strong>admin</strong></span>
          <div className="w-4.5 h-4.5 rounded-full bg-[#2271b1] text-white flex items-center justify-center font-bold text-[9px]">
            A
          </div>
          <button
            type="button"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1 rounded hover:bg-[#2c3338] text-slate-300 hover:text-white cursor-pointer transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Expand to Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* 2. MAIN WP LAYOUT: LEFT SIDEBAR + CONTENT AREA */}
      <div className="flex flex-row flex-1 overflow-hidden min-h-0">
        {/* Authentic WordPress Left Sidebar */}
        <div className="w-28 sm:w-36 md:w-40 bg-[#1d2327] text-[#c3c4c7] shrink-0 border-r border-[#2c3338] select-none text-[11px] py-1.5 overflow-y-auto">
          <ul className="space-y-0.5">
            <li>
              <button
                onClick={() => setActiveMenu('dashboard')}
                className={`w-full text-left px-3 py-2 flex items-center gap-2.5 transition-colors cursor-pointer ${
                  activeMenu === 'dashboard'
                    ? 'bg-[#2271b1] text-white font-bold'
                    : 'hover:bg-[#135e96]/40 hover:text-[#72aee6]'
                }`}
              >
                <Gauge className="w-4 h-4 shrink-0" />
                <span>Dashboard</span>
              </button>
            </li>

            <li>
              <button
                onClick={() => setActiveMenu('posts')}
                className={`w-full text-left px-3 py-2 flex items-center justify-between transition-colors cursor-pointer ${
                  activeMenu === 'posts'
                    ? 'bg-[#2271b1] text-white font-bold'
                    : 'hover:bg-[#135e96]/40 hover:text-[#72aee6]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <FileText className="w-4 h-4 shrink-0" />
                  <span>Posts</span>
                </div>
                <span className="px-1.5 py-0.2 rounded-full bg-[#2c3338] text-[10px] text-white">
                  {posts.length}
                </span>
              </button>
            </li>

            <li>
              <button
                onClick={() => setActiveMenu('plugins')}
                className={`w-full text-left px-3 py-2 flex items-center justify-between transition-colors cursor-pointer ${
                  activeMenu === 'plugins'
                    ? 'bg-[#2271b1] text-white font-bold'
                    : 'hover:bg-[#135e96]/40 hover:text-[#72aee6]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Puzzle className="w-4 h-4 shrink-0" />
                  <span>Plugins</span>
                </div>
                <span className="px-1.5 py-0.2 rounded-full bg-[#d63638] text-[10px] text-white font-bold">
                  {plugins.filter((p) => p.active).length}
                </span>
              </button>
            </li>

            <li>
              <button
                onClick={() => setActiveMenu('lscache')}
                className={`w-full text-left px-3 py-2 flex items-center gap-2.5 transition-colors cursor-pointer ${
                  activeMenu === 'lscache'
                    ? 'bg-[#2271b1] text-white font-bold'
                    : 'hover:bg-[#135e96]/40 text-amber-300'
                }`}
              >
                <Flame className="w-4 h-4 shrink-0 text-amber-400" />
                <span>LiteSpeed Cache</span>
              </button>
            </li>

            <li>
              <button
                onClick={() => setActiveMenu('settings')}
                className={`w-full text-left px-3 py-2 flex items-center gap-2.5 transition-colors cursor-pointer ${
                  activeMenu === 'settings'
                    ? 'bg-[#2271b1] text-white font-bold'
                    : 'hover:bg-[#135e96]/40 hover:text-[#72aee6]'
                }`}
              >
                <Settings className="w-4 h-4 shrink-0" />
                <span>Settings</span>
              </button>
            </li>
          </ul>

          {/* Quick WordPress Server Telemetry */}
          <div className="mt-8 px-3 pt-4 border-t border-[#2c3338] space-y-2 text-[10px] text-[#8c8f94]">
            <div className="flex justify-between items-center">
              <span>WordPress:</span>
              <span className="text-white font-mono">v6.7.2</span>
            </div>
            <div className="flex justify-between items-center">
              <span>PHP Engine:</span>
              <span className="text-emerald-400 font-mono">PHP 8.3.14</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Web Server:</span>
              <span className="text-white font-mono">LiteSpeed Ent</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Object Cache:</span>
              <span className="text-sky-400 font-bold">Redis RAM</span>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 p-4 sm:p-6 bg-[#f0f0f1] overflow-y-auto">
          {/* ======================================================== */}
          {/* VIEW 1: DASHBOARD HOME */}
          {/* ======================================================== */}
          {activeMenu === 'dashboard' && (
            <div className="space-y-5 animate-fade-in">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-300">
                <div>
                  <h2 className="text-2xl font-black text-[#1d2327]">Dashboard</h2>
                  <p className="text-xs text-slate-500">
                    Live operational WordPress control panel simulator running on LiteSpeed Enterprise.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePushStaging}
                    className="px-3 py-1.5 rounded-lg bg-[#2271b1] hover:bg-[#135e96] text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${stagingSynced ? 'animate-spin' : ''}`} />
                    <span>Push Staging to Live</span>
                  </button>
                  <button
                    onClick={handlePurgeCache}
                    className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <Flame className="w-3.5 h-3.5 text-amber-500" />
                    <span>Purge Cache</span>
                  </button>
                </div>
              </div>

              {/* Top Banner Notice */}
              <div className="p-4 rounded-xl bg-white border-l-4 border-l-[#2271b1] border border-slate-200 shadow-sm flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#2271b1] shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <h4 className="font-extrabold text-slate-900">LiteSpeed Cache &amp; Redis Object Cache are Active</h4>
                  <p className="text-slate-600">
                    Your WordPress site is operating at optimal hardware capacity with in-memory Redis caching, image WebP compression, and zero page generation lag.
                  </p>
                </div>
              </div>

              {/* Grid of WordPress Widgets */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                {/* At a Glance Widget */}
                <div className="lg:col-span-6 bg-white rounded-xl border border-slate-300 p-4 shadow-sm space-y-3">
                  <h3 className="font-extrabold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
                    <Gauge className="w-4 h-4 text-blue-600" />
                    <span>At a Glance</span>
                  </h3>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="flex items-center gap-2 text-slate-700">
                      <FileText className="w-4 h-4 text-slate-400" />
                      <span><strong>{posts.length}</strong> Posts</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-700">
                      <FileText className="w-4 h-4 text-slate-400" />
                      <span><strong>6</strong> Pages</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-700">
                      <MessageSquare className="w-4 h-4 text-slate-400" />
                      <span><strong>8</strong> Comments</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-700">
                      <Puzzle className="w-4 h-4 text-slate-400" />
                      <span><strong>{plugins.filter(p => p.active).length}</strong> Active Plugins</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                    Running <strong>WordPress 6.7.2</strong> using <strong>Twenty Twenty-Five</strong> theme on <strong>LiteSpeed Enterprise</strong>.
                  </p>
                </div>

                {/* Quick Draft Widget (Functional Form) */}
                <div className="lg:col-span-6 bg-white rounded-xl border border-slate-300 p-4 shadow-sm space-y-3">
                  <h3 className="font-extrabold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-emerald-600" />
                    <span>Quick Draft</span>
                  </h3>

                  <form onSubmit={handleSaveDraft} className="space-y-2 text-xs">
                    <input
                      type="text"
                      placeholder="Title (e.g. My New WordPress Article)"
                      value={draftTitle}
                      onChange={(e) => setDraftTitle(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 focus:outline-none focus:border-[#2271b1] text-xs"
                      required
                    />
                    <textarea
                      placeholder="What's on your mind?..."
                      rows={2}
                      value={draftContent}
                      onChange={(e) => setDraftContent(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 focus:outline-none focus:border-[#2271b1] text-xs"
                    />
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded-lg bg-[#2271b1] hover:bg-[#135e96] text-white font-bold text-xs shadow-xs active:scale-95 transition-all cursor-pointer"
                    >
                      Save Draft
                    </button>
                  </form>
                </div>
              </div>

              {/* Site Health & Benchmarks */}
              <div className="p-4 rounded-xl bg-white border border-slate-300 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-black text-sm">
                    100%
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900">Site Health Status: Good</h4>
                    <p className="text-[11px] text-slate-500">
                      Zero performance warnings. Redis object caching is responding under 1.2ms.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
                    HTTP/3 QUIC Active
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold">
                    OPcache 100% Hit Rate
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* VIEW 2: POSTS MANAGER */}
          {/* ======================================================== */}
          {activeMenu === 'posts' && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between pb-3 border-b border-slate-300">
                <div>
                  <h2 className="text-2xl font-black text-[#1d2327]">Posts</h2>
                  <p className="text-xs text-slate-500">Manage all articles published on your WordPress instance.</p>
                </div>

                <button
                  onClick={() => {
                    const newTitle = prompt('Enter New Post Title:', 'Scaling WooCommerce on Managed Cloud');
                    if (newTitle) {
                      setPosts([
                        {
                          id: `p_${Date.now()}`,
                          title: newTitle,
                          status: 'Published',
                          author: 'admin',
                          date: 'Just now',
                          comments: 0,
                        },
                        ...posts,
                      ]);
                      showToast(`Published "${newTitle}"!`);
                    }
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-[#2271b1] hover:bg-[#135e96] text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add New Post</span>
                </button>
              </div>

              {/* Table of posts */}
              <div className="bg-white rounded-xl border border-slate-300 overflow-hidden shadow-sm">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#f6f7f7] border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="p-3">Title</th>
                      <th className="p-3">Author</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Comments</th>
                      <th className="p-3">Date</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {posts.map((post) => (
                      <tr key={post.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-3 font-bold text-slate-900">{post.title}</td>
                        <td className="p-3 text-slate-600 font-mono text-[11px]">{post.author}</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              post.status === 'Published'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-amber-50 text-amber-700 border border-amber-200'
                            }`}
                          >
                            {post.status}
                          </span>
                        </td>
                        <td className="p-3 text-slate-600">💬 {post.comments}</td>
                        <td className="p-3 text-slate-500 text-[11px]">{post.date}</td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => handleDeletePost(post.id, post.title)}
                            className="p-1 rounded text-rose-500 hover:bg-rose-50 cursor-pointer"
                            title="Delete Post"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* VIEW 3: PLUGINS MANAGER */}
          {/* ======================================================== */}
          {activeMenu === 'plugins' && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between pb-3 border-b border-slate-300">
                <div>
                  <h2 className="text-2xl font-black text-[#1d2327]">Installed Plugins</h2>
                  <p className="text-xs text-slate-500">Toggle essential speed, cache, design, and commerce extensions.</p>
                </div>
              </div>

              <div className="space-y-3">
                {plugins.map((plugin) => (
                  <div
                    key={plugin.id}
                    className={`p-4 rounded-xl border bg-white shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                      plugin.active ? 'border-l-4 border-l-[#2271b1] border-slate-200' : 'border-slate-200 opacity-70'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-extrabold text-sm text-slate-900">{plugin.name}</h4>
                        <span className="font-mono text-[10px] text-slate-500">v{plugin.version}</span>
                        <span className="px-2 py-0.2 rounded bg-slate-100 text-slate-600 text-[10px] font-bold">
                          {plugin.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600">{plugin.desc}</p>
                    </div>

                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => handleTogglePlugin(plugin.id)}
                        className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95 ${
                          plugin.active
                            ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
                            : 'bg-[#2271b1] hover:bg-[#135e96] text-white'
                        }`}
                      >
                        {plugin.active ? 'Deactivate' : 'Activate'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* VIEW 4: LITESPEED CACHE CONTROLS */}
          {/* ======================================================== */}
          {activeMenu === 'lscache' && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between pb-3 border-b border-slate-300">
                <div>
                  <h2 className="text-2xl font-black text-[#1d2327] flex items-center gap-2">
                    <Flame className="w-6 h-6 text-amber-500" />
                    <span>LiteSpeed Cache Controls</span>
                  </h2>
                  <p className="text-xs text-slate-500">Hardware-accelerated server-level caching controls.</p>
                </div>

                <button
                  onClick={handlePurgeCache}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
                >
                  <Flame className="w-4 h-4 fill-slate-950" />
                  <span>Purge All Caches (0.02s)</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-white border border-slate-300 shadow-sm space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-xs text-slate-900">Object Cache (Redis)</span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                      CONNECTED
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Host: 127.0.0.1:6379 (Unix Socket). Reduces database queries by 85%.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-white border border-slate-300 shadow-sm space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-xs text-slate-900">Image WebP Optimizer</span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                      100% OPTIMIZED
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600">
                    48 Images converted to lossless WebP format. Saved 4.2 MB total weight.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-white border border-slate-300 shadow-sm space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-xs text-slate-900">Critical CSS Generation</span>
                    <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-black">
                      ACTIVE (CCSS)
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Async CSS delivery eliminates render-blocking resources for 99+ mobile score.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* VIEW 5: SETTINGS */}
          {/* ======================================================== */}
          {activeMenu === 'settings' && (
            <div className="space-y-4 animate-fade-in">
              <div className="pb-3 border-b border-slate-300">
                <h2 className="text-2xl font-black text-[#1d2327]">General Settings</h2>
                <p className="text-xs text-slate-500">Configure core WordPress configuration properties.</p>
              </div>

              <div className="bg-white rounded-xl border border-slate-300 p-5 shadow-sm space-y-4 max-w-2xl">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Site Title</label>
                  <input
                    type="text"
                    value={siteTitle}
                    onChange={(e) => setSiteTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:border-[#2271b1] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tagline</label>
                  <input
                    type="text"
                    value={tagline}
                    onChange={(e) => setTagline(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:border-[#2271b1] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Permalinks Structure</label>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs font-mono text-[#2271b1]">
                    https://yourdomain.com<strong>/%postname%/</strong> (SEO Optimized)
                  </div>
                </div>

                <button
                  onClick={() => showToast('WordPress Settings Updated Successfully!')}
                  className="px-5 py-2 rounded-xl bg-[#2271b1] hover:bg-[#135e96] text-white font-bold text-xs shadow-sm cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  if (isFullscreen) {
    return (
      <div className="fixed inset-0 z-50 h-screen w-screen bg-[#f0f0f1] overflow-hidden flex flex-col">
        {toastMessage && (
          <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#1d2327] text-white px-5 py-3 rounded-xl shadow-2xl border border-blue-400 flex items-center gap-3 text-xs font-bold animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{toastMessage}</span>
          </div>
        )}
        {renderWpCore()}
      </div>
    );
  }

  // STANDARD VIEW: REALISTIC LAPTOP MOCKUP FRAME HOUSING THE WORDPRESS DASHBOARD
  return (
    <div className="w-full relative mx-auto group select-none py-1 sm:py-2">
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#1d2327] text-white px-5 py-3 rounded-xl shadow-2xl border border-blue-400 flex items-center gap-3 text-xs font-bold animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. LAPTOP SCREEN LID (MATTE DARK TITANIUM BEZEL + WEBCAM) */}
      <div className="bg-[#0b0e14] rounded-t-[20px] sm:rounded-t-[28px] p-2 sm:p-2.5 pb-0 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.35)] ring-1 ring-slate-800 border-t border-x border-slate-700/80 relative">
        {/* Top Screen Bezel: Window Controls + Center Webcam Lens & Status LED */}
        <div className="h-3.5 sm:h-4 flex items-center justify-between px-2 relative mb-0.5 sm:mb-1">
          {/* Left: Classic Window Action Buttons */}
          <div className="flex items-center gap-1.5 opacity-70 hover:opacity-100 transition-opacity">
            <span className="w-2.5 h-2.5 rounded-full bg-[#ff5f57] border border-[#e0443e] shadow-xs inline-block" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#febc2e] border border-[#d89e24] shadow-xs inline-block" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#28c840] border border-[#1aab29] shadow-xs inline-block" />
          </div>

          {/* Center: HD Webcam with Glass Lens Reflection & Camera LED */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-slate-950/80 ring-1 ring-slate-800 shadow-inner">
              <span className="w-2 h-2 rounded-full bg-black ring-1 ring-slate-700/80 flex items-center justify-center">
                <span className="w-1 h-1 rounded-full bg-slate-800 flex items-center justify-center">
                  <span className="w-0.5 h-0.5 rounded-full bg-blue-400/80" />
                </span>
              </span>
              <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse ring-1 ring-emerald-500/60" title="Webcam active" />
            </div>
          </div>

          <div className="w-8" />
        </div>

        {/* INNER SCREEN DISPLAY (Houses the Functional WordPress Dashboard) */}
        <div className="w-full bg-[#f0f0f1] rounded-t-md sm:rounded-t-lg overflow-hidden flex flex-col h-[320px] sm:h-[350px] lg:h-[370px] xl:h-[390px] border border-slate-300 shadow-inner relative">
          {renderWpCore()}
        </div>

        {/* Bottom Screen Bezel */}
        <div className="h-3 sm:h-3.5 bg-[#0b0e14] flex items-center justify-center border-t border-slate-900" />
      </div>

      {/* 2. LAPTOP CHASSIS & KEYBOARD BASE */}
      <div className="relative w-full">
        {/* Hinge Connection Strip */}
        <div className="w-[96%] mx-auto h-1.5 bg-[#171f2e] border-t border-slate-800 rounded-b-xs" />

        {/* Aluminum Laptop Base Chassis */}
        <div className="-mx-2 sm:-mx-3.5 h-3.5 sm:h-4.5 bg-gradient-to-b from-[#e2e8f0] via-[#cbd5e1] to-[#94a3b8] rounded-b-xl sm:rounded-b-2xl border-t border-slate-200 shadow-xl flex items-start justify-center relative ring-1 ring-slate-400/40">
          {/* Center Thumb Scoop */}
          <div className="w-16 sm:w-24 h-1 sm:h-1.5 bg-slate-500/70 rounded-b-md shadow-inner mx-auto" />
        </div>

        {/* Realistic Desk Shadow */}
        <div className="w-[88%] mx-auto h-3.5 sm:h-4 bg-black/25 blur-lg rounded-full -mt-1 pointer-events-none" />
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  X,
  Server,
  CheckCircle2,
  Terminal,
  Copy,
  CheckCheck,
  ShieldCheck,
  Loader2,
  Sparkles,
} from 'lucide-react';
import { useConfig } from '../context/ConfigContext';

export const DeployServerModal: React.FC = () => {
  const {
    deployModalOpen,
    setDeployModalOpen,
    selectedPlan,
    formatPrice,
    showToast,
  } = useConfig();

  const [selectedOS, setSelectedOS] = useState('ubuntu');
  const [selectedRegion, setSelectedRegion] = useState('mumbai');
  const [hostname, setHostname] = useState('cloud-server-01.local');
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployStep, setDeployStep] = useState(0);
  const [isDeployed, setIsDeployed] = useState(false);
  const [copiedSSH, setCopiedSSH] = useState(false);

  if (!deployModalOpen) return null;

  const osOptions = [
    { id: 'ubuntu', name: 'Ubuntu 24.04 LTS', icon: '🐧', type: 'Linux' },
    { id: 'debian', name: 'Debian 12 Bookworm', icon: '🍥', type: 'Linux' },
    { id: 'windows', name: 'Windows Server 2022', icon: '🪟', type: 'Windows' },
    { id: 'docker', name: 'Docker 26 on Ubuntu', icon: '🐳', type: 'Container' },
    { id: 'wordpress', name: 'WordPress + LiteSpeed', icon: '🌐', type: 'App' },
  ];

  const regions = [
    { id: 'mumbai', name: 'Mumbai, IN', flag: '🇮🇳', ping: '4ms' },
    { id: 'singapore', name: 'Singapore, SG', flag: '🇸🇬', ping: '8ms' },
    { id: 'frankfurt', name: 'Frankfurt, DE', flag: '🇩🇪', ping: '14ms' },
    { id: 'london', name: 'London, UK', flag: '🇬🇧', ping: '12ms' },
    { id: 'newyork', name: 'New York, US', flag: '🇺🇸', ping: '18ms' },
  ];

  const handleStartDeploy = () => {
    setIsDeploying(true);
    setDeployStep(1);

    setTimeout(() => setDeployStep(2), 700);
    setTimeout(() => setDeployStep(3), 1400);
    setTimeout(() => setDeployStep(4), 2100);
    setTimeout(() => {
      setIsDeploying(false);
      setIsDeployed(true);
      showToast('Cloud server successfully deployed & ready!');
    }, 2800);
  };

  const handleClose = () => {
    setDeployModalOpen(false);
    setIsDeploying(false);
    setIsDeployed(false);
    setDeployStep(0);
  };

  const sshCommand = `ssh root@142.250.180.89 -p 22`;

  const copySSH = () => {
    navigator.clipboard.writeText(sshCommand);
    setCopiedSSH(true);
    setTimeout(() => setCopiedSSH(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div
        id="deploy-server-modal-container"
        className="w-full max-w-2xl bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden my-8"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <Server className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base">
                Instant Server Deployment Simulator
              </h3>
              <p className="text-[11px] text-slate-400">
                Plan:{' '}
                <span className="text-cyan-400 font-semibold">
                  {selectedPlan?.name || 'Business Cloud'}
                </span>{' '}
                • {formatPrice(selectedPlan?.priceINR || 169)}/mo
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          {!isDeployed ? (
            <>
              {/* Step 1: Choose OS */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  1. Choose Operating System
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {osOptions.map((os) => (
                    <button
                      key={os.id}
                      type="button"
                      onClick={() => setSelectedOS(os.id)}
                      className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition ${
                        selectedOS === os.id
                          ? 'border-blue-600 bg-blue-50/70 ring-2 ring-blue-500/20'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <span className="text-xl">{os.icon}</span>
                      <div className="min-w-0">
                        <span className="block text-xs font-bold text-slate-900 truncate">
                          {os.name}
                        </span>
                        <span className="text-[10px] text-slate-500 uppercase font-mono">
                          {os.type}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Choose Data Center Region */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  2. Choose Data Center Location
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {regions.map((reg) => (
                    <button
                      key={reg.id}
                      type="button"
                      onClick={() => setSelectedRegion(reg.id)}
                      className={`p-2.5 rounded-xl border text-left flex items-center justify-between gap-2 transition ${
                        selectedRegion === reg.id
                          ? 'border-purple-600 bg-purple-50/70 ring-2 ring-purple-500/20'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-base">{reg.flag}</span>
                        <span className="text-xs font-bold text-slate-900 truncate">
                          {reg.name}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-emerald-600 font-bold">
                        {reg.ping}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 3: Hostname */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  3. Server Hostname
                </label>
                <input
                  type="text"
                  value={hostname}
                  onChange={(e) => setHostname(e.target.value)}
                  placeholder="e.g. app-server-01.com"
                  className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
                />
              </div>

              {/* Deployment Progress Bar during simulation */}
              {isDeploying && (
                <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-3 font-mono text-xs">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-2 text-cyan-400 font-bold">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Provisioning Virtual Machine...</span>
                    </span>
                    <span className="text-slate-400">
                      Step {deployStep} of 4
                    </span>
                  </div>

                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-cyan-400 h-full transition-all duration-500"
                      style={{ width: `${deployStep * 25}%` }}
                    />
                  </div>

                  <div className="text-[11px] text-slate-300 space-y-1">
                    {deployStep >= 1 && <div>✓ Node allocated in {selectedRegion.toUpperCase()}</div>}
                    {deployStep >= 2 && <div>✓ Partitioning NVMe Gen4 SSD (RAID-10)</div>}
                    {deployStep >= 3 && <div>✓ Installing {selectedOS.toUpperCase()} & Kernel modules</div>}
                    {deployStep >= 4 && <div>✓ Dedicated IP assigned: 142.250.180.89</div>}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <div className="text-xs text-slate-500">
                  <ShieldCheck className="w-4 h-4 inline text-emerald-500 mr-1" />
                  Instant automated delivery
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleClose}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={isDeploying}
                    onClick={handleStartDeploy}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-500/25 active:scale-95 disabled:opacity-50 transition"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>{isDeploying ? 'Deploying Server...' : 'Launch Server Now'}</span>
                  </button>
                </div>
              </div>
            </>
          ) : (
            /* Successful Deployment Screen */
            <div className="text-center py-6 space-y-4">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-8 h-8 stroke-[2.5]" />
              </div>

              <div>
                <h4 className="text-xl font-extrabold text-slate-900">
                  Server Provisioned Successfully!
                </h4>
                <p className="text-xs text-slate-600 mt-1">
                  Your cloud instance is live and accepting SSH connections.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 text-white font-mono text-xs text-left space-y-2 max-w-md mx-auto border border-slate-800">
                <div className="flex justify-between text-slate-400 text-[11px] pb-1 border-b border-slate-800">
                  <span>INSTANCE DETAILS</span>
                  <span className="text-emerald-400 font-bold">ACTIVE</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">IP Address:</span>
                  <span className="text-cyan-400 font-bold">142.250.180.89</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Hostname:</span>
                  <span className="text-slate-200">{hostname}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">OS:</span>
                  <span className="text-slate-200">{selectedOS.toUpperCase()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Region:</span>
                  <span className="text-slate-200">{selectedRegion.toUpperCase()}</span>
                </div>
                <div className="pt-2">
                  <span className="text-slate-400 block text-[10px] mb-1">SSH CONNECT:</span>
                  <div className="flex items-center justify-between bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <span className="text-amber-300 select-all">{sshCommand}</span>
                    <button
                      onClick={copySSH}
                      className="text-slate-400 hover:text-white ml-2"
                      title="Copy SSH command"
                    >
                      {copiedSSH ? (
                        <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex justify-center gap-3">
                <button
                  onClick={handleClose}
                  className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-md transition"
                >
                  Close & Continue Browsing
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Server,
  Sliders,
  Menu,
  X,
  ChevronDown,
  Globe,
  Sparkles,
} from 'lucide-react';
import { useConfig } from '../context/ConfigContext';
import { Currency } from '../types/hosting';

export const Header: React.FC = () => {
  const {
    currency,
    setCurrency,
    setAdminOpen,
    openDeployModalWithPlan,
  } = useConfig();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);

  const navLinks = [
    { name: 'Why Us', href: '#why-choose' },
    { name: 'Environments', href: '#environments' },
    { name: 'Steps', href: '#steps' },
    { name: 'Pricing', href: '#pricing' },
    { name: 'Compare', href: '#compare' },
    { name: 'Features', href: '#features' },
    { name: 'Data Centers', href: '#locations' },
    { name: 'Reviews', href: '#reviews' },
  ];

  const handleCurrencyChange = (curr: Currency) => {
    setCurrency(curr);
    setCurrencyDropdownOpen(false);
  };

  return (
    <header
      id="main-header"
      className="sticky top-0 z-40 w-full bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white transition-all"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Logo */}
          <a
            id="brand-logo"
            href="#hero"
            className="flex items-center gap-3 group focus:outline-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/25 group-hover:scale-105 transition-transform">
              <Server className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-xl tracking-tight text-white flex items-center gap-1.5">
                Cloud<span className="text-cyan-400">Host</span>
              </span>
              <span className="text-[10px] text-slate-400 font-medium tracking-wider uppercase">
                Next-Gen Infrastructure
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav
            id="desktop-nav-links"
            className="hidden xl:flex items-center gap-1 bg-slate-800/60 p-1.5 rounded-full border border-slate-700/50"
          >
            {navLinks.map((link) => (
              <a
                key={link.name}
                id={`nav-link-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                href={link.href}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-700/60 rounded-full transition-all"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Currency Selector */}
            <div className="relative">
              <button
                id="currency-selector-btn"
                type="button"
                onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition"
              >
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
                <span>{currency}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {currencyDropdownOpen && (
                <div
                  id="currency-dropdown-menu"
                  className="absolute right-0 mt-2 w-28 bg-slate-800 border border-slate-700 rounded-lg shadow-xl py-1 z-50"
                >
                  {(['INR', 'USD', 'EUR'] as Currency[]).map((c) => (
                    <button
                      key={c}
                      id={`currency-option-${c.toLowerCase()}`}
                      onClick={() => handleCurrencyChange(c)}
                      className={`w-full text-left px-3 py-1.5 text-xs font-medium hover:bg-slate-700 transition flex items-center justify-between ${
                        currency === c ? 'text-cyan-400 bg-slate-750 font-bold' : 'text-slate-200'
                      }`}
                    >
                      <span>{c}</span>
                      <span className="text-slate-400 text-[10px]">
                        {c === 'INR' ? '₹' : c === 'USD' ? '$' : '€'}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Admin Panel CMS & SEO Toggle Button */}
            <button
              id="admin-panel-header-btn"
              onClick={() => setAdminOpen(true)}
              className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 text-amber-300 border border-amber-500/40 rounded-lg transition shadow-sm"
              title="Open Admin CMS & SEO Settings"
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>Admin & SEO CMS</span>
              <span className="px-1.5 py-0.5 text-[9px] bg-amber-500/30 text-amber-200 rounded-full font-bold">
                PRO
              </span>
            </button>

            {/* Client Login */}
            <a
              id="client-portal-btn"
              href="#pricing"
              className="text-xs font-semibold text-slate-300 hover:text-white px-3 py-1.5 transition"
            >
              Client Login
            </a>

            {/* Get Started CTA */}
            <button
              id="header-cta-get-started"
              onClick={() => openDeployModalWithPlan()}
              className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 rounded-lg shadow-md shadow-cyan-500/20 hover:shadow-cyan-500/35 active:scale-95 transition"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Get Started</span>
            </button>
          </div>

          {/* Mobile Hamburger Toggle */}
          <div className="flex items-center gap-2 xl:hidden">
            <button
              id="admin-panel-mobile-quick-btn"
              onClick={() => setAdminOpen(true)}
              className="p-2 text-amber-400 bg-amber-500/10 border border-amber-500/30 rounded-lg"
              title="Admin Panel"
            >
              <Sliders className="w-4 h-4" />
            </button>

            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white bg-slate-800 rounded-lg border border-slate-700"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className="xl:hidden bg-slate-900 border-b border-slate-800 px-4 pt-3 pb-6 space-y-3"
        >
          <div className="grid grid-cols-2 gap-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                id={`mobile-link-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
              >
                {link.name}
              </a>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-800 flex flex-col gap-2.5">
            <div className="flex items-center justify-between px-2">
              <span className="text-xs text-slate-400">Currency</span>
              <div className="flex gap-1">
                {(['INR', 'USD', 'EUR'] as Currency[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => setCurrency(c)}
                    className={`px-2.5 py-1 text-xs rounded font-bold ${
                      currency === c
                        ? 'bg-cyan-500 text-slate-950'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <button
              id="mobile-admin-open-btn"
              onClick={() => {
                setMobileMenuOpen(false);
                setAdminOpen(true);
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-bold"
            >
              <Sliders className="w-4 h-4" />
              <span>Admin Panel & SEO CMS</span>
            </button>

            <button
              id="mobile-cta-get-started"
              onClick={() => {
                setMobileMenuOpen(false);
                openDeployModalWithPlan();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 font-bold rounded-lg text-xs shadow-lg shadow-cyan-500/25"
            >
              <Sparkles className="w-4 h-4" />
              <span>Deploy Cloud Server Now</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

import React, { useState } from 'react';
import {
  X,
  Sliders,
  Search,
  Share2,
  FileText,
  DollarSign,
  Globe,
  Terminal,
  RotateCcw,
  Download,
  Upload,
  Save,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Database,
  Play,
  Copy,
  Table,
  Layers,
} from 'lucide-react';
import { useConfig } from '../context/ConfigContext';
import { SEOConfig, HeroConfig, PricingPlan, HostingCategory } from '../types/hosting';

export const AdminPanelModal: React.FC = () => {
  const {
    config,
    adminOpen,
    setAdminOpen,
    categoryPlans,
    updateCategoryPlans,
    activeCategory,
    setActiveCategory,
    updateSEO,
    updateHero,
    updatePricingPlans,
    resetToDefaults,
    exportConfigJson,
    importConfigJson,
    showToast,
    mySQLSchemas,
    executeMySQLQuery,
    exportMySQLDump,
  } = useConfig();

  const [activeTab, setActiveTab] = useState<'seo' | 'hero' | 'pricing' | 'mysql' | 'backup'>('pricing');
  const [selectedPlanCategory, setSelectedPlanCategory] = useState<HostingCategory>(activeCategory);

  // Local draft states
  const [seoDraft, setSeoDraft] = useState<SEOConfig>(config.seo);
  const [heroDraft, setHeroDraft] = useState<HeroConfig>(config.hero);
  const [pricingDraft, setPricingDraft] = useState<PricingPlan[]>(
    categoryPlans[selectedPlanCategory] || config.pricingPlans
  );

  // MySQL console state
  const [sqlQuery, setSqlQuery] = useState<string>('SELECT * FROM hosting_plans WHERE category = "shared";');
  const [sqlResult, setSqlResult] = useState<{ success: boolean; message: string; rows?: any[] } | null>(null);

  const [jsonImportText, setJsonImportText] = useState('');
  const [jsonError, setJsonError] = useState<string | null>(null);

  // When selectedPlanCategory changes, reload pricingDraft
  React.useEffect(() => {
    setPricingDraft(categoryPlans[selectedPlanCategory] || config.pricingPlans);
  }, [selectedPlanCategory, categoryPlans, config.pricingPlans]);

  // Sync draft when modal opens
  React.useEffect(() => {
    if (adminOpen) {
      setSeoDraft(config.seo);
      setHeroDraft(config.hero);
      setPricingDraft(categoryPlans[selectedPlanCategory] || config.pricingPlans);
      setJsonError(null);
    }
  }, [adminOpen, config, selectedPlanCategory, categoryPlans]);

  if (!adminOpen) return null;

  const handleSaveSEO = (e: React.FormEvent) => {
    e.preventDefault();
    updateSEO(seoDraft);
  };

  const handleSaveHero = (e: React.FormEvent) => {
    e.preventDefault();
    updateHero(heroDraft);
  };

  const handleSavePricing = (e: React.FormEvent) => {
    e.preventDefault();
    updateCategoryPlans(selectedPlanCategory, pricingDraft);
    showToast(`✓ Saved ${selectedPlanCategory.toUpperCase()} pricing plans to database!`);
  };

  const handleRunSQL = () => {
    const res = executeMySQLQuery(sqlQuery);
    setSqlResult(res);
  };

  const handleImportSubmit = () => {
    if (!jsonImportText.trim()) {
      setJsonError('Please paste valid JSON configuration.');
      return;
    }
    const res = importConfigJson(jsonImportText);
    if (!res.success) {
      setJsonError(res.error || 'Failed to parse JSON.');
    } else {
      setJsonError(null);
      setJsonImportText('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div
        id="admin-cms-modal-container"
        className="w-full max-w-5xl bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] my-auto"
      >
        {/* Header Bar */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-[#635bff] flex items-center justify-center text-white font-bold shadow-md">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-extrabold text-base sm:text-lg">
                  Admin CMS &amp; MySQL Control Center
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
                  Connected &amp; Synced
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Manage all 6 hosting pages, customize pricing plans, and query or export the MySQL database.
              </p>
            </div>
          </div>

          <button
            onClick={() => setAdminOpen(false)}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 bg-slate-100/80 border-b border-slate-200 flex items-center gap-2 overflow-x-auto shrink-0 py-2.5">
          <button
            onClick={() => setActiveTab('pricing')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'pricing'
                ? 'bg-white text-purple-700 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <DollarSign className="w-4 h-4 text-purple-600" />
            <span>Pricing Plans &amp; Pages</span>
          </button>

          <button
            onClick={() => setActiveTab('mysql')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'mysql'
                ? 'bg-white text-indigo-700 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database className="w-4 h-4 text-indigo-600" />
            <span>MySQL Database Sync</span>
          </button>

          <button
            onClick={() => setActiveTab('seo')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'seo'
                ? 'bg-white text-blue-600 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Search className="w-4 h-4 text-blue-500" />
            <span>SEO &amp; Social</span>
          </button>

          <button
            onClick={() => setActiveTab('hero')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'hero'
                ? 'bg-white text-blue-600 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4 text-emerald-500" />
            <span>Hero &amp; Texts</span>
          </button>

          <button
            onClick={() => setActiveTab('backup')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'backup'
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Import / Export</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* TAB 1: PRICING PLANS & PAGES SELECTOR */}
          {activeTab === 'pricing' && (
            <form onSubmit={handleSavePricing} className="space-y-6">
              {/* Product Page Selector Pill Bar */}
              <div className="p-4 rounded-2xl bg-purple-50/70 border border-purple-200 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-purple-700" />
                    <span className="font-extrabold text-xs sm:text-sm text-purple-900">
                      Select Page to Edit Pricing &amp; Plans:
                    </span>
                  </div>
                  <span className="text-[11px] text-purple-700 font-bold">
                    Editing: {selectedPlanCategory.toUpperCase()}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 flex-wrap">
                  {(
                    [
                      { id: 'shared', label: 'Shared Hosting' },
                      { id: 'wordpress', label: 'WordPress Hosting' },
                      { id: 'indian', label: 'Indian Hosting' },
                      { id: 'reseller', label: 'Reseller Hosting' },
                      { id: 'cpanel', label: 'cPanel Hosting' },
                      { id: 'business', label: 'Business Webhosting' },
                      { id: 'cloud', label: 'Cloud Hosting' },
                    ] as const
                  ).map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedPlanCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        selectedPlanCategory === cat.id
                          ? 'bg-[#635bff] text-white shadow-xs scale-102'
                          : 'bg-white text-slate-700 hover:bg-slate-100 border border-purple-200'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 4 Editable Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {pricingDraft.map((plan, idx) => (
                  <div
                    key={plan.id}
                    className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <input
                        type="text"
                        value={plan.name}
                        onChange={(e) => {
                          const next = [...pricingDraft];
                          next[idx].name = e.target.value;
                          setPricingDraft(next);
                        }}
                        className="font-black text-sm text-slate-900 border-b border-slate-300 w-full"
                      />
                      <label className="flex items-center gap-1.5 text-xs text-purple-700 shrink-0 font-bold">
                        <input
                          type="checkbox"
                          checked={plan.isPopular || false}
                          onChange={(e) => {
                            const next = pricingDraft.map((p, i) => ({
                              ...p,
                              isPopular: i === idx ? e.target.checked : false,
                            }));
                            setPricingDraft(next);
                          }}
                          className="rounded text-purple-600"
                        />
                        <span>★ Most Popular</span>
                      </label>
                    </div>

                    <input
                      type="text"
                      value={plan.description}
                      onChange={(e) => {
                        const next = [...pricingDraft];
                        next[idx].description = e.target.value;
                        setPricingDraft(next);
                      }}
                      className="w-full text-xs text-slate-600 border-b border-slate-200"
                      placeholder="Subtitle..."
                    />

                    {/* Price & Discounts */}
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <span className="text-[10px] text-slate-500 font-semibold block">
                          Monthly (₹)
                        </span>
                        <input
                          type="number"
                          value={plan.priceINR}
                          onChange={(e) => {
                            const next = [...pricingDraft];
                            next[idx].priceINR = Number(e.target.value);
                            setPricingDraft(next);
                          }}
                          className="w-full px-2 py-1 text-xs font-black rounded border border-slate-300"
                        />
                      </div>

                      <div>
                        <span className="text-[10px] text-slate-500 font-semibold block">
                          Original (₹)
                        </span>
                        <input
                          type="number"
                          value={plan.originalPriceINR}
                          onChange={(e) => {
                            const next = [...pricingDraft];
                            next[idx].originalPriceINR = Number(e.target.value);
                            setPricingDraft(next);
                          }}
                          className="w-full px-2 py-1 text-xs rounded border border-slate-300"
                        />
                      </div>

                      <div>
                        <span className="text-[10px] text-slate-500 font-semibold block">
                          Discount (%)
                        </span>
                        <input
                          type="number"
                          value={plan.discountPercentage}
                          onChange={(e) => {
                            const next = [...pricingDraft];
                            next[idx].discountPercentage = Number(e.target.value);
                            setPricingDraft(next);
                          }}
                          className="w-full px-2 py-1 text-xs rounded border border-purple-300 text-purple-700 font-bold"
                        />
                      </div>
                    </div>

                    {/* Resources */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold">Compute</span>
                        <input
                          type="text"
                          value={plan.specs.vcpu}
                          onChange={(e) => {
                            const next = [...pricingDraft];
                            next[idx].specs.vcpu = e.target.value;
                            setPricingDraft(next);
                          }}
                          className="w-full px-2 py-1 rounded border border-slate-200 text-xs"
                        />
                      </div>

                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold">RAM</span>
                        <input
                          type="text"
                          value={plan.specs.ram}
                          onChange={(e) => {
                            const next = [...pricingDraft];
                            next[idx].specs.ram = e.target.value;
                            setPricingDraft(next);
                          }}
                          className="w-full px-2 py-1 rounded border border-slate-200 text-xs"
                        />
                      </div>

                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold">Storage</span>
                        <input
                          type="text"
                          value={plan.specs.ssd}
                          onChange={(e) => {
                            const next = [...pricingDraft];
                            next[idx].specs.ssd = e.target.value;
                            setPricingDraft(next);
                          }}
                          className="w-full px-2 py-1 rounded border border-slate-200 text-xs"
                        />
                      </div>

                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold">Bandwidth</span>
                        <input
                          type="text"
                          value={plan.specs.bandwidth}
                          onChange={(e) => {
                            const next = [...pricingDraft];
                            next[idx].specs.bandwidth = e.target.value;
                            setPricingDraft(next);
                          }}
                          className="w-full px-2 py-1 rounded border border-slate-200 text-xs"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-between items-center">
                <span className="text-xs text-slate-500 font-mono">
                  Target: {selectedPlanCategory.toUpperCase()} ({pricingDraft.length} tiers)
                </span>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#635bff] hover:bg-[#5249e0] text-white font-bold text-xs sm:text-sm shadow-md"
                >
                  <Save className="w-4 h-4" />
                  <span>Save {selectedPlanCategory.toUpperCase()} Plans</span>
                </button>
              </div>
            </form>
          )}

          {/* TAB 2: MYSQL DATABASE & SCHEMA SYNC */}
          {activeTab === 'mysql' && (
            <div className="space-y-6">
              {/* Header with Export Dump button */}
              <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                    <Database className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-indigo-950">
                      MySQL Database &amp; Data Layer Sync
                    </h3>
                    <p className="text-xs text-indigo-800">
                      Database: <code className="font-mono font-bold">cloudhost_production</code> · 4 Relational Tables Active
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={exportMySQLDump}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>Export .sql Dump</span>
                  </button>
                  <button
                    onClick={() => showToast('✓ Synced with in-memory relational store!')}
                    className="px-3.5 py-2 rounded-xl bg-white border border-indigo-300 text-indigo-700 font-bold text-xs hover:bg-indigo-50"
                  >
                    Sync Schema
                  </button>
                </div>
              </div>

              {/* Table Schema Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {mySQLSchemas.map((table) => (
                  <div
                    key={table.tableName}
                    className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs font-black text-slate-800">
                        {table.tableName}
                      </span>
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-slate-100 text-slate-600">
                        {table.rowCount} rows
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      {table.columns.length} columns (
                      {table.columns.map((c) => c.field).slice(0, 3).join(', ')}...)
                    </div>
                  </div>
                ))}
              </div>

              {/* Interactive SQL Query Console */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black uppercase tracking-wider text-slate-800">
                    Live SQL Query Console
                  </label>
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="text-slate-400">Quick Templates:</span>
                    <button
                      type="button"
                      onClick={() => setSqlQuery('SELECT * FROM hosting_plans WHERE category = "wordpress";')}
                      className="text-indigo-600 hover:underline font-mono"
                    >
                      WP Plans
                    </button>
                    <span>·</span>
                    <button
                      type="button"
                      onClick={() => setSqlQuery('SELECT * FROM customer_accounts;')}
                      className="text-indigo-600 hover:underline font-mono"
                    >
                      Customers
                    </button>
                  </div>
                </div>

                <div className="relative">
                  <textarea
                    rows={3}
                    value={sqlQuery}
                    onChange={(e) => setSqlQuery(e.target.value)}
                    className="w-full p-3 rounded-xl bg-slate-950 text-emerald-400 font-mono text-xs border border-slate-800 focus:outline-hidden"
                  />
                  <button
                    onClick={handleRunSQL}
                    className="absolute bottom-3 right-3 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Run Query</span>
                  </button>
                </div>

                {/* SQL Result Table / Output */}
                {sqlResult && (
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono space-y-3 animate-fade-in">
                    <div className="flex justify-between items-center pb-2 border-b border-slate-800 text-emerald-400 font-bold">
                      <span>{sqlResult.message}</span>
                      <span className="text-[10px] text-slate-500">Output Window</span>
                    </div>

                    {sqlResult.rows && sqlResult.rows.length > 0 && (
                      <div className="overflow-x-auto max-h-48">
                        <table className="w-full text-left text-[11px]">
                          <thead className="text-slate-400 border-b border-slate-800">
                            <tr>
                              {Object.keys(sqlResult.rows[0]).map((key) => (
                                <th key={key} className="p-2 font-bold uppercase">
                                  {key}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800">
                            {sqlResult.rows.map((row, rIdx) => (
                              <tr key={rIdx} className="hover:bg-slate-800/40">
                                {Object.values(row).map((val: any, cIdx) => (
                                  <td key={cIdx} className="p-2 truncate max-w-xs text-slate-300">
                                    {String(val)}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: SEO & SOCIAL PREVIEWS */}
          {activeTab === 'seo' && (
            <form onSubmit={handleSaveSEO} className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-7 space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Meta Title
                    </label>
                    <input
                      type="text"
                      value={seoDraft.metaTitle}
                      onChange={(e) => setSeoDraft({ ...seoDraft, metaTitle: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Meta Description
                    </label>
                    <textarea
                      rows={3}
                      value={seoDraft.metaDescription}
                      onChange={(e) => setSeoDraft({ ...seoDraft, metaDescription: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Keywords
                    </label>
                    <input
                      type="text"
                      value={seoDraft.metaKeywords}
                      onChange={(e) => setSeoDraft({ ...seoDraft, metaKeywords: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                    />
                  </div>
                </div>

                {/* Google Snippet preview */}
                <div className="lg:col-span-5 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                  <span className="font-bold text-slate-700 block uppercase tracking-wider text-[10px]">
                    Google Search Snippet Preview
                  </span>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-blue-700 font-bold block text-sm truncate">
                      {seoDraft.metaTitle}
                    </span>
                    <span className="text-[11px] text-emerald-700 block">
                      https://cloudhost.io
                    </span>
                    <p className="text-[11px] text-slate-600 line-clamp-2 mt-1">
                      {seoDraft.metaDescription}
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md"
                >
                  <Save className="w-4 h-4" />
                  <span>Save SEO Changes</span>
                </button>
              </div>
            </form>
          )}

          {/* TAB 4: HERO & TEXTS */}
          {activeTab === 'hero' && (
            <form onSubmit={handleSaveHero} className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Top Pill Badge
                </label>
                <input
                  type="text"
                  value={heroDraft.badge}
                  onChange={(e) => setHeroDraft({ ...heroDraft, badge: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Main Subtitle
                </label>
                <textarea
                  rows={2}
                  value={heroDraft.subtitle}
                  onChange={(e) => setHeroDraft({ ...heroDraft, subtitle: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Hero Changes</span>
                </button>
              </div>
            </form>
          )}

          {/* TAB 5: BACKUP & EXPORT */}
          {activeTab === 'backup' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">Download Configuration JSON</h3>
                  <p className="text-xs text-slate-500">
                    Export all your customized plans, texts, SEO tags, and categories.
                  </p>
                </div>
                <button
                  onClick={exportConfigJson}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Backup</span>
                </button>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700">
                  Import Configuration JSON
                </label>
                <textarea
                  rows={4}
                  value={jsonImportText}
                  onChange={(e) => setJsonImportText(e.target.value)}
                  placeholder="Paste JSON configuration export here..."
                  className="w-full p-3 rounded-xl border border-slate-300 text-xs font-mono"
                />
                {jsonError && (
                  <span className="text-xs text-rose-600 font-bold block">{jsonError}</span>
                )}
                <div className="flex justify-between items-center pt-2">
                  <button
                    onClick={resetToDefaults}
                    type="button"
                    className="flex items-center gap-1.5 text-xs text-rose-600 hover:underline font-bold"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset All to Defaults</span>
                  </button>
                  <button
                    onClick={handleImportSubmit}
                    className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs"
                  >
                    Restore from JSON
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Check, ArrowRight } from 'lucide-react';
import { useConfig } from '../context/ConfigContext';
import { TuxPenguin, TechLogo } from './Illustrations';

export const EnvironmentsSection: React.FC = () => {
  const { config, openDeployModalWithPlan } = useConfig();
  const { environments } = config;
  const [activeTabId, setActiveTabId] = useState<string>(environments[0]?.id || 'linux');

  const activeEnv = environments.find((e) => e.id === activeTabId) || environments[0];

  return (
    <div
      id="environments-card"
      className="rounded-3xl bg-white border border-slate-200/80 p-6 sm:p-7 shadow-sm h-full flex flex-col justify-between"
    >
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
          Choose Your Cloud Environment
        </h2>
        <p className="mt-1 text-xs text-slate-500">
          Deploy your favorite stack with one click.
        </p>
      </div>

      {/* Tabs Row */}
      <div className="flex items-center gap-2 overflow-x-auto py-4 no-scrollbar">
        {environments.map((env) => {
          const isActive = env.id === activeTabId;
          return (
            <button
              key={env.id}
              id={`env-tab-${env.id}`}
              onClick={() => setActiveTabId(env.id)}
              className={`flex flex-col items-center justify-center p-2.5 rounded-2xl min-w-[68px] sm:min-w-[76px] transition-all duration-200 ${
                isActive
                  ? 'bg-[#635bff] text-white shadow-md shadow-indigo-500/25 scale-105'
                  : 'bg-slate-50 border border-slate-200/70 text-slate-600 hover:bg-slate-100/80'
              }`}
            >
              <div className="w-6 h-6 flex items-center justify-center mb-1">
                <TechLogo name={env.name} className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-bold whitespace-nowrap">
                {env.name}
              </span>
            </button>
          );
        })}
      </div>

      {/* Inner Deployment & Terminal Panel */}
      <div className="rounded-2xl bg-slate-50/80 border border-slate-200/80 p-5 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Left Sub-Panel: Mascot & Details */}
        <div className="md:col-span-6 flex items-start gap-4">
          {/* Mascot Graphic */}
          <div className="shrink-0 pt-1">
            {activeEnv.id === 'linux' ? (
              <TuxPenguin className="w-16 h-16 sm:w-20 sm:h-20" />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-center">
                <TechLogo name={activeEnv.name} className="w-10 h-10" />
              </div>
            )}
          </div>

          {/* Info & Bullets */}
          <div className="space-y-2">
            <h3 className="text-base font-extrabold text-slate-900">
              {activeEnv.title}
            </h3>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              {activeEnv.description}
            </p>

            <div className="space-y-1 pt-1">
              {activeEnv.highlights.slice(0, 3).map((item, idx) => (
                <div key={idx} className="flex items-center gap-1.5 text-[11px] text-slate-700">
                  <Check className="w-3 h-3 text-emerald-600 stroke-[3] shrink-0" />
                  <span>{item.split('(')[0].trim()}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => openDeployModalWithPlan()}
              className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#635bff] hover:bg-[#5249e0] text-white font-bold text-xs shadow-sm transition"
            >
              <span>{activeEnv.ctaText}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Right Sub-Panel: Realistic Dark Terminal Box */}
        <div className="md:col-span-6">
          <div className="rounded-2xl bg-[#0b102b] border border-slate-800 p-4 font-mono text-xs shadow-inner">
            {/* Window control dots */}
            <div className="flex items-center gap-1.5 pb-3 border-b border-slate-800/80 mb-3">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="text-[10px] text-slate-500 ml-2 font-mono">bash - cloud-node</span>
            </div>

            {/* Terminal Commands */}
            <div className="space-y-1 text-slate-300 text-[11px]">
              {activeEnv.terminalCommands.map((cmd, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="text-cyan-400 font-bold">$</span>
                  <span className="text-slate-300">{cmd.replace(/^\$\s*/, '')}</span>
                </div>
              ))}
              <div className="pt-2 text-emerald-400 font-semibold flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>{activeEnv.successMessage.replace(/^[✓\s]+/, '')}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Star,
  CheckCircle2,
  Mail,
  AtSign,
  Sparkles,
  Share2,
  Globe,
  Smartphone,
  Calendar,
  Users,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  FileText,
  Layers,
  Ban,
  Clock,
  CheckCheck,
  HardDrive,
  Send,
  Palette,
  Search,
  ArrowRight,
  ExternalLink,
  Zap,
  HelpCircle,
  Bot,
  MailCheck,
  ShieldAlert,
  Briefcase,
  Building2,
  Award,
  RefreshCw,
  Inbox,
  PenTool,
  BookmarkCheck,
} from 'lucide-react';
import { FunctionalTitanEmailDashboard } from '../dashboards/FunctionalTitanEmailDashboard';

interface BusinessEmailPageProps {
  onAddToCart: (item: {
    name: string;
    quantity: string;
    price: string;
    rawPrice: number;
    regularPrice: string;
    discount: string;
    rate: string;
    hasEnterprisePerks: boolean;
  }) => void;
}

interface PlanBaseData {
  key: string;
  name: string;
  regAnnual: number;
  offerAnnual: number;
  pid: number;
  storage: string;
  aliases: number;
  recommended?: boolean;
  summaryFeatures: string[];
  hiddenFeatures: string[];
}

export const BusinessEmailPage: React.FC<BusinessEmailPageProps> = ({ onAddToCart }) => {
  // Term selection (1 to 10 years) for each plan
  const [selectedTerms, setSelectedTerms] = useState<Record<string, number>>({
    'pro-light': 1,
    'pro-plus': 1,
    'premium': 1,
    'ultra': 1,
  });

  // Toggled "View All Features" per card
  const [expandedFeatures, setExpandedFeatures] = useState<Record<string, boolean>>({
    'pro-plus': true,
  });

  // Interactive Tab State ("For Startups" vs "For Agencies")
  const [activeWorkflowTab, setActiveWorkflowTab] = useState<'startups' | 'agencies'>('startups');

  // FAQ open index or set
  const [openFaqs, setOpenFaqs] = useState<Record<number, boolean>>({
    0: true,
    1: true,
  });
  const [faqSearch, setFaqSearch] = useState('');

  // Discount calculation based on exact prompt logic:
  // 1 yr: 0%, 2 yrs: 5%, 3 yrs: 10%, 4 yrs: 12%, 5 yrs: 15%, 6 yrs: 18%, 7 yrs: 20%, 8 yrs: 22%, 9 yrs: 24%, 10 yrs: 25%
  const getExtraDiscount = (years: number): number => {
    if (years === 1) return 0.00;
    if (years === 2) return 0.05;
    if (years === 3) return 0.10;
    if (years === 4) return 0.12;
    if (years === 5) return 0.15;
    if (years === 6) return 0.18;
    if (years === 7) return 0.20;
    if (years === 8) return 0.22;
    if (years === 9) return 0.24;
    if (years >= 10) return 0.25;
    return 0;
  };

  const plansData: PlanBaseData[] = [
    {
      key: 'pro-light',
      name: 'Pro Light',
      regAnnual: 468,
      offerAnnual: 299,
      pid: 101,
      storage: '10 GB',
      aliases: 50,
      summaryFeatures: [
        '10 GB email storage per user (approx. 50,000 emails)',
        '50 Email Aliases (Per User/Mailbox)',
        'One-click import of emails and contacts',
      ],
      hiddenFeatures: [
        'Email Forwarding & Auto-Redirects',
        'Web Access via Browser Webmail',
        'Mobile apps for iOS and Android',
        'Gmail & Outlook Integration',
        'Thunderbird Integration',
        'Transactional SMTP & IMAP/POP3',
        'Built-in Calendar and Contacts app',
        'Shared calendars and contacts with your team',
        'Advanced Anti-Spam and Anti-Virus tools',
      ],
    },
    {
      key: 'pro-plus',
      name: 'Pro Plus',
      regAnnual: 1068,
      offerAnnual: 499,
      pid: 102,
      storage: '30 GB',
      aliases: 50,
      recommended: true,
      summaryFeatures: [
        '30 GB email storage per user (approx. 150,000 emails)',
        '50 Email Aliases (Per User/Mailbox)',
        'Undo Send (Recall sent emails within 10s)',
      ],
      hiddenFeatures: [
        'Everything in Pro Light, plus:',
        'Block Sender and Allowlists',
        'Smart Write (Titan AI) – 5 responses/month',
        'AI Summary – 5 responses/month',
        'Auto Clean & Junk Eliminator',
        'Send Later (Scheduled Delivery)',
        '25 Real-Time Read Receipts',
        'Grammar and Spell Check',
        'Invoice Builder – Save up to 5 templates',
        '5 GB Titan Drive Cloud Storage',
        'Business Auto-Reply & Out of Office',
      ],
    },
    {
      key: 'premium',
      name: 'Premium',
      regAnnual: 1788,
      offerAnnual: 699,
      pid: 103,
      storage: '50 GB',
      aliases: 50,
      summaryFeatures: [
        '50 GB email storage per user (approx. 250,000 emails)',
        '50 Email Aliases (Per User/Mailbox)',
        'Unlimited Read Receipts (Open Tracking)',
      ],
      hiddenFeatures: [
        'Everything in Pro Plus, plus:',
        'Smart Write (Titan AI) – 20 responses/month',
        'AI Summary – 10 responses/month',
        'Unlimited Email Templates & Canned Snippets',
        'Contact Groups & Distribution Lists',
        'Priority VIP Inbox sorting',
        'Invoice Builder – Save up to 10 templates',
        '25 GB Titan Drive Cloud Storage',
        'Email Designer – 1 custom template',
        'Custom Brand Logo & Whitelabel portal',
      ],
    },
    {
      key: 'ultra',
      name: 'Ultra',
      regAnnual: 3228,
      offerAnnual: 999,
      pid: 104,
      storage: '100 GB',
      aliases: 50,
      summaryFeatures: [
        '100 GB email storage per user (approx. 500,000 emails)',
        '50 Email Aliases (Per User/Mailbox)',
        'Email Marketing Campaigns & Broadcasts',
      ],
      hiddenFeatures: [
        'Everything in Premium, plus:',
        'Smart Write (Titan AI) – Unlimited responses',
        'AI Summary – Unlimited responses',
        'Advanced Email Tracking (File & Link Tracking)',
        'Interactive Signature Designer',
        'Email Designer – Unlimited templates',
        '50 GB Titan Drive Cloud Storage',
        'Invoice Builder – Unlimited templates',
        'Appointment Booking & Calendar Scheduler',
      ],
    },
  ];

  const handleTermChange = (planKey: string, years: number) => {
    setSelectedTerms((prev) => ({
      ...prev,
      [planKey]: years,
    }));
  };

  const toggleFeatures = (planKey: string) => {
    setExpandedFeatures((prev) => ({
      ...prev,
      [planKey]: !prev[planKey],
    }));
  };

  const toggleFaq = (index: number) => {
    setOpenFaqs((prev) => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  // FAQ List matching the exact 17 items from user's brief
  const faqData = [
    {
      q: 'What is a business email address and why do I need one?',
      a: 'A business email uses your own custom domain (e.g., info@yourcompany.com) instead of a free provider like Gmail or Yahoo. It builds instant credibility, looks professional to clients, and helps establish your brand identity.',
      category: 'Basics & Identity',
    },
    {
      q: 'How do I set up my business email on a desktop client like Outlook?',
      a: 'To configure Outlook, go to File > Add Account. Enter your business email address and select "Advanced options" to set it up manually. You will need to enter your incoming server details (we recommend IMAP over POP3 for syncing across devices) and outgoing (SMTP) server details provided in your welcome email.',
      category: 'Desktop Configuration',
    },
    {
      q: 'How do I set up my business email on an Android smartphone?',
      a: 'Open your device Settings, navigate to Accounts > Add Account, and choose "Personal (IMAP)". Enter your full email address and password. The system will auto-detect the server settings, but if prompted, input the incoming (IMAP) and outgoing (SMTP) server hostnames to securely connect your mobile email client.',
      category: 'Mobile Setup',
    },
    {
      q: 'How do I add professional email DNS records in my hosting panel?',
      a: 'Log into your hosting control panel (like cPanel) and navigate to the "DNS Zone Editor". You must add MX records to route your incoming mail to our servers. Additionally, we highly recommend adding TXT records for SPF, DKIM, and DMARC to authenticate your emails and ensure they land in the recipient\'s inbox, not the spam folder.',
      category: 'DNS & Deliverability',
    },
    {
      q: 'Can I migrate my existing emails from Google Workspace or Office 365?',
      a: 'Yes! We provide a seamless migration tool that securely transfers all your existing emails, folders, contacts, and calendar events from any standard IMAP provider with zero downtime or data loss.',
      category: 'Migration',
    },
    {
      q: 'What happens if I buy a 10-year email plan?',
      a: 'You lock in our maximum discount rate (up to 25% extra savings) for the entire decade. This protects you against any future price hikes, eliminates annual renewal hassles, and ensures your business communications remain active and secure long-term.',
      category: 'Long-Term Savings',
    },
    {
      q: 'Is my email data secure and protected from spam?',
      a: 'Absolutely. All data is protected with industry-standard SSL/TLS encryption. Our premium email also includes advanced anti-spam and anti-virus filters to block malicious emails, phishing attempts, and unwanted clutter before they reach your inbox.',
      category: 'Security & Spam',
    },
    {
      q: 'Can I create email aliases like sales@ or support@?',
      a: 'Yes, you can create up to 50 free email aliases and forwarders per user. Any message sent to an alias (e.g., support@yourdomain.com) will automatically be delivered directly to your main primary inbox, keeping your operations streamlined.',
      category: 'Email Aliases',
    },
    {
      q: 'Do you provide a Webmail interface for browser access?',
      a: 'Yes, your account includes a clean, ultra-responsive webmail portal. You can securely log in from any web browser worldwide to send messages, manage folders, schedule meetings, and access your contacts without needing to install any software.',
      category: 'Webmail Access',
    },
    {
      q: 'What happens if I run out of storage space?',
      a: 'You will receive an alert before you reach your storage limit. You can easily upgrade your mailbox storage capacity (from 10GB to 30GB, 50GB, or 100GB) at any time directly from your client dashboard with just a few clicks, ensuring no disruption to your service.',
      category: 'Storage & Upgrades',
    },
    {
      q: 'What is an Email Alias?',
      a: 'An alias is simply a "nickname" for your main email inbox. For example, if your main email is info@yourdomain.com, you can create an alias like sales@yourdomain.com. Any email sent to sales@ will land directly inside your main info@ inbox.',
      category: 'Alias Definition',
    },
    {
      q: 'Do I have to pay extra money to create an alias?',
      a: 'No, it is completely free. You do not need to buy a new email account for different departments (like Sales, Support, or HR). You can create up to 50 aliases inside your single, existing email plan.',
      category: 'Alias Pricing',
    },
    {
      q: 'Can I send or reply to emails using my alias address?',
      a: 'Yes, you can. When writing a new email or replying to a client, you can click on the "From" field and choose your alias (e.g., sales@). The customer will only see the alias address, keeping your main email address private.',
      category: 'Alias Sending',
    },
    {
      q: 'Can I get a separate login and password for each alias?',
      a: 'No. An alias is not a real, independent mailbox. It does not have its own password or separate inbox. You must always log in using your main email address and password.',
      category: 'Alias Security',
    },
    {
      q: 'I want to give an email account to my employee. Should I use an alias?',
      a: 'No, an alias will not work for this. Since aliases share the same inbox, your employee would see all your private emails. For a team member, you need to buy a separate User Account (Additional Mailbox) so they get their own private login and password.',
      category: 'Team Management',
    },
    {
      q: 'What is the difference between an "Alias" and a "Catch-all" email?',
      a: 'Email Alias: You choose a specific name (like support@). It only receives emails when people type that exact address correctly. It is highly secure. Catch-all: It catches everything. If a customer makes a spelling mistake (like suuport@ or xyz@), the email does not bounce back. It still delivers to you. However, it can also attract spam.',
      category: 'Catch-All vs Alias',
    },
    {
      q: 'How do I stop alias emails from getting mixed up in my main inbox?',
      a: 'You can easily organize them by setting up "Rules" or "Filters" inside your email dashboard. For example, you can create a rule that automatically moves all emails sent to sales@ into a specific folder named "Sales".',
      category: 'Inbox Organization',
    },
  ];

  const filteredFaqs = faqData.filter(
    (f) =>
      f.q.toLowerCase().includes(faqSearch.toLowerCase()) ||
      f.a.toLowerCase().includes(faqSearch.toLowerCase()) ||
      f.category.toLowerCase().includes(faqSearch.toLowerCase())
  );

  return (
    <div className="space-y-12 animate-fade-in bg-white text-slate-900 pb-16 font-sans">
      {/* ========================================================================= */}
      {/* 1. HERO SECTION (2-Column Split: Content on Left, Live Dashboard on Right) */}
      {/* ========================================================================= */}
      <section className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-[#eef0f7] via-[#f8fafc] to-white border border-slate-200 shadow-sm p-4 sm:p-6 lg:p-8">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#3B3B6D]/5 rounded-full blur-3xl -mr-32 -mt-32 pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center">
          {/* LEFT SIDE: HERO CONTENT (6 Columns on lg/xl - Balanced layout) */}
          <div className="lg:col-span-6 space-y-4 sm:space-y-5">
            {/* Rating Box */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-slate-200 shadow-xs">
              <div className="flex items-center text-amber-400">
                <Star className="w-4 h-4 fill-amber-400" />
                <Star className="w-4 h-4 fill-amber-400" />
                <Star className="w-4 h-4 fill-amber-400" />
                <Star className="w-4 h-4 fill-amber-400" />
                <Star className="w-4 h-4 fill-amber-400" />
              </div>
              <span className="text-xs font-black text-slate-800">4.8/5 Trustpilot Rated</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-tight">
              Business Email for <br />
              <span className="text-[#3B3B6D] underline decoration-[#facc15] decoration-wavy decoration-2">
                Professionals
              </span>
            </h1>

            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              Build trust with every email you send. Secure, fast, and feature-rich email hosting designed to scale with your team — featuring Titan AI writing, real-time read receipts, and zero-spam inboxes.
            </p>

            {/* Value Checkmarks */}
            <ul className="grid grid-cols-2 gap-2 sm:gap-2.5 text-xs font-bold text-slate-700">
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#3B3B6D] shrink-0" />
                <span>99.9% Uptime SLA</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#3B3B6D] shrink-0" />
                <span>AI Writing Assistant</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#3B3B6D] shrink-0" />
                <span>Custom Domain Email</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#3B3B6D] shrink-0" />
                <span>Free 50 Aliases</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#3B3B6D] shrink-0" />
                <span>Zero-Spam Inbox</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#3B3B6D] shrink-0" />
                <span>Outlook &amp; Gmail Sync</span>
              </li>
            </ul>

            {/* CTAs */}
            <div className="pt-1 sm:pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <a
                href="#pricing-section"
                className="px-6 py-3.5 rounded-xl bg-[#3B3B6D] hover:bg-[#2C2C52] text-white font-extrabold text-xs sm:text-sm shadow-lg shadow-[#3B3B6D]/25 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>View Pricing Plans</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* RIGHT SIDE: LIVE EMAIL DASHBOARD INSIDE COMPACT LAPTOP MOCKUP (6 Columns on lg/xl) */}
          <div className="lg:col-span-6 w-full flex justify-center items-center">
            <div className="w-full flex justify-center">
              <FunctionalTitanEmailDashboard />
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 2. DYNAMIC 1 TO 10 YEARS PRICING GRID (WITH ACCORDION FEATURES) */}
      {/* ========================================================================= */}
      <section id="pricing-section" className="space-y-6 scroll-mt-20">
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Do more with powerful email that builds your brand
          </h2>
          <p className="text-slate-500 text-sm sm:text-base">
            Lock in up to 10 years and save massive amounts. No hidden fees, cancel anytime.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 items-stretch">
          {plansData.map((plan) => {
            const currentYears = selectedTerms[plan.key] || 1;
            const extraDisc = getExtraDiscount(currentYears);
            const currentYearlyOffer = Math.round(plan.offerAnnual * (1 - extraDisc));

            const totalRegular = plan.regAnnual * currentYears;
            const totalOffer = currentYearlyOffer * currentYears;
            const savingPercentage = Math.round(((totalRegular - totalOffer) / totalRegular) * 100);

            const isExpanded = Boolean(expandedFeatures[plan.key]);

            return (
              <div
                key={plan.key}
                className={`rounded-2xl bg-white border flex flex-col justify-between transition-all duration-300 relative shadow-sm hover:shadow-xl ${
                  plan.recommended
                    ? 'border-2 border-[#3B3B6D] shadow-[#3B3B6D]/10 transform lg:-translate-y-1.5'
                    : 'border-slate-200 hover:border-[#3B3B6D]'
                }`}
              >
                {/* Recommended Badge */}
                {plan.recommended && (
                  <div className="bg-[#3B3B6D] text-white text-[11px] font-extrabold tracking-wider uppercase text-center py-1.5 rounded-t-xl">
                    RECOMMENDED
                  </div>
                )}

                <div className="p-6 space-y-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-2xl font-black text-slate-900">{plan.name}</h3>

                    {/* 1 to 10 Years Dropdown Term Selector */}
                    <div className="mt-3">
                      <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                        Select Term:
                      </label>
                      <select
                        value={currentYears}
                        onChange={(e) => handleTermChange(plan.key, Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-slate-50 text-xs font-bold text-slate-800 focus:outline-none focus:border-[#3B3B6D] cursor-pointer"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((y) => {
                          const disc = getExtraDiscount(y);
                          const yOffer = Math.round(plan.offerAnnual * (1 - disc));
                          const totReg = plan.regAnnual * y;
                          const totOff = yOffer * y;
                          const pct = Math.round(((totReg - totOff) / totReg) * 100);
                          const suffix = y > 1 ? 's' : '';
                          return (
                            <option key={y} value={y}>
                              {y} Year{suffix} (Save {pct}%)
                            </option>
                          );
                        })}
                      </select>
                    </div>

                    {/* Pricing Box */}
                    <div className="pt-4 pb-4 border-b border-dashed border-slate-200 space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400 line-through font-mono">
                          Reg: ₹{totalRegular} for {currentYears} {currentYears > 1 ? 'Yrs' : 'Yr'}
                        </span>
                        <span className="px-2 py-0.5 rounded-md bg-[#eef0f7] text-[#3B3B6D] text-[11px] font-black">
                          Save {savingPercentage}%
                        </span>
                      </div>

                      <div className="flex items-baseline gap-1 pt-1">
                        <span className="text-xl font-bold text-slate-900">₹</span>
                        <span className="text-4xl font-black text-slate-900 tracking-tight">
                          {currentYearlyOffer}
                        </span>
                        <span className="text-xs text-slate-500 font-medium">/yr / user</span>
                      </div>

                      <p className="text-xs font-bold text-[#3B3B6D] pt-1">
                        Total Term Price: ₹{totalOffer} (For {currentYears} {currentYears > 1 ? 'Yrs' : 'Yr'})
                      </p>
                    </div>

                    {/* Add to Cart Button */}
                    <div className="pt-4">
                      <button
                        onClick={() =>
                          onAddToCart({
                            name: `Business Email - ${plan.name} (${currentYears} ${
                              currentYears > 1 ? 'Years' : 'Year'
                            })`,
                            quantity: `${plan.storage} Storage / 50 Aliases`,
                            price: `₹${totalOffer}`,
                            rawPrice: totalOffer,
                            regularPrice: `₹${totalRegular}`,
                            discount: `${savingPercentage}% OFF`,
                            rate: `₹${currentYearlyOffer}/yr`,
                            hasEnterprisePerks: true,
                          })
                        }
                        className={`w-full py-3.5 rounded-xl font-extrabold text-sm transition-all shadow-md active:scale-95 cursor-pointer ${
                          plan.recommended
                            ? 'bg-[#3B3B6D] hover:bg-[#2C2C52] text-white shadow-[#3B3B6D]/30'
                            : 'bg-slate-900 hover:bg-[#3B3B6D] text-white'
                        }`}
                      >
                        Add to Cart
                      </button>
                    </div>

                    {/* Summary Features List */}
                    <ul className="pt-4 space-y-2.5 text-xs text-slate-700">
                      {plan.summaryFeatures.map((feat, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-[#3B3B6D] shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>

                    {/* View All Features Toggle Button */}
                    <button
                      type="button"
                      onClick={() => toggleFeatures(plan.key)}
                      className="mt-3 text-xs font-black text-[#3B3B6D] hover:text-slate-900 flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>{isExpanded ? 'Hide Extra Features' : 'View All Features'}</span>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>

                    {/* Hidden Features Dropdown */}
                    {isExpanded && (
                      <ul className="mt-3 pt-3 border-t border-slate-100 space-y-2 text-xs text-slate-600 animate-fade-in">
                        {plan.hiddenFeatures.map((feat, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-[#3B3B6D] font-bold">•</span>
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 3. PRICE COMPARISON TABLE (GITYSOFT VS GODADDY, HOSTINGER, ETC.) */}
      {/* ========================================================================= */}
      <section className="rounded-3xl bg-slate-50 border border-slate-200/90 p-6 sm:p-10 space-y-6">
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Gitysoft <span className="text-amber-600">Vs</span> Other Competitors' Pricing (Per Email)
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Compare our direct transparent pricing with leading industry providers. See how much you save every year.
          </p>
        </div>

        {/* Desktop Comparison Table */}
        <div className="hidden lg:block overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
          <table className="w-full text-center text-xs divide-y divide-slate-200">
            <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[11px]">
              <tr>
                <th className="p-3 text-left font-black">Plan</th>
                <th className="p-3 bg-[#fffcdb] border-x-2 border-t-2 border-[#facc15] text-[#854d0e] font-black text-sm">
                  Gitysoft ★
                </th>
                <th className="p-3">GoDaddy</th>
                <th className="p-3">Bigrock</th>
                <th className="p-3">Hostinger</th>
                <th className="p-3">Resellerclub</th>
                <th className="p-3">Name.com</th>
                <th className="p-3">WHOIS.com</th>
                <th className="p-3">Namesilo</th>
                <th className="p-3">Hostgator</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              <tr className="hover:bg-slate-50/50">
                <td className="p-3.5 text-left font-extrabold text-slate-900">10 GB Plan</td>
                <td className="p-3.5 bg-[#fffcdb] border-x-2 border-[#facc15] font-black text-amber-900 text-sm">
                  ₹299/-Year
                </td>
                <td className="p-3.5 text-slate-600">₹552/-Year</td>
                <td className="p-3.5 text-slate-600">₹637/-Year</td>
                <td className="p-3.5 text-slate-600">₹690/-Year</td>
                <td className="p-3.5 text-slate-600">₹648/-Year</td>
                <td className="p-3.5 text-slate-600">₹2,366/-Year</td>
                <td className="p-3.5 text-slate-600">₹1,470/-Year</td>
                <td className="p-3.5 text-slate-600">₹2,908/-Year</td>
                <td className="p-3.5 text-slate-600">₹1,913/-Year</td>
              </tr>
              <tr className="hover:bg-slate-50/50">
                <td className="p-3.5 text-left font-extrabold text-slate-900">50 GB Plan</td>
                <td className="p-3.5 bg-[#fffcdb] border-x-2 border-b-2 border-[#facc15] font-black text-amber-900 text-sm">
                  ₹699/-Year
                </td>
                <td className="p-3.5 text-slate-600">₹2,109/-Year</td>
                <td className="p-3.5 text-slate-600">₹1,217/-Year</td>
                <td className="p-3.5 text-slate-600">₹6,060/-Year</td>
                <td className="p-3.5 text-slate-600">₹1,068/-Year</td>
                <td className="p-3.5 text-slate-600">₹2,958/-Year</td>
                <td className="p-3.5 text-slate-600">₹2,159/-Year</td>
                <td className="p-3.5 text-slate-600">₹5,159/-Year</td>
                <td className="p-3.5 text-slate-600">₹2,870/-Year</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Mobile Provider Cards */}
        <div className="lg:hidden space-y-3">
          {/* Gitysoft Card (Highlighted) */}
          <div className="p-4 rounded-xl bg-[#fffcdb] border-2 border-[#facc15] shadow-md space-y-2">
            <div className="text-center font-black text-base text-[#854d0e] pb-1 border-b border-amber-300">
              Gitysoft (Our Price)
            </div>
            <div className="flex justify-between text-xs">
              <span className="font-bold text-slate-700">10 GB Plan:</span>
              <strong className="text-amber-900 font-black">₹299 / Year</strong>
            </div>
            <div className="flex justify-between text-xs">
              <span className="font-bold text-slate-700">50 GB Plan:</span>
              <strong className="text-amber-900 font-black">₹699 / Year</strong>
            </div>
          </div>

          {[
            { name: 'GoDaddy', p10: '₹552/-Year', p50: '₹2,109/-Year' },
            { name: 'Bigrock', p10: '₹637/-Year', p50: '₹1,217/-Year' },
            { name: 'Hostinger', p10: '₹690/-Year', p50: '₹6,060/-Year' },
            { name: 'Resellerclub', p10: '₹648/-Year', p50: '₹1,068/-Year' },
            { name: 'Name.com', p10: '₹2,366/-Year', p50: '₹2,958/-Year' },
            { name: 'Hostgator', p10: '₹1,913/-Year', p50: '₹2,870/-Year' },
          ].map((c, i) => (
            <div key={i} className="p-3.5 rounded-xl bg-white border border-slate-200 text-xs space-y-1.5">
              <strong className="text-slate-900 block pb-1 border-b border-slate-100">{c.name}</strong>
              <div className="flex justify-between text-slate-600">
                <span>10 GB:</span>
                <span>{c.p10}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>50 GB:</span>
                <span>{c.p50}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 4. ADVANCED SECTION: GLASSMORPHISM HOW IT WORKS */}
      {/* ========================================================================= */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0f172a] via-[#1e293b] to-[#0f172a] text-white p-6 sm:p-12 shadow-xl border border-slate-800">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#3B3B6D]/30 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Why Switch to Our Premium Email?
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm">
              Experience the next generation of business communication with features built to increase your productivity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Card 1: AI-Powered Drafting */}
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 text-center space-y-3 hover:bg-white/10 hover:border-[#3B3B6D] transition-all">
              <div className="w-12 h-12 rounded-xl bg-[#3B3B6D]/30 text-sky-400 mx-auto flex items-center justify-center text-2xl">
                <Bot className="w-6 h-6 text-sky-400" />
              </div>
              <h3 className="text-lg font-bold text-white">AI-Powered Drafting</h3>
              <p className="text-slate-300 text-xs leading-relaxed">
                Stuck on what to write? Give our built-in AI a one-line prompt, and it will generate a professional email in seconds.
              </p>
            </div>

            {/* Card 2: Advanced Tracking */}
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 text-center space-y-3 hover:bg-white/10 hover:border-[#3B3B6D] transition-all">
              <div className="w-12 h-12 rounded-xl bg-[#3B3B6D]/30 text-emerald-400 mx-auto flex items-center justify-center text-2xl">
                <MailCheck className="w-6 h-6 text-emerald-400" />
              </div>
              <h3 className="text-lg font-bold text-white">Advanced Tracking</h3>
              <p className="text-slate-300 text-xs leading-relaxed">
                Never guess if your client saw your invoice. Get real-time notifications the moment your emails and file attachments are opened.
              </p>
            </div>

            {/* Card 3: Zero-Spam Inbox */}
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 text-center space-y-3 hover:bg-white/10 hover:border-[#3B3B6D] transition-all">
              <div className="w-12 h-12 rounded-xl bg-[#3B3B6D]/30 text-rose-400 mx-auto flex items-center justify-center text-2xl">
                <ShieldAlert className="w-6 h-6 text-rose-400" />
              </div>
              <h3 className="text-lg font-bold text-white">Zero-Spam Inbox</h3>
              <p className="text-slate-300 text-xs leading-relaxed">
                Our enterprise-grade security filters out 99.9% of spam, phishing attempts, and viruses before they reach you.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. INTERACTIVE WORKFLOW TABS: BUILT FOR YOUR WORKFLOW */}
      {/* ========================================================================= */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Built For Your Workflow
          </h2>
          <p className="text-slate-500 text-xs sm:text-sm">
            Tailored tools for growing startups and busy multi-client agency teams.
          </p>

          <div className="flex justify-center gap-3 pt-3">
            <button
              onClick={() => setActiveWorkflowTab('startups')}
              className={`px-5 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
                activeWorkflowTab === 'startups'
                  ? 'bg-[#3B3B6D] text-white shadow-md'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              For Startups
            </button>
            <button
              onClick={() => setActiveWorkflowTab('agencies')}
              className={`px-5 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
                activeWorkflowTab === 'agencies'
                  ? 'bg-[#3B3B6D] text-white shadow-md'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              For Agencies
            </button>
          </div>
        </div>

        {/* Tab 1: Startups */}
        {activeWorkflowTab === 'startups' && (
          <div className="rounded-3xl bg-white border border-slate-200 p-6 sm:p-10 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-8 items-center animate-fade-in">
            <div className="space-y-4">
              <span className="px-3 py-1 rounded-full bg-blue-50 text-[#3B3B6D] text-xs font-black uppercase">
                Seed &amp; Growth Stage
              </span>
              <h3 className="text-2xl font-black text-slate-900">Scale your startup fast</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Look professional from day one without breaking the bank. Get custom domain emails for your entire founding team in 5 minutes.
              </p>
              <ul className="space-y-2 text-xs font-bold text-slate-700">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>Setup founding team mailboxes (founder@, dev@, legal@)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>One-click contact import from personal Gmail or Yahoo</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>Integrated Calendar for pitch meetings &amp; demo calls</span>
                </li>
              </ul>
            </div>
            <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-50 to-[#eef0f7] border border-slate-200 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-800 pb-2 border-b border-slate-200">
                <span>Startup Inboxes Ready</span>
                <span className="text-emerald-600">3 Users Active</span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded-lg bg-white border border-slate-200 flex justify-between items-center">
                  <span>alex@nextgenstartup.in</span>
                  <span className="text-[10px] text-slate-400">Founder</span>
                </div>
                <div className="p-2.5 rounded-lg bg-white border border-slate-200 flex justify-between items-center">
                  <span>priya@nextgenstartup.in</span>
                  <span className="text-[10px] text-slate-400">CTO</span>
                </div>
                <div className="p-2.5 rounded-lg bg-white border border-slate-200 flex justify-between items-center">
                  <span>sales@nextgenstartup.in</span>
                  <span className="text-[10px] text-emerald-600 font-bold">Free Alias</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Agencies */}
        {activeWorkflowTab === 'agencies' && (
          <div className="rounded-3xl bg-white border border-slate-200 p-6 sm:p-10 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-8 items-center animate-fade-in">
            <div className="space-y-4">
              <span className="px-3 py-1 rounded-full bg-purple-50 text-purple-700 text-xs font-black uppercase">
                Agency &amp; Multiple Domains
              </span>
              <h3 className="text-2xl font-black text-slate-900">Manage multiple clients easily</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Use Multi-account support to toggle between client domains without constantly logging in and out.
              </p>
              <ul className="space-y-2 text-xs font-bold text-slate-700">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>Switch client domains in 1 click from single webmail bar</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>Shared templates for invoices, contracts, and proposals</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>Whitelabel branding with your custom logo and login URL</span>
                </li>
              </ul>
            </div>
            <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-50 to-[#eef0f7] border border-slate-200 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-800 pb-2 border-b border-slate-200">
                <span>Multi-Client Account Switcher</span>
                <span className="text-purple-600 font-bold">Titan Portal</span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded-lg bg-[#3B3B6D] text-white flex justify-between items-center shadow-xs">
                  <span className="font-bold">brand@agencygroup.com</span>
                  <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded">Active</span>
                </div>
                <div className="p-2.5 rounded-lg bg-white border border-slate-200 flex justify-between items-center text-slate-600">
                  <span>support@clientstore.in</span>
                  <span className="text-[10px] text-slate-400">Switch ↗</span>
                </div>
                <div className="p-2.5 rounded-lg bg-white border border-slate-200 flex justify-between items-center text-slate-600">
                  <span>media@fashionbrand.org</span>
                  <span className="text-[10px] text-slate-400">Switch ↗</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* ========================================================================= */}
      {/* 6. INSTANT 5-MINUTE ONBOARDING & ZERO-DOWNTIME MIGRATION */}
      {/* ========================================================================= */}
      <section className="rounded-3xl bg-slate-900 text-white p-6 sm:p-10 shadow-2xl border border-slate-800 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-sky-300 text-xs font-black uppercase">
            <Zap className="w-3.5 h-3.5" />
            <span>RAPID DEPLOYMENT ENGINE</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-black text-white">How Titan Email Works in 4 Simple Steps</h3>
          <p className="text-xs sm:text-sm text-slate-400">
            Go from zero to fully authenticated business email in less than 5 minutes with our automated setup wizard.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
            <div className="w-8 h-8 rounded-xl bg-[#3B3B6D] text-amber-300 font-black text-sm flex items-center justify-center">
              01
            </div>
            <h4 className="font-extrabold text-sm text-white">Choose Plan &amp; Term</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Select 1 to 10 years term to lock in up to 25% savings. Add your custom business domain name.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
            <div className="w-8 h-8 rounded-xl bg-[#3B3B6D] text-sky-300 font-black text-sm flex items-center justify-center">
              02
            </div>
            <h4 className="font-extrabold text-sm text-white">Auto DNS Configuration</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Our automated system adds your MX, SPF, DKIM, and DMARC records to ensure 100% inbox delivery.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
            <div className="w-8 h-8 rounded-xl bg-[#3B3B6D] text-emerald-300 font-black text-sm flex items-center justify-center">
              03
            </div>
            <h4 className="font-extrabold text-sm text-white">Create Mailboxes &amp; Aliases</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Set up team logins (info@, sales@, support@) plus up to 50 free aliases per mailbox with zero extra cost.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
            <div className="w-8 h-8 rounded-xl bg-[#3B3B6D] text-purple-300 font-black text-sm flex items-center justify-center">
              04
            </div>
            <h4 className="font-extrabold text-sm text-white">Connect &amp; Launch Titan</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Access your webmail portal directly, sync with Outlook and mobile apps on iOS &amp; Android seamlessly.
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#3B3B6D]/40 border border-indigo-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <strong className="text-white block">Free Migration from Google Workspace, cPanel or Microsoft 365</strong>
              <span className="text-slate-300 text-[11px]">Zero downtime. All historical emails, contacts, and folders transferred safely.</span>
            </div>
          </div>
          <a
            href="#pricing-section"
            className="px-5 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-950 font-black text-xs shrink-0 cursor-pointer shadow-sm transition-all"
          >
            Start Setup Now
          </a>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 7. ALL 17 COMPREHENSIVE BUSINESS EMAIL FAQS (2/2 MODERN ACCORDION GRID) */}
      {/* ========================================================================= */}
      <section className="space-y-6 pt-4">
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold uppercase">
            <HelpCircle className="w-3.5 h-3.5 text-[#3B3B6D]" />
            <span>KNOWLEDGE BASE (17 QUESTIONS)</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="text-slate-500 text-xs sm:text-sm">
            Everything you need to know about custom domains, 10-year lock-in savings, DNS configuration, and email aliases.
          </p>

          {/* Quick FAQ Search Bar */}
          <div className="max-w-md mx-auto pt-3 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-5" />
            <input
              type="text"
              placeholder="Search all 17 FAQs (e.g. Outlook, Alias, DMARC, Storage)..."
              value={faqSearch}
              onChange={(e) => setFaqSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-300 text-xs focus:outline-none focus:border-[#3B3B6D] bg-white shadow-xs"
            />
          </div>
        </div>

        {/* 2 / 2 Column Modern Accordion Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
          {/* Column 1 */}
          <div className="space-y-3">
            {filteredFaqs.slice(0, Math.ceil(filteredFaqs.length / 2)).map((faq, idx) => {
              const isOpen = Boolean(openFaqs[idx]);
              const numStr = String(idx + 1).padStart(2, '0');

              return (
                <div
                  key={idx}
                  className={`rounded-2xl border transition-all duration-300 bg-white overflow-hidden ${
                    isOpen
                      ? 'border-[#3B3B6D]/40 shadow-md ring-2 ring-[#3B3B6D]/10 bg-gradient-to-br from-white via-white to-slate-50/50'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => toggleFaq(idx)}
                    className="w-full p-4 sm:p-5 text-left flex items-start justify-between gap-3 hover:bg-slate-50/50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <span
                        className={`px-2 py-0.5 rounded-lg text-xs font-mono font-black shrink-0 transition-colors mt-0.5 ${
                          isOpen ? 'bg-[#3B3B6D] text-white' : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {numStr}
                      </span>
                      <div className="space-y-1">
                        <span className="font-extrabold text-slate-900 text-sm leading-snug block">
                          {faq.q}
                        </span>
                        <span className="inline-block text-[10px] font-bold text-[#3B3B6D] uppercase tracking-wider">
                          {faq.category}
                        </span>
                      </div>
                    </div>
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center transition-all duration-300 shrink-0 mt-0.5 ${
                        isOpen ? 'bg-[#3B3B6D]/10 text-[#3B3B6D] rotate-180' : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 border-t border-slate-100 leading-relaxed animate-fade-in pl-14">
                      <p>{faq.a}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Column 2 */}
          <div className="space-y-3">
            {filteredFaqs.slice(Math.ceil(filteredFaqs.length / 2)).map((faq, idx) => {
              const realIdx = idx + Math.ceil(filteredFaqs.length / 2);
              const isOpen = Boolean(openFaqs[realIdx]);
              const numStr = String(realIdx + 1).padStart(2, '0');

              return (
                <div
                  key={realIdx}
                  className={`rounded-2xl border transition-all duration-300 bg-white overflow-hidden ${
                    isOpen
                      ? 'border-[#3B3B6D]/40 shadow-md ring-2 ring-[#3B3B6D]/10 bg-gradient-to-br from-white via-white to-slate-50/50'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => toggleFaq(realIdx)}
                    className="w-full p-4 sm:p-5 text-left flex items-start justify-between gap-3 hover:bg-slate-50/50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <span
                        className={`px-2 py-0.5 rounded-lg text-xs font-mono font-black shrink-0 transition-colors mt-0.5 ${
                          isOpen ? 'bg-[#3B3B6D] text-white' : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {numStr}
                      </span>
                      <div className="space-y-1">
                        <span className="font-extrabold text-slate-900 text-sm leading-snug block">
                          {faq.q}
                        </span>
                        <span className="inline-block text-[10px] font-bold text-[#3B3B6D] uppercase tracking-wider">
                          {faq.category}
                        </span>
                      </div>
                    </div>
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center transition-all duration-300 shrink-0 mt-0.5 ${
                        isOpen ? 'bg-[#3B3B6D]/10 text-[#3B3B6D] rotate-180' : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 border-t border-slate-100 leading-relaxed animate-fade-in pl-14">
                      <p>{faq.a}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};

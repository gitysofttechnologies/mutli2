import React, { useState } from 'react';
import {
  Globe2,
  Zap,
  Gauge,
  Layers,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Terminal,
  Database,
  ShieldAlert,
  ArrowRight,
  GitBranch,
  RefreshCw,
  ShoppingBag,
  Sparkles,
} from 'lucide-react';
import { PricingPlanGrid } from '../PricingPlanGrid';
import { PricingPlan } from '../../types/hosting';
import { FunctionalWordPressDashboard } from '../dashboards/FunctionalWordPressDashboard';

interface WordPressHostingPageProps {
  plans: PricingPlan[];
  onOpenDeployModal: (plan?: PricingPlan) => void;
}

export const WordPressHostingPage: React.FC<WordPressHostingPageProps> = ({
  plans,
  onOpenDeployModal,
}) => {
  // Speed simulator state
  const [lscacheActive, setLscacheActive] = useState<boolean>(true);
  const [activeWpTool, setActiveWpTool] = useState<'staging' | 'redis' | 'cli' | 'security'>('staging');
  const [activeAccordion, setActiveAccordion] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Does LiteSpeed Cache come pre-installed and configured on WordPress?',
      a: 'Yes, every WordPress installation includes our fine-tuned LiteSpeed Cache preset with CSS/JS minification, HTML lazy-loading, WebP image generation, and critical CSS generation ready out-of-the-box.',
    },
    {
      q: 'How does 1-click WordPress Staging work?',
      a: 'With one click inside your control panel, you can clone your production WordPress website into a private staging sandbox (staging.yourdomain.com), test plugins or redesigns safely, and push changes back live in seconds.',
    },
    {
      q: 'Is this hosting optimized for heavy WooCommerce stores?',
      a: 'Yes! We configure Redis Object Caching in RAM so WooCommerce shopping carts, customer checkout sessions, and inventory queries bypass the SQL disk bottleneck completely.',
    },
    {
      q: 'Are automatic plugin and WordPress core updates safe?',
      a: 'Our smart update system creates an automated JetBackup snapshot before executing any updates. If an update causes an incompatibility, it auto-rolls back instantly.',
    },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* UNIQUE HERO: Managed WordPress Cloud with Functional Dashboard in Laptop */}
      <section className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-[#0c2438] via-[#004f7a] to-[#002f4d] text-white p-4 sm:p-6 lg:p-8 shadow-xl border border-blue-400/20">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-sky-400/10 rounded-full blur-3xl -mr-32 -mt-32 pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center">
          {/* LEFT SIDE: HERO CONTENT (6 Columns on lg/xl) */}
          <div className="lg:col-span-6 space-y-4 sm:space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-300/30 text-blue-200 text-xs font-bold uppercase tracking-wider">
              <Globe2 className="w-3.5 h-3.5" />
              <span>Official LiteSpeed &amp; WooCommerce Ready</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
              Turbocharged Managed <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-200 via-sky-300 to-indigo-200">
                WordPress Hosting
              </span>
            </h1>

            <p className="text-blue-100 text-xs sm:text-sm leading-relaxed max-w-xl">
              Engineered specifically for WordPress &amp; WooCommerce. Sub-second load times with in-memory Redis caching, 1-click staging, automated updates, and ultra-fast NVMe storage.
            </p>

            {/* Value Checkmarks */}
            <ul className="grid grid-cols-2 gap-2 sm:gap-2.5 text-xs font-bold text-blue-100">
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Pre-installed WP 6.7</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>LiteSpeed Enterprise</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Redis RAM Cache</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>1-Click WP Staging</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Free Auto SSL &amp; CDN</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Automated Backups</span>
              </li>
            </ul>

            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={() => onOpenDeployModal(plans[2] || plans[0])}
                className="px-6 py-3.5 rounded-xl bg-white hover:bg-blue-50 text-blue-900 font-black text-xs sm:text-sm shadow-lg shadow-black/20 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Launch WordPress at ₹79/mo</span>
                <ArrowRight className="w-4 h-4 text-blue-700" />
              </button>
            </div>
          </div>

          {/* RIGHT SIDE: FUNCTIONAL WORDPRESS DASHBOARD INSIDE LAPTOP MOCKUP (6 Columns on lg/xl) */}
          <div className="lg:col-span-6 w-full flex justify-center items-center">
            <div className="w-full flex justify-center max-w-[480px] sm:max-w-[520px] lg:max-w-[540px]">
              <FunctionalWordPressDashboard />
            </div>
          </div>
        </div>
      </section>

      {/* BENCHMARK & PAGESPEED METRICS CARD */}
      <div className="bg-slate-900/90 text-white rounded-2xl sm:rounded-3xl p-5 sm:p-6 border border-blue-400/30 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Gauge className="w-5 h-5 text-sky-400" />
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white uppercase tracking-wider">
                LiteSpeed &amp; Redis PageSpeed Benchmark
              </h3>
              <p className="text-xs text-slate-400">Real-time simulation on NVMe hardware</p>
            </div>
          </div>
          <button
            onClick={() => setLscacheActive(!lscacheActive)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
              lscacheActive
                ? 'bg-emerald-500 text-slate-950 font-extrabold shadow-sm'
                : 'bg-rose-500/30 text-rose-300'
            }`}
          >
            {lscacheActive ? '✓ LSCache + Redis ON' : '✕ Standard Apache/Nginx'}
          </button>
        </div>

        <div className="grid grid-cols-3 gap-3 text-center">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[10px] sm:text-xs text-slate-400 uppercase font-semibold block mb-0.5">
              Speed Score
            </span>
            <span className={`text-2xl sm:text-3xl font-black ${lscacheActive ? 'text-emerald-400' : 'text-amber-400'}`}>
              {lscacheActive ? '99/100' : '72/100'}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[10px] sm:text-xs text-slate-400 uppercase font-semibold block mb-0.5">
              TTFB Latency
            </span>
            <span className={`text-2xl sm:text-3xl font-black ${lscacheActive ? 'text-emerald-400' : 'text-rose-400'}`}>
              {lscacheActive ? '42 ms' : '680 ms'}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[10px] sm:text-xs text-slate-400 uppercase font-semibold block mb-0.5">
              LCP Render
            </span>
            <span className={`text-2xl sm:text-3xl font-black ${lscacheActive ? 'text-emerald-400' : 'text-amber-400'}`}>
              {lscacheActive ? '0.6s' : '2.9s'}
            </span>
          </div>
        </div>
      </div>

      {/* INTERACTIVE TAB: WordPress Power Tools */}
      <div className="rounded-3xl bg-white border border-slate-200/90 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-blue-50 text-blue-700 border border-blue-200">
              DEVELOPER &amp; AGENCY SUITE
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-1">
              Engineered WordPress Toolset
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Everything WordPress developers and agencies need to deploy and manage high-traffic stores.
            </p>
          </div>

          {/* Tool Switcher Tabs */}
          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 border border-slate-200 overflow-x-auto">
            <button
              onClick={() => setActiveWpTool('staging')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeWpTool === 'staging'
                  ? 'bg-[#0073aa] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              1-Click Staging
            </button>
            <button
              onClick={() => setActiveWpTool('redis')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeWpTool === 'redis'
                  ? 'bg-[#0073aa] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Redis Object Cache
            </button>
            <button
              onClick={() => setActiveWpTool('cli')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeWpTool === 'cli'
                  ? 'bg-[#0073aa] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              WP-CLI &amp; Git
            </button>
            <button
              onClick={() => setActiveWpTool('security')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeWpTool === 'security'
                  ? 'bg-[#0073aa] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Smart Auto-Updates
            </button>
          </div>
        </div>

        {/* Tab Detail View */}
        <div className="pt-6">
          {activeWpTool === 'staging' && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              <div className="md:col-span-7 space-y-3">
                <div className="flex items-center gap-2 text-[#0073aa] font-bold text-xs uppercase">
                  <GitBranch className="w-4 h-4" />
                  <span>Sandbox Environment</span>
                </div>
                <h3 className="text-xl font-black text-slate-900">
                  Safely test plugins, themes, and code updates
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Never break your live site again. Create a clone with one click, modify your files or update WooCommerce in staging, and push selective database tables or files back to production instantly.
                </p>
                <div className="pt-2 flex flex-wrap gap-2 text-xs">
                  <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 font-semibold border border-blue-200">
                    ✓ Selective DB Merge
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 font-semibold border border-blue-200">
                    ✓ Password-Protected Staging
                  </span>
                </div>
              </div>
              <div className="md:col-span-5 p-4 rounded-2xl bg-slate-950 text-slate-200 font-mono text-xs border border-slate-800">
                <div className="text-slate-500 mb-1"># Create staging clone:</div>
                <div className="text-sky-300">$ wp staging create --name="redesign-2026"</div>
                <div className="text-emerald-400 mt-2">✓ Staging deployed to: staging.store.com</div>
                <div className="text-slate-500 mt-2"># Push changes back live:</div>
                <div className="text-sky-300">$ wp staging push --target=production</div>
                <div className="text-emerald-400 mt-1">✓ Synced with 0s downtime.</div>
              </div>
            </div>
          )}

          {activeWpTool === 'redis' && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              <div className="md:col-span-7 space-y-3">
                <div className="flex items-center gap-2 text-rose-600 font-bold text-xs uppercase">
                  <Database className="w-4 h-4" />
                  <span>In-Memory RAM Caching</span>
                </div>
                <h3 className="text-xl font-black text-slate-900">
                  Cut MySQL database queries by up to 95%
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Redis stores complex database query results in blazing-fast memory. When shoppers browse products or categories, results are served in 1ms without touching the slow disk.
                </p>
                <div className="pt-2 flex flex-wrap gap-2 text-xs">
                  <span className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 font-semibold border border-rose-200">
                    ✓ Dedicated Redis Socket
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 font-semibold border border-rose-200">
                    ✓ Zero MySQL Lockups
                  </span>
                </div>
              </div>
              <div className="md:col-span-5 p-4 rounded-2xl bg-slate-900 border border-slate-800 text-xs font-mono">
                <div className="flex items-center justify-between text-slate-300 pb-2 border-b border-slate-800">
                  <span>Redis Memory:</span>
                  <span className="text-emerald-400 font-bold">256 MB Active</span>
                </div>
                <div className="flex items-center justify-between text-slate-300 py-2 border-b border-slate-800">
                  <span>Cache Hit Ratio:</span>
                  <span className="text-sky-400 font-bold">98.4%</span>
                </div>
                <div className="flex items-center justify-between text-slate-300 pt-2">
                  <span>Queries Saved:</span>
                  <span className="text-purple-400 font-bold">1.2M queries / day</span>
                </div>
              </div>
            </div>
          )}

          {activeWpTool === 'cli' && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              <div className="md:col-span-7 space-y-3">
                <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs uppercase">
                  <Terminal className="w-4 h-4" />
                  <span>Command Line &amp; Version Control</span>
                </div>
                <h3 className="text-xl font-black text-slate-900">
                  Automate deployments with WP-CLI and Git
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Full SSH shell access with pre-installed WP-CLI, Composer, and Git. Push code directly from GitHub or GitLab to your production or staging branches automatically.
                </p>
              </div>
              <div className="md:col-span-5 p-4 rounded-2xl bg-slate-950 text-slate-200 font-mono text-xs border border-slate-800">
                <div className="text-slate-500"># Mass plugin update via CLI:</div>
                <div className="text-emerald-400">$ wp plugin update --all</div>
                <div className="text-slate-500 mt-2"># Search and replace URLs safely:</div>
                <div className="text-sky-300">$ wp search-replace 'old.com' 'new.com'</div>
              </div>
            </div>
          )}

          {activeWpTool === 'security' && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              <div className="md:col-span-7 space-y-3">
                <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs uppercase">
                  <RefreshCw className="w-4 h-4" />
                  <span>AI Smart Updates &amp; Backup</span>
                </div>
                <h3 className="text-xl font-black text-slate-900">
                  Automated visual testing before and after updates
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Our system compares visual screenshots of your homepage and cart pages before and after core updates. If any pixel break is detected, the snapshot rolls back immediately.
                </p>
              </div>
              <div className="md:col-span-5 p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs">
                <div className="font-bold flex items-center gap-2 mb-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Automated Rollback Shield Active</span>
                </div>
                <p className="text-emerald-800 leading-relaxed">
                  Daily offsite backups to AWS S3 + 30-day retention with 1-click restore for single files or full databases.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* EXACT PRICING PLAN CARDS (Matches Image Reference) */}
      <div className="rounded-3xl bg-white border border-slate-200/90 p-6 sm:p-8 shadow-sm">
        <PricingPlanGrid
          plans={plans}
          sectionTitle="Managed WordPress Hosting Plans"
          sectionSubtitle="Engineered for high performance WordPress blogs, multi-sites, and WooCommerce stores."
          categoryName="WordPress Hosting"
        />
      </div>

      {/* 4 FEATURE COLUMNS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="rounded-2xl p-5 bg-white border border-slate-200 shadow-sm hover:shadow-md transition-all group">
          <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <Globe2 className="w-5 h-5" />
          </div>
          <h3 className="font-black text-slate-900 text-base mb-1">1-Click WP Install</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Install WordPress with auto SSL and security hardening in less than 30 seconds.
          </p>
        </div>

        <div className="rounded-2xl p-5 bg-white border border-slate-200 shadow-sm hover:shadow-md transition-all group">
          <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <ShoppingBag className="w-5 h-5" />
          </div>
          <h3 className="font-black text-slate-900 text-base mb-1">WooCommerce Turbo</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Handle hundreds of concurrent checkouts without timeouts or slow cart response.
          </p>
        </div>

        <div className="rounded-2xl p-5 bg-white border border-slate-200 shadow-sm hover:shadow-md transition-all group">
          <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <Database className="w-5 h-5" />
          </div>
          <h3 className="font-black text-slate-900 text-base mb-1">Redis Object Cache</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            In-memory persistence for all transient data and heavy SQL queries.
          </p>
        </div>

        <div className="rounded-2xl p-5 bg-white border border-slate-200 shadow-sm hover:shadow-md transition-all group">
          <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <h3 className="font-black text-slate-900 text-base mb-1">WP Malware Defense</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Real-time proactive rule set blocking brute-force attacks on wp-login.php and XML-RPC.
          </p>
        </div>
      </div>

      {/* ACCORDION FAQ SECTION */}
      <div className="rounded-3xl bg-white border border-slate-200/90 p-6 sm:p-8 shadow-sm">
        <h3 className="text-xl font-black text-slate-900 mb-4">
          WordPress Hosting Frequently Asked Questions
        </h3>
        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = activeAccordion === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-slate-200/80 overflow-hidden transition-all"
              >
                <button
                  onClick={() => setActiveAccordion(isOpen ? null : idx)}
                  className="w-full p-4 text-left flex items-center justify-between font-bold text-slate-800 text-sm hover:bg-slate-50 transition-colors"
                >
                  <span>{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-blue-600 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <div className="p-4 pt-0 text-xs text-slate-600 border-t border-slate-100 bg-slate-50/50 leading-relaxed">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  Check,
  ArrowRight,
  Terminal,
  Cpu,
  HardDrive,
  Globe,
  Activity,
  GitBranch,
  ShieldCheck,
  Layers,
  Lock,
  Server,
  Clock,
  Star,
  CheckCircle2,
  Play,
  RotateCw,
  ExternalLink,
  ChevronDown,
  Sparkles,
  Zap,
  Radio,
  FileCode,
  Copy,
  ChevronRight,
  Database,
  SlidersHorizontal,
} from 'lucide-react';
import { PricingPlanGrid } from '../PricingPlanGrid';
import { allCategoryPlans } from '../../data/hostingPagesData';
import { ImpressiveReviewsCarousel } from '../common/ImpressiveReviewsCarousel';

export type HostingStack = 'shared' | 'wordpress' | 'cpanel' | 'python' | 'business' | 'indian' | 'reseller';

interface ModernHostingPageProps {
  stack?: HostingStack;
  onDeployPlan?: (planName: string, price: string) => void;
  onOpenLiveChat?: () => void;
  onOpenMigrationModal?: () => void;
}

export const ModernHostingPage: React.FC<ModernHostingPageProps> = ({
  stack = 'cpanel',
  onDeployPlan,
  onOpenLiveChat,
  onOpenMigrationModal,
}) => {
  // Billing Cycle Toggle (Monthly vs Yearly 60% OFF)
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  // Interactive Code Editor Tabs
  const [activeCodeTab, setActiveCodeTab] = useState<'app.js' | 'server.js' | 'package.json'>('app.js');
  const [activeVersion, setActiveVersion] = useState<string>('22.x');

  // Real-time server performance ticking state
  const [metrics, setMetrics] = useState({
    cpu: 12,
    ram: 28,
    disk: 41,
    net: 18,
  });

  // Interactive FAQs Accordion
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Live copy notification
  const [copiedCode, setCopiedCode] = useState(false);

  // Animate metrics slightly for living dashboard effect
  useEffect(() => {
    const timer = setInterval(() => {
      setMetrics((prev) => ({
        cpu: Math.min(95, Math.max(8, prev.cpu + (Math.floor(Math.random() * 5) - 2))),
        ram: Math.min(95, Math.max(20, prev.ram + (Math.floor(Math.random() * 3) - 1))),
        disk: 41,
        net: Math.min(90, Math.max(10, prev.net + (Math.floor(Math.random() * 7) - 3))),
      }));
    }, 2800);
    return () => clearInterval(timer);
  }, []);

  // Stack Configurations (Node.js, WordPress, Python, cPanel, Shared)
  const stackData = {
    nodejs: {
      title: 'Node.js Hosting',
      tagline: 'Deploy, manage and scale your Node.js applications with high performance servers, global infrastructure and powerful developer tools.',
      badgeText: 'FAST • SECURE • DEVELOPER FRIENDLY',
      accentColor: 'text-emerald-500',
      accentBg: 'bg-emerald-500',
      accentBorder: 'border-emerald-500',
      logoLabel: 'Node.js',
      defaultPort: 3000,
      versions: ['14.x LTS', '16.x LTS', '18.x LTS', '20.x LTS', '22.x Latest'],
      codeTabs: {
        'app.js': `const express = require('express')
const app = express()

app.get('/', (req, res) => {
  res.json({
    message: 'Hello from Gitysoft!',
    status: 'Running',
    platform: 'Node.js'
  })
})

app.listen(3000, () => {
  console.log('Server running 🚀')
})`,
        'server.js': `const cluster = require('cluster');
const http = require('http');
const numCPUs = require('os').cpus().length;

if (cluster.isMaster) {
  for (let i = 0; i < numCPUs; i++) cluster.fork();
  cluster.on('exit', () => cluster.fork());
} else {
  http.createServer((req, res) => {
    res.writeHead(200);
    res.end('Cluster Worker Active\\n');
  }).listen(3000);
}`,
        'package.json': `{
  "name": "gitysoft-app",
  "version": "1.0.0",
  "main": "app.js",
  "scripts": {
    "start": "pm2 start app.js --name production-api"
  },
  "dependencies": {
    "express": "^4.19.2",
    "cors": "^2.8.5"
  }
}`,
      },
    },
    wordpress: {
      title: 'WordPress Hosting',
      tagline: 'Turbocharged WordPress with LiteSpeed Enterprise, automated updates, Redis object caching, and staging environments.',
      badgeText: 'LITESPEED TURBO • 99.9% UPTIME • WP CLI',
      accentColor: 'text-blue-500',
      accentBg: 'bg-blue-600',
      accentBorder: 'border-blue-500',
      logoLabel: 'WordPress',
      defaultPort: 443,
      versions: ['WP 6.2', 'WP 6.3', 'WP 6.4', 'WP 6.5', 'WP 6.7 Latest'],
      codeTabs: {
        'app.js': `// wp-config.php Configuration
define( 'WP_CACHE', true );
define( 'WP_REDIS_HOST', '127.0.0.1' );
define( 'WP_REDIS_PORT', 6379 );

// Gitysoft LiteSpeed Enterprise Optimization
define( 'LSCWP_VARY', true );
define( 'WP_MEMORY_LIMIT', '512M' );`,
        'server.js': `# CLI Diagnostic & Maintenance
wp core update --allow-root
wp plugin update --all --allow-root
wp litespeed-purge all`,
        'package.json': `{
  "stack": "WordPress LSCache",
  "database": "MariaDB 10.11",
  "php": "PHP 8.3",
  "security": "Imunify360 + ModSecurity"
}`,
      },
    },
    cpanel: {
      title: 'cPanel NVMe Hosting',
      tagline: 'Official cPanel license with Softaculous 400+ 1-click script installers, CloudLinux CageFS security, and daily offsite backups.',
      badgeText: 'GENUINE CPANEL • SOFTACULOUS • FAST NVME',
      accentColor: 'text-amber-500',
      accentBg: 'bg-amber-600',
      accentBorder: 'border-amber-500',
      logoLabel: 'cPanel',
      defaultPort: 2083,
      versions: ['PHP 7.4', 'PHP 8.0', 'PHP 8.1', 'PHP 8.2', 'PHP 8.3 Latest'],
      codeTabs: {
        'app.js': `// cPanel Node.js Application Setup
const app = require('./index');
const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log('cPanel Passenger Proxy Connected');
});`,
        'server.js': `// .htaccess LiteSpeed Rule
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /
RewriteRule ^index\\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>`,
        'package.json': `{
  "panel": "cPanel Version 118",
  "storage": "PCIe 4.0 NVMe",
  "mail": "SpamAssassin + Webmail",
  "backups": "JetBackup 5 (Daily)"
}`,
      },
    },
  }[stack === 'wordpress' ? 'wordpress' : 'cpanel'];

  // Pricing Plans from Screenshot
  const plans = [
    {
      id: 'starter',
      name: 'Starter',
      subtitle: 'Perfect for Learning',
      monthlyPrice: 199,
      yearlyPrice: 79,
      badge: null,
      isPopular: false,
      features: [
        '1 App Deployment',
        '1 GB RAM',
        '25 GB NVMe Storage',
        'Free SSL Certificate',
        'Git & SSH Access',
        'Basic Community Support',
      ],
    },
    {
      id: 'developer',
      name: 'Developer',
      subtitle: 'Most Popular',
      monthlyPrice: 399,
      yearlyPrice: 159,
      badge: 'Most Popular',
      isPopular: true,
      features: [
        '5 App Deployments',
        '2 GB RAM',
        '50 GB NVMe Storage',
        'Free SSL Certificate',
        'PM2 Process Support',
        'Priority Technical Support',
      ],
    },
    {
      id: 'business',
      name: 'Business',
      subtitle: 'For Growing Applications',
      monthlyPrice: 699,
      yearlyPrice: 279,
      badge: null,
      isPopular: false,
      features: [
        '10 App Deployments',
        '4 GB RAM',
        '100 GB NVMe Storage',
        'Free SSL Certificate',
        'Advanced Live Monitoring',
        'Priority Technical Support',
      ],
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      subtitle: 'For High Traffic Apps',
      monthlyPrice: 1299,
      yearlyPrice: 519,
      badge: null,
      isPopular: false,
      features: [
        'Unlimited Deployments',
        '8 GB RAM',
        '200 GB NVMe Storage',
        'Free Wildcard SSL',
        'Dedicated CPU Resources',
        '24/7 Dedicated VIP Support',
      ],
    },
  ];

  // 12 Feature Tiles from Horizontal Ribbon Bar
  const ribbonFeatures = [
    { icon: 'code', title: 'Multiple Node.js Versions', iconComp: <Terminal className="w-5 h-5 text-emerald-400" /> },
    { icon: 'pm2', title: 'PM2 Process Manager', iconComp: <Cpu className="w-5 h-5 text-emerald-400" /> },
    { icon: 'git', title: 'Git Deployment', iconComp: <GitBranch className="w-5 h-5 text-emerald-400" /> },
    { icon: 'ssh', title: 'SSH Access', iconComp: <Terminal className="w-5 h-5 text-emerald-400" /> },
    { icon: 'env', title: 'Environment Variables', iconComp: <Layers className="w-5 h-5 text-emerald-400" /> },
    { icon: 'domain', title: 'Custom Domains', iconComp: <Globe className="w-5 h-5 text-emerald-400" /> },
    { icon: 'nginx', title: 'Nginx / Apache', iconComp: <Server className="w-5 h-5 text-emerald-400" /> },
    { icon: 'cron', title: 'Cron Jobs', iconComp: <Clock className="w-5 h-5 text-emerald-400" /> },
    { icon: 'logs', title: 'Monitoring & Logs', iconComp: <Activity className="w-5 h-5 text-emerald-400" /> },
    { icon: 'staging', title: 'Staging Environment', iconComp: <Layers className="w-5 h-5 text-emerald-400" /> },
    { icon: 'backup', title: 'Automatic Backups', iconComp: <RotateCw className="w-5 h-5 text-emerald-400" /> },
    { icon: 'ddos', title: 'DDoS Protection', iconComp: <ShieldCheck className="w-5 h-5 text-emerald-400" /> },
  ];

  // Global Infrastructure Datacenters
  const datacenters = [
    { flag: '🇮🇳', country: 'India', city: 'Mumbai', ping: '8ms' },
    { flag: '🇺🇸', country: 'USA', city: 'New York', ping: '12ms' },
    { flag: '🇬🇧', country: 'UK', city: 'London', ping: '15ms' },
    { flag: '🇩🇪', country: 'Germany', city: 'Frankfurt', ping: '14ms' },
    { flag: '🇸🇬', country: 'Singapore', city: 'Singapore', ping: '18ms' },
  ];

  // Developer Tools
  const devTools = [
    { name: 'PM2', icon: '⚡' },
    { name: 'NPM', icon: '📦' },
    { name: 'Yarn', icon: '🧶' },
    { name: 'Git', icon: '🌿' },
    { name: 'SSH', icon: '>_' },
    { name: 'File Manager', icon: '📁' },
    { name: 'Cron Jobs', icon: '⏱️' },
    { name: 'Logs', icon: '📋' },
    { name: 'Database', icon: '🗄️' },
    { name: 'CLI Access', icon: '💻' },
  ];

  // 6 Endless Possibilities Bento Cards
  const possibilities = [
    {
      title: 'Web Applications',
      desc: 'Express.js, Next.js, Nuxt, Remix',
      icon: '🌐',
      bg: 'bg-indigo-50 border-indigo-200 text-indigo-700',
    },
    {
      title: 'APIs & Microservices',
      desc: 'Scalable & Secure REST, GraphQL',
      icon: '⚡',
      bg: 'bg-rose-50 border-rose-200 text-rose-700',
    },
    {
      title: 'Real-time Apps',
      desc: 'Chat, Streaming, Live Data, WebSockets',
      icon: '💬',
      bg: 'bg-emerald-50 border-emerald-200 text-emerald-700',
    },
    {
      title: 'Bots & Automation',
      desc: 'Discord, Telegram, WhatsApp, Slack',
      icon: '🤖',
      bg: 'bg-blue-50 border-blue-200 text-blue-700',
    },
    {
      title: 'E-Commerce',
      desc: 'Headless, Shopify Apps, MedusaJS',
      icon: '🛍️',
      bg: 'bg-amber-50 border-amber-200 text-amber-700',
    },
    {
      title: 'AI & Machine Learning',
      desc: 'Integrate AI Models, LangChain, OpenAI',
      icon: '🧠',
      bg: 'bg-purple-50 border-purple-200 text-purple-700',
    },
  ];

  // Reviews from screenshot
  const reviews = [
    {
      name: 'Amit Sharma',
      role: 'Full Stack Developer',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
      text: 'Super fast servers! My Node.js app runs smoothly without any downtime. Highly recommended!',
    },
    {
      name: 'Priya Verma',
      role: 'Software Engineer',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=120&q=80',
      text: 'The deployment process is so easy. Git integration and PM2 support saved me a lot of time.',
    },
    {
      name: 'Rahul Mehta',
      role: 'CTO, SaaS Project',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80',
      text: 'Great performance and excellent support. Best Node.js hosting in India with Mumbai servers!',
    },
    {
      name: 'Neha Singh',
      role: 'Freelancer',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80',
      text: 'Affordable pricing with all the essential features. Perfect for developers and client apps.',
    },
  ];

  // FAQs
  const faqs = [
    {
      q: 'Which Node.js versions are supported?',
      a: 'We support all active LTS and latest releases including Node.js 14.x, 16.x, 18.x, 20.x, and 22.x Latest. You can switch versions with one click from your control panel anytime.',
    },
    {
      q: 'Can I deploy from GitHub or GitLab?',
      a: 'Yes! Automated CI/CD webhooks trigger builds on every git push to your master or main branch. We also support manual git pull, zip uploads, and SSH rsync.',
    },
    {
      q: 'Do you provide SSH access?',
      a: 'Full jailed SSH terminal access is provided on Developer, Business, and Enterprise plans with access to npm, yarn, git, pm2, and system diagnostics.',
    },
    {
      q: 'Is PM2 included?',
      a: 'Yes, PM2 process management comes pre-configured with zero-downtime reloads, cluster mode across CPU cores, and automatic startup on server boots.',
    },
    {
      q: 'Can I use my own custom domain?',
      a: 'Yes, you can bind unlimited custom domains with free auto-renewing Let’s Encrypt SSL certificates, automated DNS records, and Cloudflare CDN proxying.',
    },
    {
      q: 'What is your refund policy?',
      a: 'We offer an unconditional 30-Day Money-Back Guarantee. If you are not satisfied for any reason, get a full refund within 30 days with no questions asked.',
    },
  ];

  const handleCopyCode = () => {
    navigator.clipboard?.writeText(stackData.codeTabs[activeCodeTab]);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="bg-[#f8fafc] text-slate-900 font-sans antialiased selection:bg-emerald-500 selection:text-white">
      {/* ========================================================================= */}
      {/* 1. TOP HERO SECTION (PIXEL-PERFECT FROM SCREENSHOT) */}
      {/* ========================================================================= */}
      <section className="relative pt-8 pb-16 px-4 sm:px-6 lg:px-8 max-w-[1360px] mx-auto overflow-hidden">
        {/* Glow ambient background elements */}
        <div className="absolute top-12 left-1/4 w-96 h-96 bg-emerald-200/30 rounded-full blur-3xl pointer-events-none -z-10" />
        <div className="absolute top-20 right-1/4 w-80 h-80 bg-teal-200/25 rounded-full blur-3xl pointer-events-none -z-10" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Hero Copy & CTA */}
          <div className="lg:col-span-4 space-y-6">
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-[11px] font-extrabold tracking-wide uppercase shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>{stackData.badgeText}</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl font-black text-slate-900 tracking-tight leading-[1.12]">
              {stackData.title} <br />
              Built for Real <br />
              <span className="text-emerald-500 font-black">Developers</span>
            </h1>

            {/* Sub-description */}
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              {stackData.tagline}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                onClick={() => {
                  const devPlan = plans.find((p) => p.isPopular) || plans[0];
                  if (onDeployPlan) onDeployPlan(devPlan.name, `₹${devPlan.monthlyPrice}`);
                }}
                className="px-6 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-sm shadow-lg shadow-emerald-500/25 active:scale-95 transition-all flex items-center gap-2 group cursor-pointer"
              >
                <span>Get Started Now</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <a
                href="#pricing-grid"
                className="px-6 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-bold text-sm border border-slate-300 shadow-2xs active:scale-95 transition-all flex items-center gap-1.5"
              >
                <span>View Plans</span>
              </a>
            </div>

            {/* Social Proof */}
            <div className="pt-3 flex items-center gap-3">
              <div className="flex -space-x-2">
                {[
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=80&q=80',
                  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=80&q=80',
                  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=80&q=80',
                  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=80&q=80',
                ].map((src, i) => (
                  <img
                    key={i}
                    src={src}
                    alt="Developer"
                    className="w-8 h-8 rounded-full border-2 border-white object-cover shadow-2xs"
                  />
                ))}
              </div>
              <div className="text-xs">
                <span className="font-extrabold text-slate-900 block">50,000+ Developers</span>
                <span className="text-slate-500 text-[11px]">Trust Our Hosting Platform</span>
              </div>
            </div>
          </div>

          {/* Middle Column: Interactive Code Editor Mockup + Floating Node Hexagon */}
          <div className="lg:col-span-5 relative">
            <div className="rounded-2xl bg-slate-950 text-slate-200 border border-slate-800 shadow-2xl p-4 sm:p-5 relative overflow-hidden font-mono text-xs">
              {/* Window Header */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-rose-500" />
                  <div className="w-3 h-3 rounded-full bg-amber-500" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                </div>

                {/* Tabs */}
                <div className="flex items-center gap-1">
                  {(['app.js', 'server.js', 'package.json'] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveCodeTab(tab)}
                      className={`px-3 py-1 rounded-md text-[11px] transition-colors cursor-pointer ${
                        activeCodeTab === tab
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleCopyCode}
                  className="text-slate-400 hover:text-white p-1 rounded-md cursor-pointer"
                  title="Copy Code"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Code Snippet with Syntax Colors */}
              <pre className="text-[11px] leading-relaxed overflow-x-auto text-emerald-300/90 py-2">
                <code>{stackData.codeTabs[activeCodeTab]}</code>
              </pre>

              {/* Bottom Status Pill */}
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-2 text-emerald-400 bg-emerald-950/60 px-3 py-1.5 rounded-full border border-emerald-800/50">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Application Deployed: https://yourapp.online</span>
                </div>
                {copiedCode && <span className="text-emerald-400 font-bold">Copied!</span>}
              </div>
            </div>

            {/* Glowing 3D Node Hexagon & Build/Develop/Deploy/Scale Pills from Screenshot */}
            <div className="absolute -top-4 -right-4 sm:-right-8 hidden md:flex flex-col items-center gap-2">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-slate-900 to-slate-800 border-2 border-emerald-500 shadow-xl shadow-emerald-500/30 flex items-center justify-center animate-bounce-slow">
                <span className="text-2xl font-black text-emerald-400">Node</span>
              </div>
              <div className="flex flex-col gap-1.5">
                {['Build', 'Develop', 'Deploy', 'Scale'].map((step, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 rounded-full bg-slate-900/90 backdrop-blur-md text-[10px] font-bold text-slate-200 border border-slate-700 shadow-md text-center"
                  >
                    {step}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Real-time Server Performance Card & Badges */}
          <div className="lg:col-span-3 space-y-3.5">
            {/* Real-time Performance Card */}
            <div className="rounded-2xl bg-white border border-slate-200 shadow-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Real-time Server Performance</span>
                </h4>
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                </span>
              </div>

              {/* 4 Circular Dials from Screenshot */}
              <div className="grid grid-cols-4 gap-2 pt-1">
                {[
                  { label: 'CPU', val: metrics.cpu, color: 'text-sky-500', stroke: '#0ea5e9' },
                  { label: 'RAM', val: metrics.ram, color: 'text-teal-500', stroke: '#14b8a6' },
                  { label: 'Disk', val: metrics.disk, color: 'text-emerald-500', stroke: '#10b981' },
                  { label: 'Network', val: metrics.net, color: 'text-purple-500', stroke: '#a855f7' },
                ].map((dial) => (
                  <div key={dial.label} className="flex flex-col items-center">
                    <div className="relative w-11 h-11 flex items-center justify-center">
                      <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                        <circle
                          cx="18"
                          cy="18"
                          r="14"
                          fill="none"
                          className="stroke-slate-100"
                          strokeWidth="3.5"
                        />
                        <circle
                          cx="18"
                          cy="18"
                          r="14"
                          fill="none"
                          stroke={dial.stroke}
                          strokeWidth="3.5"
                          strokeDasharray="88"
                          strokeDashoffset={88 - (88 * dial.val) / 100}
                          strokeLinecap="round"
                          className="transition-all duration-700"
                        />
                      </svg>
                      <span className={`absolute text-[10px] font-black ${dial.color}`}>{dial.val}%</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500 mt-1">{dial.label}</span>
                  </div>
                ))}
              </div>

              {/* Micro Status Badges from Screenshot */}
              <div className="space-y-1.5 pt-2 border-t border-slate-100 text-[11px]">
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-150">
                  <div className="flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-emerald-600" />
                    <div>
                      <span className="font-bold text-slate-800 block text-[10px]">Your App is Live!</span>
                      <span className="text-slate-500 text-[9px] font-mono">https://yourapp.online</span>
                    </div>
                  </div>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700 text-[9px] font-bold">200 OK</span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-150">
                  <div className="flex items-center gap-1.5">
                    <GitBranch className="w-3.5 h-3.5 text-slate-700" />
                    <span className="font-bold text-slate-800 text-[10px]">Auto Deploy from GitHub</span>
                  </div>
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                </div>
              </div>
            </div>

            {/* 3 Pills: Free SSL, Global CDN, Automatic Backups */}
            <div className="grid grid-cols-3 gap-2">
              <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-center shadow-2xs space-y-0.5">
                <Lock className="w-3.5 h-3.5 text-emerald-600 mx-auto" />
                <span className="font-extrabold text-[10px] block text-slate-800">Free SSL</span>
                <span className="text-[8px] text-slate-400 block">Let's Encrypt</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-center shadow-2xs space-y-0.5">
                <Globe className="w-3.5 h-3.5 text-blue-600 mx-auto" />
                <span className="font-extrabold text-[10px] block text-slate-800">Global CDN</span>
                <span className="text-[8px] text-slate-400 block">Ultra Fast</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-center shadow-2xs space-y-0.5">
                <RotateCw className="w-3.5 h-3.5 text-purple-600 mx-auto" />
                <span className="font-extrabold text-[10px] block text-slate-800">Backups</span>
                <span className="text-[8px] text-slate-400 block">Automatic</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 2. POWERFUL FEATURES FOR MODERN NODE.JS (HORIZONTAL DARK RIBBON BAR) */}
      {/* ========================================================================= */}
      <section className="bg-slate-900 text-white py-8 border-y border-slate-800">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm sm:text-base text-white tracking-tight flex items-center gap-2">
              <span>Powerful Features for Modern {stackData.title}</span>
            </h3>
            <a
              href="#pricing-grid"
              className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
            >
              <span>Explore All Features</span>
              <ArrowRight className="w-3 h-3" />
            </a>
          </div>

          {/* 12 Horizontal Feature Tiles */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 xl:grid-cols-12 gap-2.5">
            {ribbonFeatures.map((feat, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60 hover:border-emerald-500/80 hover:bg-slate-800 transition-all flex flex-col items-center text-center gap-1.5 group cursor-default"
              >
                <div className="p-2 rounded-lg bg-slate-900 group-hover:scale-110 transition-transform">
                  {feat.iconComp}
                </div>
                <span className="text-[10px] font-bold text-slate-300 leading-tight">
                  {feat.title}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 3. PRICING & DEPLOYMENT SECTION (FULL SECTION UI FROM zzzzzz.png) */}
      {/* ========================================================================= */}
      <section id="pricing-grid" className="py-14 px-4 sm:px-6 lg:px-8 max-w-[1360px] mx-auto space-y-12">
        {/* Full-width 4-Card Pricing Plan Grid matching zzzzzz.png */}
        <div className="rounded-3xl bg-white border border-slate-200/90 p-6 sm:p-10 shadow-sm">
          <PricingPlanGrid
            plans={allCategoryPlans[stack === 'wordpress' ? 'wordpress' : stack === 'cpanel' ? 'cpanel' : 'shared']}
            sectionTitle={`Choose Your Perfect ${stackData.title} Plan`}
            sectionSubtitle="High performance NVMe SSD hosting with transparent pricing, zero renewal surprise."
            categoryName={stackData.title}
            onDeployPlan={onDeployPlan}
          />
        </div>

        {/* 2-Column Companion Section: Deploy in Minutes + Global Infrastructure */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left Column: Deploy in Minutes Stepper */}
          <div className="lg:col-span-6 rounded-3xl bg-white border border-slate-200/90 p-6 sm:p-8 shadow-sm space-y-6 flex flex-col justify-between">
            <div>
              <h3 className="font-extrabold text-xl text-slate-900">Deploy in Minutes</h3>
              <p className="text-xs text-slate-500 mt-1">From code to live in just a few steps with automated DevOps pipelines.</p>
            </div>

            <div className="space-y-4">
              {[
                { step: '1', title: 'Connect Repository', desc: 'Link your Git repository (GitHub, GitLab, or Bitbucket) with one click.' },
                { step: '2', title: 'Configure Environment', desc: 'Set environment variables, branch, and automated build/start commands.' },
                { step: '3', title: 'Zero-Downtime Deploy', desc: 'One-click deployment with instant streaming build and runtime logs.' },
                { step: '4', title: 'Go Live with Global CDN', desc: 'Your app is live with automated Let\'s Encrypt SSL & edge caching!' },
              ].map((s) => (
                <div key={s.step} className="flex items-start gap-3.5 p-3 rounded-2xl bg-slate-50 border border-slate-100">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 text-white font-black text-xs flex items-center justify-center shrink-0 shadow-md shadow-emerald-500/20">
                    {s.step}
                  </div>
                  <div>
                    <h5 className="font-bold text-xs text-slate-900">{s.title}</h5>
                    <p className="text-[11px] text-slate-500 leading-snug">{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Global Infrastructure Card (Dark Blue with Map) */}
          <div className="lg:col-span-6 rounded-3xl bg-[#0b132b] text-white p-6 sm:p-8 shadow-xl border border-slate-800 space-y-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-cyan-400 mb-1">
                <Globe className="w-5 h-5" />
                <h4 className="font-black text-lg text-white">Global Edge Infrastructure</h4>
              </div>
              <p className="text-xs text-slate-400">
                Deploy your applications closer to your users with our enterprise carrier-neutral data centers.
              </p>
            </div>

            {/* Datacenters List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {datacenters.map((dc) => (
                <div
                  key={dc.city}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">{dc.flag}</span>
                    <span className="font-bold text-slate-200">{dc.country}</span>
                    <span className="text-[10px] text-slate-500">({dc.city})</span>
                  </div>
                  <span className="font-mono text-[10px] text-emerald-400 font-bold">{dc.ping}</span>
                </div>
              ))}
            </div>

            {/* Visual Vector World Map with pinging dots */}
            <div className="relative h-28 rounded-2xl bg-slate-900/60 border border-slate-800 p-3 overflow-hidden flex items-center justify-center">
              <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:12px_12px]" />
              <div className="relative text-center space-y-1">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Low Latency. High Performance.</span>
                </span>
                <p className="text-[10px] text-slate-400">Tier-IV Datacenters with 100% Redundant BGP &amp; DDoS Protection</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 4. BUILT FOR PERFORMANCE & SUPPORTED VERSIONS & TOOLS */}
      {/* ========================================================================= */}
      <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-[1360px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left Card: Built for Performance */}
          <div className="lg:col-span-6 rounded-3xl bg-white border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col justify-between space-y-6">
            <div>
              <h3 className="font-black text-2xl text-slate-900 tracking-tight">Built for Performance</h3>
              <p className="text-xs text-slate-500 mt-1">
                Optimized infrastructure for blazing fast {stackData.title} applications.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-4 text-xs">
                {[
                  'NVMe SSD Storage',
                  'Latest Node.js Versions',
                  'Optimized for High Concurrency',
                  'Global Load Balancing',
                  'Enterprise-Grade Security',
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span className="font-bold text-slate-800">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Center Visual 3D Server Block with Badges from Screenshot */}
            <div className="rounded-2xl bg-gradient-to-tr from-slate-900 to-slate-800 p-6 text-white relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="space-y-2">
                <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                  Ultra Fast NVMe SSD
                </span>
                <h4 className="font-black text-xl text-white">99.9% Uptime Guarantee</h4>
                <p className="text-xs text-slate-400">Direct carrier multi-homed BGP routing</p>
              </div>

              <div className="space-y-2 shrink-0">
                <div className="px-3 py-1.5 rounded-xl bg-slate-800/90 border border-slate-700 text-xs font-bold flex items-center gap-2 text-slate-200">
                  <RotateCw className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Auto Scaling</span>
                </div>
                <div className="px-3 py-1.5 rounded-xl bg-slate-800/90 border border-slate-700 text-xs font-bold flex items-center gap-2 text-slate-200">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>DDoS Protection</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Supported Versions + Developer Tools */}
          <div className="lg:col-span-6 space-y-6 flex flex-col justify-between">
            {/* Top: Supported Node.js Versions */}
            <div className="rounded-3xl bg-white border border-slate-200 p-6 shadow-sm space-y-3">
              <div>
                <h4 className="font-extrabold text-sm text-slate-900">Supported {stackData.title} Versions</h4>
                <p className="text-xs text-slate-500">Choose the version that works best for you.</p>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                {stackData.versions.map((ver) => {
                  const isActive = ver === activeVersion || ver.includes(activeVersion);
                  return (
                    <button
                      key={ver}
                      onClick={() => setActiveVersion(ver)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        isActive
                          ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20 font-black'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      {ver}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Bottom: Developer Tools Included */}
            <div className="rounded-3xl bg-white border border-slate-200 p-6 shadow-sm space-y-3">
              <div>
                <h4 className="font-extrabold text-sm text-slate-900">Developer Tools Included</h4>
                <p className="text-xs text-slate-500">Everything you need, right out of the box.</p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-1">
                {devTools.map((tool) => (
                  <div
                    key={tool.name}
                    className="p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50/50 border border-slate-200 text-center transition-colors space-y-1"
                  >
                    <span className="text-lg block">{tool.icon}</span>
                    <span className="text-[11px] font-bold text-slate-800 block">{tool.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. ONE PLATFORM. ENDLESS POSSIBILITIES & FREE MIGRATION CARD */}
      {/* ========================================================================= */}
      <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-[1360px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left: Endless Possibilities */}
          <div className="lg:col-span-7 rounded-3xl bg-white border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-black text-2xl text-slate-900 tracking-tight">
                  One Platform. <br />
                  Endless Possibilities.
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Build APIs, web apps, microservices, bots, and more with {stackData.title}.
                </p>
              </div>

              <button
                onClick={() => {
                  const devPlan = plans.find((p) => p.isPopular) || plans[0];
                  if (onDeployPlan) onDeployPlan(devPlan.name, `₹${devPlan.monthlyPrice}`);
                }}
                className="px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-xs shadow-md shadow-emerald-500/25 active:scale-95 transition-all flex items-center gap-1.5 self-start cursor-pointer"
              >
                <span>Start Building Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* 6 Bento Tiles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {possibilities.map((p, idx) => (
                <div key={idx} className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{p.icon}</span>
                    <h5 className="font-extrabold text-xs text-slate-900">{p.title}</h5>
                  </div>
                  <p className="text-[11px] text-slate-500">{p.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Migrate Your App for Free Card */}
          <div className="lg:col-span-5 rounded-3xl bg-gradient-to-tr from-slate-900 via-slate-900 to-emerald-950 text-white p-6 sm:p-8 shadow-xl border border-slate-800 flex flex-col justify-between space-y-5">
            <div className="space-y-3">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                <CheckCircle2 className="w-3 h-3" />
                <span>100% Free Migration</span>
              </div>

              <h3 className="font-black text-xl text-white tracking-tight">
                Migrate Your App for Free
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Already hosting elsewhere? We'll migrate your application completely free — with zero downtime.
              </p>

              <div className="space-y-2 pt-2 text-xs">
                {['No Downtime Guaranteed', 'Safe & Secure Migration', 'Handled by Senior DevOps Experts'].map((m, i) => (
                  <div key={i} className="flex items-center gap-2 text-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{m}</span>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                if (onOpenMigrationModal) onOpenMigrationModal();
              }}
              className="w-full py-3.5 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all cursor-pointer"
            >
              <span>Request Free Migration</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 6. WHAT DEVELOPERS SAY (IMPRESSIVE ANIMATED CAROUSEL) */}
      {/* ========================================================================= */}
      <ImpressiveReviewsCarousel />

      {/* ========================================================================= */}
      {/* 7. FAQS & INSTANT DEPLOYMENT CTA */}
      {/* ========================================================================= */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-[1360px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* FAQs Accordion (Expanded to 7 Columns) */}
          <div className="lg:col-span-7 rounded-3xl bg-white border border-slate-200 p-6 sm:p-8 shadow-sm space-y-5">
            <div>
              <h3 className="font-black text-2xl text-slate-900 tracking-tight">Frequently Asked Questions</h3>
              <p className="text-xs text-slate-500 mt-1">Find answers to common questions about our high performance hosting platform.</p>
            </div>

            <div className="space-y-3">
              {faqs.map((faq, idx) => {
                const isOpen = openFaqIndex === idx;
                return (
                  <div key={idx} className="border border-slate-200 rounded-2xl overflow-hidden transition-all">
                    <button
                      onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                      className="w-full p-4 text-left font-extrabold text-sm text-slate-900 flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer"
                    >
                      <span>{faq.q}</span>
                      <span className="text-lg font-black text-slate-400 shrink-0 ml-2">{isOpen ? '−' : '+'}</span>
                    </button>
                    {isOpen && (
                      <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs sm:text-sm text-slate-600 leading-relaxed animate-fade-in">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Neon Dark CTA Card (5 Columns) */}
          <div className="lg:col-span-5 rounded-3xl bg-slate-950 text-white p-6 sm:p-8 shadow-xl border border-slate-800 flex flex-col justify-between space-y-6 relative overflow-hidden">
            <div className="space-y-4">
              <h3 className="font-black text-2xl sm:text-3xl text-white tracking-tight leading-tight">
                Ready to Deploy <br />
                Your Next Big Idea?
              </h3>
              <p className="text-xs sm:text-sm text-slate-400">
                Join thousands of developers and teams who trust our {stackData.title} platform for speed, security, and 99.9% uptime.
              </p>

              {/* Neon Green Lightning Bolt graphic */}
              <div className="py-2">
                <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shadow-lg shadow-emerald-500/30">
                  <Zap className="w-8 h-8 fill-emerald-400" />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <button
                onClick={() => {
                  const devPlan = plans.find((p) => p.isPopular) || plans[0];
                  if (onDeployPlan) onDeployPlan(devPlan.name, `₹${devPlan.monthlyPrice}`);
                }}
                className="w-full py-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-sm shadow-lg shadow-emerald-500/30 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Get Started Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* 4 Micro Icons: Code, Deploy, Scale, Succeed */}
              <div className="grid grid-cols-4 gap-1 text-center text-xs text-slate-400 border-t border-slate-800 pt-4">
                <div>
                  <span className="block font-mono text-emerald-400 font-bold text-sm">{'{ }'}</span>
                  <span className="text-[11px]">Code</span>
                </div>
                <div>
                  <span className="block text-emerald-400 font-bold text-sm">⚡</span>
                  <span className="text-[11px]">Deploy</span>
                </div>
                <div>
                  <span className="block text-emerald-400 font-bold text-sm">📈</span>
                  <span className="text-[11px]">Scale</span>
                </div>
                <div>
                  <span className="block text-emerald-400 font-bold text-sm">🎯</span>
                  <span className="text-[11px]">Succeed</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

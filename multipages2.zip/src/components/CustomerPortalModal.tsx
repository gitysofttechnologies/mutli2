import React, { useState } from 'react';
import {
  X,
  User,
  Server,
  Globe,
  FileText,
  LifeBuoy,
  CreditCard,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Plus,
  Send,
  Database,
  Mail,
  HardDrive,
  Activity,
  ArrowRight,
} from 'lucide-react';
import { useConfig } from '../context/ConfigContext';
import { CustomerService, SupportTicket, InvoiceRecord } from '../types/hosting';
import {
  initialCustomerServices,
  initialSupportTickets,
  initialInvoices,
} from '../data/customerAndDbData';

interface CustomerPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CustomerPortalModal: React.FC<CustomerPortalModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { showToast } = useConfig();
  const [activeTab, setActiveTab] = useState<'services' | 'domains' | 'billing' | 'tickets'>('services');

  // Customer state
  const [services, setServices] = useState<CustomerService[]>(initialCustomerServices);
  const [tickets, setTickets] = useState<SupportTicket[]>(initialSupportTickets);
  const [invoices, setInvoices] = useState<InvoiceRecord[]>(initialInvoices);

  // New Ticket form
  const [newTicketSubject, setNewTicketSubject] = useState('');
  const [newTicketDept, setNewTicketDept] = useState<'Technical Support' | 'Billing' | 'Migration' | 'Sales'>('Technical Support');
  const [newTicketMessage, setNewTicketMessage] = useState('');
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [ticketReplyText, setTicketReplyText] = useState('');

  if (!isOpen) return null;

  const handlePayInvoice = (invId: string) => {
    setInvoices((prev) =>
      prev.map((inv) =>
        inv.id === invId ? { ...inv, status: 'Paid', paymentMethod: 'UPI (Paid)' } : inv
      )
    );
    showToast('✓ Invoice marked as Paid via UPI!');
  };

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTicketSubject.trim() || !newTicketMessage.trim()) return;

    const newTicket: SupportTicket = {
      id: `TKT-${Math.floor(1000 + Math.random() * 9000)}`,
      subject: newTicketSubject,
      department: newTicketDept,
      status: 'Open',
      priority: 'High',
      lastUpdated: 'Just now',
      messages: [
        {
          sender: 'user',
          senderName: 'Account Owner',
          timestamp: 'Just now',
          content: newTicketMessage,
        },
      ],
    };

    setTickets([newTicket, ...tickets]);
    setNewTicketSubject('');
    setNewTicketMessage('');
    showToast('✓ Support ticket submitted! Assigned to Senior Engineer.');
  };

  const handleSendReply = (ticketId: string) => {
    if (!ticketReplyText.trim()) return;

    setTickets((prev) =>
      prev.map((t) => {
        if (t.id === ticketId) {
          return {
            ...t,
            lastUpdated: 'Just now',
            messages: [
              ...t.messages,
              {
                sender: 'user',
                senderName: 'Account Owner',
                timestamp: 'Just now',
                content: ticketReplyText,
              },
            ],
          };
        }
        return t;
      })
    );
    setTicketReplyText('');
    showToast('✓ Reply posted to ticket.');
  };

  const selectedTicket = tickets.find((t) => t.id === selectedTicketId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="w-full max-w-5xl bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] my-auto">
        {/* Top Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-slate-950 font-black shadow-md">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight">
                  Customer Client Portal
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Verified Client
                </span>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                Account ID: #CL-9842 · info@gitysoft.com
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="bg-slate-100/80 border-b border-slate-200 px-6 py-2 flex items-center justify-between gap-3 overflow-x-auto shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setActiveTab('services');
                setSelectedTicketId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'services'
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Server className="w-4 h-4 text-emerald-600" />
              <span>Active Services ({services.length})</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('domains');
                setSelectedTicketId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'domains'
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Globe className="w-4 h-4 text-blue-600" />
              <span>Domains &amp; DNS</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('billing');
                setSelectedTicketId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'billing'
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CreditCard className="w-4 h-4 text-purple-600" />
              <span>Billing &amp; Invoices</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('tickets');
                setSelectedTicketId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'tickets'
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LifeBuoy className="w-4 h-4 text-amber-600" />
              <span>Support Tickets ({tickets.length})</span>
            </button>
          </div>

          <div className="text-right hidden sm:block">
            <span className="text-[10px] text-slate-500 font-semibold block uppercase">
              Credit Balance
            </span>
            <span className="text-xs font-black text-emerald-600">₹0.00 (Active)</span>
          </div>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: ACTIVE SERVICES */}
          {activeTab === 'services' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-black text-slate-900">Your Active Hosting Products</h3>
                  <p className="text-xs text-slate-500">
                    Manage servers, cPanel logins, databases, and resource allocations.
                  </p>
                </div>
                <button
                  onClick={() => {
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-[#635bff] text-white text-xs font-bold hover:bg-[#5249e0] transition-colors shadow-xs"
                >
                  + Order New Service
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {services.map((srv) => {
                  const diskPct = Math.round((srv.diskUsedMB / srv.diskTotalMB) * 100);
                  const bwPct = Math.round((srv.bandwidthUsedGB / srv.bandwidthTotalGB) * 100);

                  return (
                    <div
                      key={srv.id}
                      className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">
                            {srv.status}
                          </span>
                          <span className="text-xs font-bold text-slate-500">
                            ₹{srv.amountINR}/{srv.billingCycle === 'yearly' ? 'yr' : 'mo'}
                          </span>
                        </div>

                        <h4 className="text-base font-black text-slate-900 tracking-tight">
                          {srv.planName}
                        </h4>
                        <span className="text-xs text-blue-600 font-mono font-semibold block mb-3 hover:underline cursor-pointer">
                          https://{srv.domain}
                        </span>

                        <div className="space-y-2 text-xs font-mono text-slate-600 pb-3 border-b border-slate-100 mb-3">
                          <div className="flex justify-between">
                            <span className="text-slate-400">Server IP:</span>
                            <span className="font-bold text-slate-800">{srv.serverIp}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">cPanel User:</span>
                            <span className="text-slate-800 font-bold">{srv.cpanelUsername}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Renews On:</span>
                            <span>{srv.nextDueDate}</span>
                          </div>
                        </div>

                        {/* Disk & Bandwidth Progress Bars */}
                        <div className="space-y-2 text-[11px] mb-4">
                          <div>
                            <div className="flex justify-between text-slate-600 mb-0.5">
                              <span>NVMe Storage</span>
                              <span>
                                {Math.round(srv.diskUsedMB / 1024)}GB / {Math.round(srv.diskTotalMB / 1024)}GB ({diskPct}%)
                              </span>
                            </div>
                            <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
                              <div
                                className="h-full bg-indigo-500 rounded-full"
                                style={{ width: `${diskPct}%` }}
                              />
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between text-slate-600 mb-0.5">
                              <span>Monthly Bandwidth</span>
                              <span>
                                {srv.bandwidthUsedGB}GB / {srv.bandwidthTotalGB}GB ({bwPct}%)
                              </span>
                            </div>
                            <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
                              <div
                                className="h-full bg-emerald-500 rounded-full"
                                style={{ width: `${bwPct}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Quick cPanel / Webmail / Database Launcher */}
                      <div className="grid grid-cols-3 gap-1.5 pt-2 border-t border-slate-100">
                        <button
                          onClick={() => showToast(`✓ Connected to cPanel session for ${srv.domain}`)}
                          className="p-1.5 rounded-lg bg-orange-50 hover:bg-orange-100 text-orange-700 text-[10px] font-bold text-center transition-colors"
                        >
                          cPanel
                        </button>
                        <button
                          onClick={() => showToast(`✓ Opening phpMyAdmin for ${srv.domain}`)}
                          className="p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-[10px] font-bold text-center transition-colors"
                        >
                          phpMyAdmin
                        </button>
                        <button
                          onClick={() => showToast(`✓ Direct Webmail SSO launched for ${srv.domain}`)}
                          className="p-1.5 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-700 text-[10px] font-bold text-center transition-colors"
                        >
                          Webmail
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: DOMAINS & DNS */}
          {activeTab === 'domains' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-black text-slate-900">Domains &amp; Cloud DNS Zones</h3>
                <p className="text-xs text-slate-500">
                  Manage domain name servers, DNS records (A, CNAME, MX, TXT), and Auto-Renewal.
                </p>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-slate-200">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase">
                    <tr>
                      <th className="p-3">Domain</th>
                      <th className="p-3">Primary Nameserver</th>
                      <th className="p-3">Auto-Renew</th>
                      <th className="p-3">Status</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr className="hover:bg-slate-50/50">
                      <td className="p-3 font-bold text-slate-900">mytechstartup.in</td>
                      <td className="p-3 font-mono text-slate-600">ns1.cloudhost.io</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700">
                          Enabled
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="text-emerald-600 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Active
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => showToast('✓ DNS Zone Editor opened.')}
                          className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 font-bold text-[11px]"
                        >
                          Manage DNS
                        </button>
                      </td>
                    </tr>
                    <tr className="hover:bg-slate-50/50">
                      <td className="p-3 font-bold text-slate-900">bestshoestore.com</td>
                      <td className="p-3 font-mono text-slate-600">ns1.cloudhost.io</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700">
                          Enabled
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="text-emerald-600 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Active
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => showToast('✓ DNS Zone Editor opened.')}
                          className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 font-bold text-[11px]"
                        >
                          Manage DNS
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: BILLING & INVOICES */}
          {activeTab === 'billing' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-black text-slate-900">Invoices &amp; Transaction History</h3>
                <p className="text-xs text-slate-500">
                  Pay outstanding hosting dues via UPI / Cards and download GST tax receipts.
                </p>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-slate-200">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase">
                    <tr>
                      <th className="p-3">Invoice #</th>
                      <th className="p-3">Date</th>
                      <th className="p-3">Description</th>
                      <th className="p-3">Amount</th>
                      <th className="p-3">Status</th>
                      <th className="p-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {invoices.map((inv) => (
                      <tr key={inv.id} className="hover:bg-slate-50/50">
                        <td className="p-3 font-bold text-slate-900 font-mono">{inv.invoiceNumber}</td>
                        <td className="p-3 text-slate-600">{inv.date}</td>
                        <td className="p-3 text-slate-700 font-medium">{inv.description}</td>
                        <td className="p-3 font-black text-slate-900">₹{inv.amountINR}.00</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              inv.status === 'Paid'
                                ? 'bg-emerald-50 text-emerald-700'
                                : 'bg-rose-50 text-rose-700'
                            }`}
                          >
                            {inv.status}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          {inv.status === 'Unpaid' ? (
                            <button
                              onClick={() => handlePayInvoice(inv.id)}
                              className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                            >
                              Pay Now (UPI)
                            </button>
                          ) : (
                            <button
                              onClick={() => showToast(`✓ Downloading PDF receipt for ${inv.invoiceNumber}`)}
                              className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px]"
                            >
                              Download PDF
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: SUPPORT TICKETS */}
          {activeTab === 'tickets' && (
            <div className="space-y-6">
              {selectedTicket ? (
                /* Ticket Detail & Live Reply View */
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <button
                      onClick={() => setSelectedTicketId(null)}
                      className="text-xs font-bold text-[#635bff] hover:underline"
                    >
                      ← Back to All Tickets
                    </button>
                    <span className="text-xs font-mono font-bold text-slate-500">
                      {selectedTicket.id} · {selectedTicket.department}
                    </span>
                  </div>

                  <h3 className="text-lg font-black text-slate-900">
                    {selectedTicket.subject}
                  </h3>

                  <div className="space-y-3">
                    {selectedTicket.messages.map((msg, i) => (
                      <div
                        key={i}
                        className={`p-4 rounded-2xl ${
                          msg.sender === 'agent'
                            ? 'bg-blue-50/80 border border-blue-200 ml-4'
                            : 'bg-slate-100 border border-slate-200 mr-4'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="font-bold text-slate-900">{msg.senderName}</span>
                          <span className="text-slate-400 font-mono text-[10px]">{msg.timestamp}</span>
                        </div>
                        <p className="text-xs text-slate-700 leading-relaxed">{msg.content}</p>
                      </div>
                    ))}
                  </div>

                  {/* Reply Input Box */}
                  <div className="pt-2 flex items-center gap-2">
                    <input
                      type="text"
                      placeholder="Type your message to the support engineering team..."
                      value={ticketReplyText}
                      onChange={(e) => setTicketReplyText(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendReply(selectedTicket.id)}
                      className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 text-xs focus:outline-hidden focus:border-[#635bff]"
                    />
                    <button
                      onClick={() => handleSendReply(selectedTicket.id)}
                      className="px-4 py-2.5 rounded-xl bg-[#635bff] text-white text-xs font-bold flex items-center gap-1.5 hover:bg-[#5249e0]"
                    >
                      <span>Send</span>
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                /* Ticket List + New Ticket Form */
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Left: Open Tickets List */}
                  <div className="lg:col-span-7 space-y-3">
                    <h3 className="text-base font-black text-slate-900">Support History</h3>
                    <div className="space-y-2">
                      {tickets.map((t) => (
                        <div
                          key={t.id}
                          onClick={() => setSelectedTicketId(t.id)}
                          className="p-4 rounded-2xl border border-slate-200 hover:border-purple-300 bg-white shadow-xs hover:shadow-sm cursor-pointer transition-all flex items-center justify-between"
                        >
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-mono text-xs font-bold text-slate-500">{t.id}</span>
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700">
                                {t.status}
                              </span>
                            </div>
                            <h4 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1">
                              {t.subject}
                            </h4>
                            <span className="text-[11px] text-slate-400">
                              {t.department} · Updated {t.lastUpdated}
                            </span>
                          </div>
                          <ArrowRight className="w-4 h-4 text-slate-400" />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Right: Submit New Ticket */}
                  <div className="lg:col-span-5 p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                    <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                      Open New Support Ticket
                    </h4>
                    <form onSubmit={handleCreateTicket} className="space-y-3">
                      <div>
                        <label className="text-[11px] font-bold text-slate-700 block mb-1">
                          Department
                        </label>
                        <select
                          value={newTicketDept}
                          onChange={(e) => setNewTicketDept(e.target.value as any)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-medium focus:outline-hidden"
                        >
                          <option value="Technical Support">Technical Support (cPanel/Server)</option>
                          <option value="Migration">Migration Concierge</option>
                          <option value="Billing">Billing &amp; Invoices</option>
                          <option value="Sales">Sales &amp; Enterprise Custom</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-slate-700 block mb-1">
                          Subject
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. PHP 8.4 Extension Request"
                          value={newTicketSubject}
                          onChange={(e) => setNewTicketSubject(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs focus:outline-hidden"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-slate-700 block mb-1">
                          Detailed Message
                        </label>
                        <textarea
                          rows={3}
                          required
                          placeholder="Provide details about your query or server domain..."
                          value={newTicketMessage}
                          onChange={(e) => setNewTicketMessage(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs focus:outline-hidden"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-sm transition-all"
                      >
                        Submit Ticket
                      </button>
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  FileCode,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Search,
  ExternalLink,
  Copy,
  ChevronRight,
  Layers,
  Sparkles,
  Smartphone,
  Server,
  Zap,
  Globe2,
  X,
  Code2,
  Info,
  Terminal,
} from 'lucide-react';

interface ChangesAuditModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToPage?: (pageId: string) => void;
}

interface AuditRecord {
  id: string;
  time: string;
  category: 'Sender ID' | 'Hero Title' | 'SMS Panel' | 'Hosting Pages' | 'Clean Up';
  title: string;
  description: string;
  files: string[];
  status: 'Verified & Active' | 'Completed';
  color: string;
}

export const ChangesAuditModal: React.FC<ChangesAuditModalProps> = ({
  isOpen,
  onClose,
  onNavigateToPage,
}) => {
  const [activeTab, setActiveTab] = useState<'timeline' | 'hosting-list' | 'files' | 'how-to'>('timeline');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2500);
  };

  const auditHistory: AuditRecord[] = [
    {
      id: 'AUD-013',
      time: 'Just now',
      category: 'Hosting Pages',
      title: 'Functional TITAN Webmail Dashboard Built in Hero Section',
      description: 'Built a pixel-perfect, fully operational replica of the user-uploaded TITAN Email Dashboard directly in the Business Email hero section with proper height (h-[740px]) and responsive full-width. Features authentic top navbar with Search and "New email", left sidebar with 6 app tiles (Mail, Calendar, Contacts, Bookings, Drive, Tasks) + tool links (Signature Designer, Smart Write AI, Invoice Builder), middle pane with Priority (99+) and Other (99+) email rows with unread dots and reading view, right sidebar with Sep 2026 calendar picker, hourly GMT+05:30 schedule slots and interactive Tasks checklist, and interactive compose modal with Smart Write AI auto-drafting.',
      files: ['src/components/dashboards/FunctionalTitanEmailDashboard.tsx', 'src/components/pages/BusinessEmailPage.tsx'],
      status: 'Verified & Active',
      color: 'bg-blue-50 text-blue-700 border-blue-200',
    },
    {
      id: 'AUD-012',
      time: '5 mins ago',
      category: 'Hosting Pages',
      title: 'Dedicated Business Email Webpage Built (Next.js/React + 10-Yr Term Pricing)',
      description: 'Created a complete Business Email webpage with dynamic 1 to 10 years term pricing (up to 25% extra lock-in savings), 4 tiered plans (Pro Light, Pro Plus, Premium, Ultra), Gitysoft vs GoDaddy/Bigrock/Hostinger/Resellerclub competitive pricing comparison table, glassmorphism features, interactive startup/agency workflow tabs, live Webmail & Titan AI draft simulator, and all 17 comprehensive FAQs in a 2/2 modern accordion grid.',
      files: ['src/components/pages/BusinessEmailPage.tsx', 'src/App.tsx'],
      status: 'Verified & Active',
      color: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    },
    {
      id: 'AUD-011',
      time: '5 mins ago',
      category: 'SMS Panel',
      title: 'Bulk SMS FAQs Converted to 2/2 Column Modern Accordion Grid',
      description: 'Upgraded Bulk SMS FAQs to a responsive 2/2 column layout (4 FAQs on left, 4 on right) with modern accordion styling, numbered badges (01-08), category tags, smooth plus/minus animated triggers, and independent toggle states.',
      files: ['src/components/bulksms/FaqSection.tsx'],
      status: 'Verified & Active',
      color: 'bg-rose-50 text-rose-700 border-rose-200',
    },
    {
      id: 'AUD-010',
      time: '5 mins ago',
      category: 'Hosting Pages',
      title: 'Functional WordPress, cPanel Jupiter & WHM Dashboards Added',
      description: 'Built 3 live interactive operational control panels: 1) Authentic WordPress Dashboard with WP Admin bar, Quick Draft creator, active plugins manager, posts table, and LiteSpeed Cache purge. 2) Authentic cPanel Jupiter Dashboard with live File Manager, Email Account creator, MySQL Database provisioner, and AutoSSL. 3) Authentic WebHost Manager (WHM) Reseller Dashboard with client cPanel accounts table, account creator, and white-label nameserver settings.',
      files: [
        'src/components/dashboards/FunctionalWordPressDashboard.tsx',
        'src/components/dashboards/FunctionalCPanelDashboard.tsx',
        'src/components/dashboards/FunctionalWhmDashboard.tsx',
        'src/components/pages/WordPressHostingPage.tsx',
        'src/components/pages/CPanelHostingPage.tsx',
        'src/components/pages/ResellerHostingPage.tsx',
      ],
      status: 'Verified & Active',
      color: 'bg-blue-50 text-blue-700 border-blue-200',
    },
    {
      id: 'AUD-009',
      time: '5 mins ago',
      category: 'Clean Up',
      title: 'Removed "Need Help? We\'re Here 24/7" from All Hosting Pages',
      description: 'Removed the "Need Help? We\'re Here 24/7" 3-channel support box across all hosting pages per user request. Re-balanced the layout into a spacious 2-column grid: FAQs expanded to 7 columns and Instant Deployment CTA to 5 columns.',
      files: ['src/components/pages/ModernHostingPage.tsx', 'src/components/common/UnifiedTechHostingTemplate.tsx'],
      status: 'Verified & Active',
      color: 'bg-rose-50 text-rose-700 border-rose-200',
    },
    {
      id: 'AUD-008',
      time: '5 mins ago',
      category: 'Clean Up',
      title: 'Footers Removed, Pricing Tooltips & Impressive Review Carousel Added',
      description: 'Removed all footer sections across all pages per user request. Added rich interactive floating tooltips on all hosting resources & perks in PricingPlanGrid. Built an impressive animated Testimonials Carousel with verified customer badges, speed metrics, 5.0 rating, auto-sliding, and quick-picker avatars.',
      files: ['src/App.tsx', 'src/components/PricingPlanGrid.tsx', 'src/components/common/ImpressiveReviewsCarousel.tsx', 'src/components/pages/ModernHostingPage.tsx'],
      status: 'Verified & Active',
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    },
    {
      id: 'AUD-007',
      time: '5 mins ago',
      category: 'Hosting Pages',
      title: 'Full-Section Pricing Plan UI Implemented (Matching zzzzzz.png)',
      description: 'Implemented the exact 4-card pricing layout across ALL hosting webpages: Basic (₹69/mo, 77% OFF), Pro (₹99/mo, 75% OFF with purple border & solid purple button), Premium (₹169/mo, 66% OFF with MOST POPULAR dark purple star ribbon), and Platinum (₹399/mo, 69% OFF). Features mint green PERKS & INCLUSIONS box, badges, underlined resource specs, and transparent renewal guarantee.',
      files: ['src/components/PricingPlanGrid.tsx', 'src/components/pages/ModernHostingPage.tsx'],
      status: 'Verified & Active',
      color: 'bg-purple-50 text-purple-700 border-purple-200',
    },
    {
      id: 'AUD-006',
      time: '10 mins ago',
      category: 'Hosting Pages',
      title: 'Modern Developer Hosting UI Implemented (Matching Screenshot)',
      description: 'Built high-fidelity developer landing page matching user screenshot: Interactive code editor with language tabs, live server performance dials (CPU/RAM/Disk/Network), 3-column deployment stepper & pricing grid, global infrastructure with latency map, supported versions switcher, 6 endless possibilities bento cards, and 24/7 support bar.',
      files: ['src/components/pages/ModernHostingPage.tsx', 'src/App.tsx'],
      status: 'Verified & Active',
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    },
    {
      id: 'AUD-005',
      time: '15 mins ago',
      category: 'Clean Up',
      title: 'Removed 5 Route Badges Below Hero Title',
      description: 'Per user request, removed the 5 pill buttons (📣 Promotional SMS, ⚡ Transactional SMS, 🔒 OTP SMS, 🔔 Alert SMS, 🚀 Marketing SMS) from below the hero title for a cleaner layout.',
      files: ['src/components/bulksms/BulkSmsHero.tsx'],
      status: 'Verified & Active',
      color: 'bg-rose-50 text-[#e11d48] border-rose-200',
    },
    {
      id: 'AUD-004',
      time: '10 mins ago',
      category: 'Hero Title',
      title: 'Multi-Colour Auto Fade-Right Animation in Hero Title',
      description: 'Synchronized text word and colour gradient transition every 2.2s. When colour changes, the text word simultaneously fades in smoothly from left to right (translateX -28px to 0, opacity 0 to 1).',
      files: ['src/components/bulksms/BulkSmsHero.tsx', 'src/index.css'],
      status: 'Verified & Active',
      color: 'bg-purple-50 text-purple-700 border-purple-200',
    },
    {
      id: 'AUD-003',
      time: '20 mins ago',
      category: 'Sender ID',
      title: 'Set Default Sender ID to "GITYSFT" in Panel Dashboard',
      description: 'Updated default active Sender ID to "GITYSFT" with character counter 7 / 7, added GITYSFT (10482) as default selected in the Sender ID table, updated sent records, cURL API samples, and DLT mappings.',
      files: ['src/components/bulksms/SmsPanelDashboard.tsx'],
      status: 'Verified & Active',
      color: 'bg-blue-50 text-blue-700 border-blue-200',
    },
    {
      id: 'AUD-002',
      time: '45 mins ago',
      category: 'SMS Panel',
      title: 'Created Dynamic Functional SMS Panel Dashboard',
      description: 'Pixel-perfect functional dashboard matching screenshot: Left sidebar with Send SMS, Delivery Report, Developer API, DLT; Top bar with Recharge Account button; 2-column composer & Sender ID table with operator upload.',
      files: [
        'src/components/bulksms/SmsPanelDashboard.tsx',
        'src/components/bulksms/ResellerPanelSection.tsx',
        'src/App.tsx',
      ],
      status: 'Verified & Active',
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    },
    {
      id: 'AUD-001',
      time: '1 hour ago',
      category: 'Hosting Pages',
      title: 'Complete Hosting Pages Suite & Database Integration',
      description: 'All 7 web hosting pages available (Shared, WordPress, cPanel, Business, Indian, Reseller, Cloud) with MySQL schema, pricing grids, and currency switcher.',
      files: [
        'src/components/pages/SharedHostingPage.tsx',
        'src/components/pages/WordPressHostingPage.tsx',
        'src/components/pages/CPanelHostingPage.tsx',
        'src/components/pages/BusinessHostingPage.tsx',
        'src/components/pages/IndianHostingPage.tsx',
        'src/components/pages/ResellerHostingPage.tsx',
      ],
      status: 'Completed',
      color: 'bg-amber-50 text-amber-700 border-amber-200',
    },
  ];

  const allHostingPages = [
    {
      id: 'bulksms',
      name: 'Bulk SMS Platform',
      icon: <Smartphone className="w-4 h-4 text-[#e11d48]" />,
      badge: 'Live Gateway',
      desc: 'Bulk SMS Portal, SMS Panel Dashboard, Promotional, Transactional & OTP Routes.',
      file: 'src/components/bulksms/BulkSmsHero.tsx',
    },
    {
      id: 'shared',
      name: 'Shared Web Hosting',
      icon: <Zap className="w-4 h-4 text-cyan-600]" />,
      badge: 'Popular',
      desc: 'cPanel NVMe SSD hosting with CloudLinux, CageFS isolation & PHP 8.3/8.4 switcher.',
      file: 'src/components/pages/SharedHostingPage.tsx',
    },
    {
      id: 'wordpress',
      name: 'Managed WordPress Hosting',
      icon: <Globe2 className="w-4 h-4 text-blue-600" />,
      badge: 'LiteSpeed Turbo',
      desc: 'WordPress-optimized hosting with LSCache, automated core updates, and staging tools.',
      file: 'src/components/pages/WordPressHostingPage.tsx',
    },
    {
      id: 'cpanel',
      name: 'cPanel NVMe Hosting',
      icon: <Layers className="w-4 h-4 text-amber-600" />,
      badge: 'Softaculous 400+',
      desc: 'Official cPanel license with 1-click script installer and automated daily backups.',
      file: 'src/components/pages/CPanelHostingPage.tsx',
    },
    {
      id: 'business',
      name: 'Business Enterprise Hosting',
      icon: <ShieldCheck className="w-4 h-4 text-emerald-600" />,
      badge: '99.99% SLA',
      desc: 'High-RAM enterprise tier with dedicated CPU cores and priority support hotline.',
      file: 'src/components/pages/BusinessHostingPage.tsx',
    },
    {
      id: 'indian',
      name: 'Indian Web Hosting (Mumbai DC)',
      icon: <span className="text-base">🇮🇳</span>,
      badge: '<10ms Ping',
      desc: 'Located in Mumbai Tier-IV datacenters for ultra-fast domestic loading speeds.',
      file: 'src/components/pages/IndianHostingPage.tsx',
    },
    {
      id: 'reseller',
      name: 'Reseller Web Hosting',
      icon: <Server className="w-4 h-4 text-purple-600" />,
      badge: '100% White-Label',
      desc: 'WHM control panel with private nameservers to start your own web hosting company.',
      file: 'src/components/pages/ResellerHostingPage.tsx',
    },
    {
      id: 'cloud',
      name: 'Cloud Infrastructure & VPS Hosting',
      icon: <Sparkles className="w-4 h-4 text-indigo-600" />,
      badge: 'Scale-On-Demand',
      desc: 'Virtual instances with dedicated NVMe, root access, and customizable environments.',
      file: 'src/components/PricingSection.tsx',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden text-slate-800">
        {/* Modal Top Bar */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#e11d48] to-purple-600 flex items-center justify-center shadow-md">
              <FileCode className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-black text-base text-white tracking-tight flex items-center gap-2">
                <span>Changes Audit &amp; Hosting Pages List</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/30">
                  LIVE SYNCED
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Audit all recent updates, verify modified components, and switch between hosting pages.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-200 bg-slate-50 text-xs font-bold overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('timeline')}
            className={`pb-3 px-3 transition-colors border-b-2 flex items-center gap-2 cursor-pointer ${
              activeTab === 'timeline'
                ? 'border-[#e11d48] text-[#e11d48]'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Recent Changes Audit ({auditHistory.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('hosting-list')}
            className={`pb-3 px-3 transition-colors border-b-2 flex items-center gap-2 cursor-pointer ${
              activeTab === 'hosting-list'
                ? 'border-[#e11d48] text-[#e11d48]'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Server className="w-4 h-4" />
            <span>All Hosting Pages List ({allHostingPages.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('how-to')}
            className={`pb-3 px-3 transition-colors border-b-2 flex items-center gap-2 cursor-pointer ${
              activeTab === 'how-to'
                ? 'border-[#e11d48] text-[#e11d48]'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Info className="w-4 h-4" />
            <span>Changes Audit Kaise Karein? (Guide)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {/* TAB 1: AUDIT TIMELINE */}
          {activeTab === 'timeline' && (
            <div className="space-y-3.5">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Total verified changes executed in this session:</span>
                <span className="font-bold text-slate-800 font-mono">5 Commits / Updates</span>
              </div>

              <div className="space-y-3">
                {auditHistory.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl border border-slate-200/90 bg-white hover:border-slate-300 shadow-2xs transition-all space-y-2"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${item.color}`}>
                          {item.category}
                        </span>
                        <h4 className="font-extrabold text-sm text-slate-900">{item.title}</h4>
                      </div>
                      <span className="text-[11px] font-mono text-slate-400 shrink-0">{item.time}</span>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">{item.description}</p>

                    <div className="pt-1 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 text-[11px]">
                      <div className="flex items-center gap-1.5 font-mono text-slate-500">
                        <Code2 className="w-3.5 h-3.5 text-slate-400" />
                        <span>Files: {item.files.join(', ')}</span>
                      </div>
                      <span className="flex items-center gap-1 font-bold text-emerald-600">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{item.status}</span>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: ALL HOSTING PAGES LIST */}
          {activeTab === 'hosting-list' && (
            <div className="space-y-4">
              <div className="bg-sky-50 border border-sky-200 rounded-2xl p-4 text-xs text-sky-900 flex items-start gap-3">
                <Info className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-bold">Aapke sabhi hosting aur SMS pages yaha listed hain:</p>
                  <p>
                    Aap kisi bhi page par click karke turant us page ko live view kar sakte hain ya audit kar sakte hain!
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {allHostingPages.map((pg) => (
                  <div
                    key={pg.id}
                    className="p-4 rounded-2xl border border-slate-200/90 bg-white hover:border-[#e11d48] shadow-2xs hover:shadow-md transition-all flex flex-col justify-between group space-y-3"
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center">
                            {pg.icon}
                          </div>
                          <span className="font-extrabold text-xs text-slate-900">{pg.name}</span>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[10px]">
                          {pg.badge}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 leading-relaxed">{pg.desc}</p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                      <span className="text-[10px] font-mono text-slate-400 truncate max-w-[170px]">
                        {pg.file}
                      </span>
                      <button
                        onClick={() => {
                          if (onNavigateToPage) onNavigateToPage(pg.id);
                          onClose();
                        }}
                        className="px-3 py-1 rounded-lg bg-slate-900 hover:bg-[#e11d48] text-white font-bold text-xs flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <span>View Page</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: HOW TO AUDIT GUIDE */}
          {activeTab === 'how-to' && (
            <div className="space-y-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-900 text-slate-100 space-y-3">
                <h4 className="font-black text-sm text-white flex items-center gap-2">
                  <span>Changes Audit Kaise Karein? (Step-by-Step Guide)</span>
                </h4>
                <p className="text-slate-300 leading-relaxed text-xs">
                  Aap application me huye sabhi code changes aur pages ko 3 aasaan tareeqon se audit kar sakte hain:
                </p>

                <div className="space-y-2.5 pt-1">
                  <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 space-y-1">
                    <span className="font-bold text-emerald-400 block">1. Live Page Navigator se Test Karein:</span>
                    <p className="text-slate-300">
                      Top bar me <strong>"Hosting Pages"</strong> dropdown ya is Modal ke <em>"All Hosting Pages List"</em> tab se kisi bhi hosting page (Shared, WordPress, cPanel, Indian, Reseller, Cloud) par 1-click karke direct view karein.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 space-y-1">
                    <span className="font-bold text-sky-400 block">2. Panel Dashboard me GITYSFT Sender ID Audit:</span>
                    <p className="text-slate-300">
                      Top bar me <strong>"Live SMS Panel"</strong> button click karein. Sender ID box me <code>GITYSFT</code> check karein, character counter <code>7 / 7</code> check karein, aur right side table me default selection check karein.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 space-y-1">
                    <span className="font-bold text-purple-400 block">3. Hero Title Auto Fade-Right Audit:</span>
                    <p className="text-slate-300">
                      Hero section me title dekhein: Har 2.2 seconds me word aur uska colour gradient ek sath left se right fade hota hai (Promotional, Transactional, OTP, Alert, Marketing SMS).
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
                <span className="font-bold text-slate-800">Source Files Checklist:</span>
                <ul className="space-y-1 font-mono text-[11px] text-slate-600">
                  <li>• <code>src/components/bulksms/SmsPanelDashboard.tsx</code> (Sender ID &amp; Dynamic Panel)</li>
                  <li>• <code>src/components/bulksms/BulkSmsHero.tsx</code> (Auto Fade-Right Title)</li>
                  <li>• <code>src/components/pages/SharedHostingPage.tsx</code> (Shared Hosting)</li>
                  <li>• <code>src/components/pages/WordPressHostingPage.tsx</code> (WordPress Hosting)</li>
                  <li>• <code>src/components/pages/IndianHostingPage.tsx</code> (Indian Hosting)</li>
                  <li>• <code>src/components/pages/CPanelHostingPage.tsx</code> (cPanel Hosting)</li>
                  <li>• <code>src/components/pages/BusinessHostingPage.tsx</code> (Business Hosting)</li>
                  <li>• <code>src/components/pages/ResellerHostingPage.tsx</code> (Reseller Hosting)</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-500 font-mono text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>AI Studio Dev Server: Port 3000 Active</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs cursor-pointer shadow-xs"
          >
            Close Audit
          </button>
        </div>
      </div>
    </div>
  );
};

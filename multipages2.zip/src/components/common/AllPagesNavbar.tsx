import React from 'react';
import { HostingCategory } from '../../types/hosting';

interface AllPagesNavbarProps {
  activeCategory: HostingCategory;
  onSelectCategory: (cat: HostingCategory) => void;
}

export const AllPagesNavbar: React.FC<AllPagesNavbarProps> = ({
  activeCategory,
  onSelectCategory,
}) => {
  const pages: {
    id: HostingCategory;
    label: string;
    badge?: string;
    icon: string;
    accentColor: string;
  }[] = [
    {
      id: 'shared',
      label: 'Shared Hosting',
      badge: 'LiteSpeed',
      icon: '⚡',
      accentColor: 'border-cyan-500 text-cyan-600',
    },
    {
      id: 'wordpress',
      label: 'WordPress Hosting',
      badge: 'Turbo WP',
      icon: '🚀',
      accentColor: 'border-blue-500 text-blue-600',
    },
    {
      id: 'indian',
      label: 'Indian Hosting',
      badge: 'Tier-4 <10ms',
      icon: '🇮🇳',
      accentColor: 'border-orange-500 text-orange-600',
    },
    {
      id: 'reseller',
      label: 'Reseller Hosting',
      badge: 'WHM White-label',
      icon: '💼',
      accentColor: 'border-purple-500 text-purple-600',
    },
    {
      id: 'cpanel',
      label: 'cPanel Hosting',
      badge: 'Softaculous 400+',
      icon: '⚙️',
      accentColor: 'border-amber-500 text-amber-600',
    },
    {
      id: 'business',
      label: 'Business Webhosting',
      badge: '99.99% SLA',
      icon: '🏢',
      accentColor: 'border-yellow-500 text-yellow-700',
    },
    {
      id: 'bulksms',
      label: 'Bulk SMS Platform',
      badge: 'Instant DLR',
      icon: '📱',
      accentColor: 'border-rose-500 text-rose-600',
    },
  ];

  return (
    <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-2xs py-2.5 px-3 sm:px-6">
      <div className="max-w-[1360px] mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar w-full sm:w-auto py-1">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider mr-2 shrink-0 hidden md:inline">
            ALL PAGES:
          </span>

          {pages.map((p) => {
            const isActive = activeCategory === p.id;

            return (
              <button
                key={p.id}
                onClick={() => onSelectCategory(p.id)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition-all duration-200 shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-sm scale-102 ring-2 ring-slate-800'
                    : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                <span>{p.icon}</span>
                <span>{p.label}</span>
                {p.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded-full font-extrabold uppercase ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {p.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Live Indicator */}
        <div className="items-center gap-2 hidden lg:flex shrink-0">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <span className="text-[11px] font-mono text-slate-500 font-semibold">
            All Cloud Clusters Online
          </span>
        </div>
      </div>
    </div>
  );
};

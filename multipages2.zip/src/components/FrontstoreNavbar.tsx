import React from 'react';
import {
  Server,
  Zap,
  Globe2,
  Layers,
  Settings,
  Briefcase,
  UserCheck,
  Database,
  Cloud,
  ChevronRight,
  Shield,
  Sliders,
} from 'lucide-react';
import { HostingCategory } from '../types/hosting';
import { useConfig } from '../context/ConfigContext';

interface FrontstoreNavbarProps {
  activeCategory: HostingCategory;
  onSelectCategory: (cat: HostingCategory) => void;
  onOpenCustomerPortal: () => void;
  onOpenAdminPanel: () => void;
}

export const FrontstoreNavbar: React.FC<FrontstoreNavbarProps> = ({
  activeCategory,
  onSelectCategory,
  onOpenCustomerPortal,
  onOpenAdminPanel,
}) => {
  const { config } = useConfig();

  const navItems: {
    id: HostingCategory;
    label: string;
    badge?: string;
    icon: React.ReactNode;
    color: string;
  }[] = [
    {
      id: 'cloud',
      label: 'Cloud Hosting',
      icon: <Cloud className="w-4 h-4" />,
      color: 'text-indigo-600',
    },
    {
      id: 'shared',
      label: 'Shared Hosting',
      badge: 'Popular',
      icon: <Zap className="w-4 h-4" />,
      color: 'text-cyan-600',
    },
    {
      id: 'wordpress',
      label: 'WordPress Hosting',
      badge: 'Turbo LiteSpeed',
      icon: <Globe2 className="w-4 h-4" />,
      color: 'text-blue-600',
    },
    {
      id: 'indian',
      label: 'Indian Hosting',
      badge: '<10ms Ping',
      icon: <span className="text-sm">🇮🇳</span>,
      color: 'text-orange-600',
    },
    {
      id: 'reseller',
      label: 'Reseller Hosting',
      badge: '100% White-Label',
      icon: <Layers className="w-4 h-4" />,
      color: 'text-purple-600',
    },
    {
      id: 'cpanel',
      label: 'cPanel Hosting',
      badge: 'Softaculous 400+',
      icon: <Settings className="w-4 h-4" />,
      color: 'text-amber-600',
    },
    {
      id: 'business',
      label: 'Business Webhosting',
      badge: '99.99% SLA',
      icon: <Briefcase className="w-4 h-4" />,
      color: 'text-emerald-700',
    },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-xs">
      {/* Top Frontstore Bar */}
      <div className="max-w-[1440px] mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-3">
        {/* Brand / Logo with live server pulse */}
        <div
          onClick={() => onSelectCategory('cloud')}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#635bff] to-indigo-700 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-base sm:text-lg font-black tracking-tight text-slate-900 group-hover:text-[#635bff] transition-colors">
                CloudHost
              </span>
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-semibold block -mt-1 hidden sm:block">
              Enterprise Cloud &amp; Web Hosting
            </span>
          </div>
        </div>

        {/* Right Action Hub: Customer Panel & Admin / MySQL Sync buttons */}
        <div className="flex items-center gap-2">
          {/* Customer Panel / Client Area Button */}
          <button
            onClick={onOpenCustomerPortal}
            id="nav-customer-portal-btn"
            className="flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-800 text-xs font-bold transition-all active:scale-95 border border-slate-200/80"
            title="Open Customer Client Portal"
          >
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline">Customer Portal</span>
            <span className="sm:hidden">Client</span>
          </button>

          {/* Admin & MySQL Database Sync Button */}
          <button
            onClick={onOpenAdminPanel}
            id="nav-admin-cms-btn"
            className="flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl bg-gradient-to-r from-purple-700 via-indigo-600 to-[#635bff] hover:from-purple-800 hover:to-indigo-700 text-white text-xs font-extrabold shadow-sm active:scale-95 transition-all"
            title="Admin CMS & MySQL Database Sync"
          >
            <Database className="w-4 h-4 text-amber-300" />
            <span className="hidden md:inline">Admin &amp; MySQL Sync</span>
            <span className="md:hidden">Admin/DB</span>
          </button>
        </div>
      </div>

      {/* Hosting Categories Sub-navigation Pill Bar */}
      <div className="bg-slate-50/80 border-t border-slate-200/60 overflow-x-auto no-scrollbar py-1.5 px-3 sm:px-6">
        <div className="max-w-[1440px] mx-auto flex items-center gap-1.5 sm:gap-2 min-w-max">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider mr-1 shrink-0">
            PRODUCTS:
          </span>
          {navItems.map((item) => {
            const isActive = activeCategory === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectCategory(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all duration-200 shrink-0 ${
                  isActive
                    ? 'bg-[#635bff] text-white shadow-sm shadow-indigo-500/20 scale-102'
                    : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200/80'
                }`}
              >
                <span className={isActive ? 'text-white' : item.color}>
                  {item.icon}
                </span>
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold uppercase ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-purple-100 text-purple-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};

import React from 'react';
import { Server, Shield, Lock, Sliders, Heart } from 'lucide-react';
import { useConfig } from '../context/ConfigContext';

export const Footer: React.FC = () => {
  const { setAdminOpen } = useConfig();

  return (
    <footer id="main-footer" className="bg-slate-950 text-slate-400 text-xs border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-12 border-b border-slate-800">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center text-white shadow-md">
                <Server className="w-4 h-4" />
              </div>
              <span className="font-extrabold text-lg text-white">
                Cloud<span className="text-cyan-400">Host</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Empowering businesses, developers, and global agencies with ultra-fast NVMe cloud hosting, automated scaling, and guaranteed 99.9% uptime.
            </p>
            <div className="flex items-center gap-3 text-slate-300">
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>All Systems Operational (99.99%)</span>
              </div>
            </div>
          </div>

          {/* Col 2: Hosting */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-slate-200">Hosting Solutions</h4>
            <ul className="space-y-2">
              <li><a href="#environments" className="hover:text-white transition">Linux Cloud VPS</a></li>
              <li><a href="#environments" className="hover:text-white transition">Windows Server RDP</a></li>
              <li><a href="#environments" className="hover:text-white transition">Managed WordPress</a></li>
              <li><a href="#environments" className="hover:text-white transition">Docker & Microservices</a></li>
              <li><a href="#environments" className="hover:text-white transition">Node.js / Python Hosting</a></li>
            </ul>
          </div>

          {/* Col 3: Infrastructure */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-slate-200">Infrastructure</h4>
            <ul className="space-y-2">
              <li><a href="#locations" className="hover:text-white transition">Global Data Centers</a></li>
              <li><a href="#features" className="hover:text-white transition">NVMe Gen4 Storage</a></li>
              <li><a href="#features" className="hover:text-white transition">3.2 Tbps DDoS Defense</a></li>
              <li><a href="#features" className="hover:text-white transition">Dedicated IPv4 / IPv6</a></li>
              <li><a href="#features" className="hover:text-white transition">Automated Backups</a></li>
            </ul>
          </div>

          {/* Col 4: Platform & CMS */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-slate-200">Management & Tools</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setAdminOpen(true)}
                  className="text-amber-400 hover:text-amber-300 flex items-center gap-1 font-semibold transition"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Admin Panel (SEO & CMS)</span>
                </button>
              </li>
              <li><a href="#pricing" className="hover:text-white transition">Pricing Calculator</a></li>
              <li><a href="#compare" className="hover:text-white transition">Plan Comparison</a></li>
              <li><a href="#faq" className="hover:text-white transition">Help Center & FAQ</a></li>
              <li><span className="text-slate-500">API Documentation (REST)</span></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div className="flex items-center gap-1">
            <span>© {new Date().getFullYear()} CloudHost Global Inc. Built with</span>
            <Heart className="w-3 h-3 text-red-500 fill-current inline" />
            <span>for Developers worldwide.</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>SOC2 Type II Certified</span>
            </span>
            <span className="flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-blue-400" />
              <span>256-bit SSL Encrypted</span>
            </span>
            <button
              onClick={() => setAdminOpen(true)}
              className="text-slate-400 hover:text-amber-400 underline transition"
            >
              Configure SEO & Content
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

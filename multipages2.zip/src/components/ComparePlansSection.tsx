import React from 'react';
import { Check, X } from 'lucide-react';
import { useConfig } from '../context/ConfigContext';

export const ComparePlansSection: React.FC = () => {
  const { config, openDeployModalWithPlan } = useConfig();
  const { compareRows, pricingPlans } = config;

  const renderCell = (val: string | boolean) => {
    if (typeof val === 'boolean') {
      return val ? (
        <Check className="w-4 h-4 text-emerald-500 stroke-[3] mx-auto" />
      ) : (
        <X className="w-4 h-4 text-rose-500 stroke-[3] mx-auto" />
      );
    }
    return <span className="font-semibold text-slate-800 text-xs">{val}</span>;
  };

  return (
    <div
      id="compare-card"
      className="rounded-3xl bg-white border border-slate-200/80 p-6 sm:p-7 shadow-sm h-full flex flex-col justify-between"
    >
      {/* Header */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-1">
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Compare Plans
          </h2>
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#f3f0ff] text-[#635bff]">
            DETAILED COMPARISON
          </span>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          Find the perfect plan for your requirements.
        </p>
      </div>

      {/* Comparison Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-100 my-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-[#f0f4fd] text-slate-800 font-bold border-b border-slate-200/60">
              <th className="py-2.5 px-3 text-xs w-1/3">Features</th>
              <th className="py-2.5 px-2 text-center text-xs">Basic</th>
              <th className="py-2.5 px-2 text-center text-xs">Pro</th>
              <th className="py-2.5 px-2 text-center text-xs text-[#635bff] bg-purple-50/70">
                Business
              </th>
              <th className="py-2.5 px-2 text-center text-xs">Enterprise</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {compareRows.map((row, idx) => (
              <tr
                key={idx}
                className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'}
              >
                <td className="py-2 px-3 text-[11px] font-medium text-slate-700">
                  {row.name}
                </td>
                <td className="py-2 px-2 text-center text-[11px]">
                  {renderCell(row.basic)}
                </td>
                <td className="py-2 px-2 text-center text-[11px]">
                  {renderCell(row.pro)}
                </td>
                <td className="py-2 px-2 text-center text-[11px] bg-purple-50/30">
                  {renderCell(row.business)}
                </td>
                <td className="py-2 px-2 text-center text-[11px]">
                  {renderCell(row.enterprise)}
                </td>
              </tr>
            ))}

            {/* Price Row */}
            <tr className="bg-slate-50/80 font-bold">
              <td className="py-2 px-3 text-slate-900 text-xs">Price (Monthly)</td>
              <td className="py-2 px-2 text-center text-slate-900 text-xs">₹69</td>
              <td className="py-2 px-2 text-center text-slate-900 text-xs">₹99</td>
              <td className="py-2 px-2 text-center text-[#635bff] text-xs bg-purple-50/50">
                ₹169
              </td>
              <td className="py-2 px-2 text-center text-slate-900 text-xs">₹399</td>
            </tr>

            {/* Choose Plan Buttons Row */}
            <tr className="bg-white">
              <td className="py-3 px-3 font-bold text-slate-900 text-xs">
                Choose Plan
              </td>
              <td className="py-3 px-1 text-center">
                <button
                  onClick={() => openDeployModalWithPlan(pricingPlans[0])}
                  className="px-2.5 py-1.5 rounded-lg bg-[#f0eeff] text-[#635bff] hover:bg-[#e4e0ff] text-[10px] font-bold transition whitespace-nowrap"
                >
                  Buy Now
                </button>
              </td>
              <td className="py-3 px-1 text-center">
                <button
                  onClick={() => openDeployModalWithPlan(pricingPlans[1])}
                  className="px-2.5 py-1.5 rounded-lg bg-[#f0eeff] text-[#635bff] hover:bg-[#e4e0ff] text-[10px] font-bold transition whitespace-nowrap"
                >
                  Buy Now
                </button>
              </td>
              <td className="py-3 px-1 text-center bg-purple-50/40">
                <button
                  onClick={() => openDeployModalWithPlan(pricingPlans[2])}
                  className="px-2.5 py-1.5 rounded-lg bg-[#635bff] text-white hover:bg-[#5249e0] text-[10px] font-bold shadow-sm transition whitespace-nowrap"
                >
                  Buy Now
                </button>
              </td>
              <td className="py-3 px-1 text-center">
                <button
                  onClick={() => openDeployModalWithPlan(pricingPlans[3])}
                  className="px-2.5 py-1.5 rounded-lg bg-[#f0eeff] text-[#635bff] hover:bg-[#e4e0ff] text-[10px] font-bold transition whitespace-nowrap"
                >
                  Buy Now
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

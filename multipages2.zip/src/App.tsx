/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ConfigProvider, useConfig } from './context/ConfigContext';
import { allCategoryPlans } from './data/hostingPagesData';

// Bulk SMS Components
import { BulkSmsHero } from './components/bulksms/BulkSmsHero';
import { ServiceCards } from './components/bulksms/ServiceCards';
import { WhyChooseSms } from './components/bulksms/WhyChooseSms';
import { StatsBar } from './components/bulksms/StatsBar';
import { BulkSmsPricing, PlanOrderInfo } from './components/bulksms/BulkSmsPricing';
import { ResellerPanelSection } from './components/bulksms/ResellerPanelSection';
import { ApiIntegrationSection } from './components/bulksms/ApiIntegrationSection';
import { TrustedBrandsSection } from './components/bulksms/TrustedBrandsSection';
import { ValueFeaturesSection } from './components/bulksms/ValueFeaturesSection';
import { FaqSection } from './components/bulksms/FaqSection';

// Hosting Pages Suite
import { SharedHostingPage } from './components/pages/SharedHostingPage';
import { WordPressHostingPage } from './components/pages/WordPressHostingPage';
import { CPanelHostingPage } from './components/pages/CPanelHostingPage';
import { BusinessHostingPage } from './components/pages/BusinessHostingPage';
import { IndianHostingPage } from './components/pages/IndianHostingPage';
import { ResellerHostingPage } from './components/pages/ResellerHostingPage';
import { ModernHostingPage } from './components/pages/ModernHostingPage';
import { BusinessEmailPage } from './components/pages/BusinessEmailPage';
import { PricingSection } from './components/PricingSection';
import { EnvironmentsSection } from './components/EnvironmentsSection';
import { ComparePlansSection } from './components/ComparePlansSection';

// Interactive Modals & Drawers
import { TestSmsSandboxModal } from './components/bulksms/TestSmsSandboxModal';
import { OrderSmsModal } from './components/bulksms/OrderSmsModal';
import { ScheduleMeetingModal } from './components/bulksms/ScheduleMeetingModal';
import { CartSyncDrawer, CartItem } from './components/bulksms/CartSyncDrawer';
import { SmsPanelDashboard } from './components/bulksms/SmsPanelDashboard';
import { ChangesAuditModal } from './components/common/ChangesAuditModal';
import { DeployServerModal } from './components/DeployServerModal';
import { CustomerPortalModal } from './components/CustomerPortalModal';
import { AdminPanelModal } from './components/AdminPanelModal';

import {
  CheckCircle2,
  MessageSquare,
  ShieldCheck,
  Zap,
  ShoppingCart,
  Database,
  Crown,
  LayoutDashboard,
  Maximize2,
  X,
  Server,
  Globe2,
  ChevronDown,
  ArrowLeft,
  FileCode,
  Sparkles,
  Mail,
} from 'lucide-react';

function AppContent() {
  const [currentPage, setCurrentPage] = useState<
    'bulksms' | 'shared' | 'wordpress' | 'cpanel' | 'business' | 'indian' | 'reseller' | 'cloud' | 'businessemail'
  >('businessemail');

  const [viewMode, setViewMode] = useState<'modern' | 'classic'>('modern');
  const [sandboxOpen, setSandboxOpen] = useState(false);
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [orderOpen, setOrderOpen] = useState(false);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [fullScreenPanelOpen, setFullScreenPanelOpen] = useState(false);
  const [auditModalOpen, setAuditModalOpen] = useState(false);
  const [hostingDropdownOpen, setHostingDropdownOpen] = useState(false);

  // Dynamic Cart Items state (synced with localStorage & panels)
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      cartId: 'default_100k',
      name: 'COMMON PLAN - 1,00,000 SMS',
      quantity: '1,00,000 SMS',
      price: '₹15,000',
      rawPrice: 15000,
      regularPrice: '₹25,000',
      discount: '40% OFF',
      rate: '₹0.150 / SMS',
      hasEnterprisePerks: true,
      addedAt: '10:45 AM',
    },
  ]);

  const [selectedPlan, setSelectedPlan] = useState<PlanOrderInfo | null>({
    name: 'COMMON PLAN - 1,00,000 SMS',
    quantity: '1,00,000 SMS',
    price: '₹15,000',
    rawPrice: 15000,
    regularPrice: '₹25,000',
    discount: '40% OFF',
    rate: '₹0.150 / SMS',
    hasEnterprisePerks: true,
  });

  const [sandboxServiceType, setSandboxServiceType] = useState('OTP SMS');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 4000);
  };

  const handleSelectService = (serviceName: string) => {
    setSandboxServiceType(serviceName);
    setSandboxOpen(true);
  };

  // Buy Hosting Plan (from Node.js or other hosting grids)
  const handleBuyHostingPlan = (planName: string, price: string) => {
    const rawP = parseInt(price.replace(/\D/g, ''), 10) || 199;
    const newItem: CartItem = {
      cartId: `hosting_${Date.now()}`,
      name: `${planName} - Developer NVMe Server`,
      quantity: '1 Instance',
      price: price,
      rawPrice: rawP,
      regularPrice: `₹${rawP * 2}`,
      discount: '50% OFF',
      rate: `${price} (Billed Annually)`,
      hasEnterprisePerks: true,
      addedAt: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    };
    setCartItems((prev) => [newItem, ...prev]);
    setCartDrawerOpen(true);
    showToast(`✓ ${planName} added to Cart! Synced with provisioning system.`);
  };

  // When clicking Buy Now, add to Dynamic Cart and open drawer with MySQL sync
  const handleBuyPlan = (plan: PlanOrderInfo) => {
    const is1LacPlus = plan.hasEnterprisePerks || parseInt(plan.quantity.replace(/\D/g, ''), 10) >= 100000;
    const newItem: CartItem = {
      ...plan,
      cartId: `cart_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      hasEnterprisePerks: is1LacPlus,
      addedAt: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    };

    setCartItems((prev) => [newItem, ...prev.filter((i) => i.quantity !== plan.quantity)]);
    setSelectedPlan(plan);
    setCartDrawerOpen(true);
    showToast(`✓ ${plan.quantity} added to Cart! Synced with MySQL & Admin Panel.`);
  };

  const handleRemoveCartItem = (cartId: string) => {
    setCartItems((prev) => prev.filter((it) => it.cartId !== cartId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const hostingPageOptions = [
    { id: 'businessemail', name: 'Business Email Hosting', icon: '✉️', badge: '10-Yr Save 25%' },
    { id: 'wordpress', name: 'WordPress Hosting', icon: '🌐', badge: 'Turbo LiteSpeed' },
    { id: 'cpanel', name: 'cPanel NVMe Hosting', icon: '⚙️', badge: 'Softaculous 400+' },
    { id: 'shared', name: 'Shared Web Hosting', icon: '⚡', badge: 'cPanel NVMe' },
    { id: 'business', name: 'Business Enterprise Hosting', icon: '💼', badge: '99.99% SLA' },
    { id: 'indian', name: 'Indian Hosting (Mumbai DC)', icon: '🇮🇳', badge: '<10ms Ping' },
    { id: 'reseller', name: 'Reseller Web Hosting', icon: '👥', badge: '100% White-Label' },
    { id: 'cloud', name: 'Cloud Infrastructure & VPS', icon: '☁️', badge: 'Dedicated NVMe' },
    { id: 'bulksms', name: 'Bulk SMS Platform', icon: '📱', badge: 'Live Gateway' },
  ];

  return (
    <div className="min-h-screen bg-white text-slate-900 selection:bg-[#e11d48] selection:text-white font-sans antialiased overflow-x-hidden">
      {/* Dynamic Sync Sticky Bar at Top */}
      <div className="bg-slate-900 text-white text-[11px] py-2 px-4 border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-[1360px] mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
            <span className="flex h-2 w-2 relative shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </span>
            <span className="font-mono text-emerald-400 font-bold shrink-0">
              Live Gateway: AIRTEL &amp; JIO SS7
            </span>
            <span className="text-slate-400 hidden md:inline">•</span>
            <span className="text-slate-300 hidden md:inline">
              1 Lac+ Plans: Whitelabel Reseller, Custom Sender ID (GITYSFT), Free DLT Support &amp; API
            </span>
          </div>

          {/* Quick Triggers: All Hosting Pages List, Changes Audit, Live Panel, Cart */}
          <div className="flex items-center gap-2 relative">
            {/* Hosting Pages List Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setHostingDropdownOpen(!hostingDropdownOpen)}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs border border-slate-700 transition-all cursor-pointer"
              >
                <Server className="w-3.5 h-3.5 text-cyan-400" />
                <span>Hosting Pages ({hostingPageOptions.length})</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {hostingDropdownOpen && (
                <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 text-slate-800 animate-fade-in">
                  <div className="px-3.5 py-1.5 border-b border-slate-100 flex items-center justify-between">
                    <span className="font-extrabold text-[11px] text-slate-500 uppercase tracking-wider">
                      All Hosting &amp; SMS Pages
                    </span>
                    <span className="text-[10px] font-mono text-emerald-600 font-bold">8 Pages Ready</span>
                  </div>
                  <div className="max-h-80 overflow-y-auto py-1">
                    {hostingPageOptions.map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => {
                          setCurrentPage(opt.id as any);
                          setHostingDropdownOpen(false);
                          showToast(`✓ Switched view to: ${opt.name}`);
                        }}
                        className={`w-full px-3.5 py-2 text-left text-xs flex items-center justify-between hover:bg-slate-50 cursor-pointer transition-colors ${
                          currentPage === opt.id ? 'bg-rose-50 text-[#e11d48] font-black' : 'text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-sm">{opt.icon}</span>
                          <span className="font-bold">{opt.name}</span>
                        </div>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 font-mono text-slate-600">
                          {opt.badge}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Business Email Direct Button */}
            <button
              type="button"
              onClick={() => {
                setCurrentPage('businessemail');
                showToast('✓ Switched to Business Email Suite');
              }}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all shrink-0 cursor-pointer border ${
                currentPage === 'businessemail'
                  ? 'bg-[#3B3B6D] text-white border-amber-400 shadow-md ring-2 ring-amber-400/40'
                  : 'bg-slate-800 hover:bg-[#3B3B6D] text-slate-200 hover:text-white border-slate-700'
              }`}
            >
              <Mail className="w-3.5 h-3.5 text-amber-400" />
              <span>Business Email</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-400 text-slate-950 font-black">NEW</span>
            </button>

            {/* Changes Audit Button */}
            <button
              onClick={() => setAuditModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all shrink-0 cursor-pointer"
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Changes Audit</span>
            </button>

            {/* Live SMS Panel */}
            <button
              onClick={() => setFullScreenPanelOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0284c7] hover:bg-[#0369a1] text-white font-bold text-xs shadow-xs active:scale-95 transition-all shrink-0 cursor-pointer"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>SMS Panel</span>
            </button>

            {/* Cart Trigger */}
            <button
              onClick={() => setCartDrawerOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#e11d48] hover:bg-[#be123c] text-white font-bold text-xs shadow-xs active:scale-95 transition-all shrink-0 cursor-pointer"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span>Cart ({cartItems.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* VIEW MODE 1: BULK SMS PLATFORM (MAIN ACTIVE VIEW) */}
      {currentPage === 'bulksms' && (
        <main>
          {/* 1. HERO SECTION (High-Impact with animated live phone preview & flying plane) */}
          <BulkSmsHero
            onOpenOrder={(planName) => {
              handleBuyPlan({
                name: planName || 'COMMON PLAN - 1,00,000 SMS',
                quantity: '1,00,000 SMS',
                price: '₹15,000',
                rawPrice: 15000,
                regularPrice: '₹25,000',
                discount: '40% OFF',
                rate: '₹0.150 / SMS',
                hasEnterprisePerks: true,
              });
            }}
            onOpenSchedule={() => setScheduleOpen(true)}
            onOpenSandbox={() => {
              setSandboxServiceType('OTP SMS');
              setSandboxOpen(true);
            }}
          />

          {/* 2. 5 SERVICE CARDS (With 3D hover lift & route selection) */}
          <ServiceCards onSelectService={handleSelectService} />

          {/* 3. WHY CHOOSE OUR BULK SMS PLATFORM? */}
          <WhyChooseSms
            onGetStarted={() => {
              handleBuyPlan({
                name: 'COMMON PLAN - 1,00,000 SMS',
                quantity: '1,00,000 SMS',
                price: '₹15,000',
                rawPrice: 15000,
                regularPrice: '₹25,000',
                discount: '40% OFF',
                rate: '₹0.150 / SMS',
                hasEnterprisePerks: true,
              });
            }}
          />

          {/* 4. KEY METRICS STATS BAR (Dark glowing bento bar) */}
          <StatsBar />

          {/* 5. BULK SMS PLANS & PRICING GRID */}
          <BulkSmsPricing
            onBuyPlan={handleBuyPlan}
            cartCount={cartItems.length}
            onOpenCart={() => setCartDrawerOpen(true)}
          />

          {/* 6. DYNAMIC SMS PANEL & RESELLER SECTION (Functional dashboard matching screenshot) */}
          <ResellerPanelSection
            onBecomeReseller={() => {
              handleBuyPlan({
                name: 'WHITE LABEL RESELLER - 2,00,000 SMS',
                quantity: '2,00,000 SMS',
                price: '₹28,000',
                rawPrice: 28000,
                regularPrice: '₹45,000',
                discount: '38% OFF',
                rate: '₹0.140 / SMS',
                hasEnterprisePerks: true,
              });
            }}
            onOpenFullScreenPanel={() => setFullScreenPanelOpen(true)}
          />

          {/* 7. POWERFUL API INTEGRATION FOR DEVELOPERS */}
          <ApiIntegrationSection
            onOpenSandbox={() => {
              setSandboxServiceType('Transactional SMS');
              setSandboxOpen(true);
            }}
            onViewDocs={() => {
              showToast('✓ Opening API Documentation (REST & SMPP)...');
            }}
          />

          {/* 8. TRUSTED BY 5000+ BUSINESSES ACROSS INDIA */}
          <TrustedBrandsSection />

          {/* 9. 4 ENTERPRISE VALUE PROPOSITION CARDS */}
          <ValueFeaturesSection />

          {/* 10. FREQUENTLY ASKED QUESTIONS */}
          <FaqSection />
        </main>
      )}

      {/* VIEW MODE 2: SPECIFIC HOSTING PAGES */}
      {currentPage !== 'bulksms' && (
        <main className="min-h-screen bg-slate-50">
          {/* Top Bar Switcher to Return to Bulk SMS */}
          <div className="bg-slate-900 text-white px-4 sm:px-6 py-3.5 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setCurrentPage('bulksms')}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-[#e11d48] text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Bulk SMS Platform</span>
              </button>
              <div className="hidden sm:flex items-center gap-2 text-xs text-slate-300">
                <span>Currently Viewing:</span>
                <span className="font-bold text-cyan-400 capitalize">
                  {hostingPageOptions.find((p) => p.id === currentPage)?.name}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* View Mode Toggle: Modern Screenshot Look vs Classic Spec */}
              <div className="flex items-center bg-slate-800 rounded-xl p-1 text-xs font-bold border border-slate-700">
                <button
                  type="button"
                  onClick={() => setViewMode('modern')}
                  className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                    viewMode === 'modern' ? 'bg-emerald-500 text-white font-black shadow-xs' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  ★ Modern Developer Look
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('classic')}
                  className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                    viewMode === 'classic' ? 'bg-slate-700 text-white font-bold shadow-xs' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Classic View
                </button>
              </div>

              <button
                onClick={() => setAuditModalOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>Audit</span>
              </button>
            </div>
          </div>

          {/* Quick Stack Switcher Bar */}
          <div className="bg-slate-900/90 backdrop-blur-md px-4 sm:px-6 py-2 border-b border-slate-800 flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs font-bold">
            <span className="text-slate-400 text-[11px] uppercase tracking-wider shrink-0 mr-1">Select Stack:</span>
            {[
              { id: 'businessemail', label: '✉️ Business Email', badge: '10-Yr Save 25%' },
              { id: 'wordpress', label: '🌐 WordPress Hosting', badge: 'LiteSpeed' },
              { id: 'cpanel', label: '⚙️ cPanel NVMe', badge: 'Softaculous' },
              { id: 'shared', label: '⚡ Shared Hosting', badge: 'CloudLinux' },
              { id: 'business', label: '💼 Business Enterprise', badge: '99.99%' },
              { id: 'indian', label: '🇮🇳 Indian Hosting', badge: 'Mumbai DC' },
              { id: 'reseller', label: '👥 Reseller WHM', badge: 'Whitelabel' },
              { id: 'cloud', label: '☁️ Cloud VPS', badge: 'Dedicated' },
            ].map((st) => (
              <button
                key={st.id}
                type="button"
                onClick={() => {
                  setCurrentPage(st.id as any);
                  showToast(`✓ Switched to ${st.label}`);
                }}
                className={`px-3 py-1.5 rounded-xl shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
                  currentPage === st.id
                    ? 'bg-emerald-500 text-white font-black shadow-md shadow-emerald-500/20'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white'
                }`}
              >
                <span>{st.label}</span>
                <span className={`text-[9px] px-1.5 py-0.2 rounded-full ${
                  currentPage === st.id ? 'bg-emerald-700 text-emerald-100' : 'bg-slate-900 text-slate-400'
                }`}>
                  {st.badge}
                </span>
              </button>
            ))}
          </div>

          {/* Render Active Hosting Page: Business Email vs WordPress vs Modern Screenshot vs Classic Spec */}
          {currentPage === 'businessemail' ? (
            <div className="max-w-[1360px] mx-auto px-4 sm:px-6 py-8">
              <BusinessEmailPage
                onAddToCart={(item) => {
                  const newItem: CartItem = {
                    cartId: `email_${Date.now()}`,
                    name: item.name,
                    quantity: item.quantity,
                    price: item.price,
                    rawPrice: item.rawPrice,
                    regularPrice: item.regularPrice,
                    discount: item.discount,
                    rate: item.rate,
                    hasEnterprisePerks: item.hasEnterprisePerks,
                    addedAt: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
                  };
                  setCartItems((prev) => [newItem, ...prev]);
                  setCartDrawerOpen(true);
                  showToast(`✓ ${item.name} added to Cart!`);
                }}
              />
            </div>
          ) : currentPage === 'wordpress' ? (
            <div className="max-w-[1360px] mx-auto px-4 sm:px-6 py-8">
              <WordPressHostingPage
                plans={allCategoryPlans.wordpress}
                onOpenDeployModal={(plan) => {
                  handleBuyHostingPlan(
                    plan?.name || 'Turbo WordPress NVMe',
                    plan?.priceINR ? `₹${plan.priceINR}/mo` : '₹79/mo'
                  );
                }}
              />
            </div>
          ) : viewMode === 'modern' ? (
            <ModernHostingPage
              stack={currentPage === 'cpanel' ? 'cpanel' : 'shared'}
              onDeployPlan={handleBuyHostingPlan}
              onOpenLiveChat={() => showToast('Opening 24/7 Live DevOps Chat Support...')}
              onOpenMigrationModal={() => showToast('Free Migration request received! Senior DevOps will contact you.')}
            />
          ) : (
            /* Classic Spec View */
            <div>
              {currentPage === 'shared' && (
                <SharedHostingPage
                  plans={allCategoryPlans.shared}
                  onOpenDeployModal={() => showToast('Configured Shared Hosting plan deployment!')}
                />
              )}
              {currentPage === 'cpanel' && (
                <CPanelHostingPage
                  plans={allCategoryPlans.cpanel}
                  onOpenDeployModal={() => showToast('Configured cPanel Hosting plan deployment!')}
                />
              )}
              {currentPage === 'business' && (
                <BusinessHostingPage
                  plans={allCategoryPlans.business}
                  onOpenDeployModal={() => showToast('Configured Business Hosting plan deployment!')}
                />
              )}
              {currentPage === 'indian' && (
                <IndianHostingPage
                  plans={allCategoryPlans.indian}
                  onOpenDeployModal={() => showToast('Configured Mumbai Datacenter Hosting plan deployment!')}
                />
              )}
              {currentPage === 'reseller' && (
                <ResellerHostingPage
                  plans={allCategoryPlans.reseller}
                  onOpenDeployModal={() => showToast('Configured Reseller WHM plan deployment!')}
                />
              )}
              {currentPage === 'cloud' && (
                <div className="max-w-7xl mx-auto px-4 py-8 space-y-10">
                  <PricingSection />
                  <EnvironmentsSection />
                  <ComparePlansSection />
                </div>
              )}
            </div>
          )}
        </main>
      )}

      {/* Floating Action Trigger: Live SMS Sandbox, SMS Panel, Audit Log & Cart Switcher */}
      <div className="fixed bottom-6 right-6 z-40 flex items-center gap-2">
        <button
          onClick={() => setAuditModalOpen(true)}
          className="group flex items-center gap-1.5 px-3.5 py-3 rounded-full bg-purple-700 hover:bg-purple-600 text-white font-extrabold text-xs shadow-2xl active:scale-95 transition-all cursor-pointer border border-purple-400"
          title="Changes Audit & Hosting Pages List"
        >
          <FileCode className="w-4 h-4 text-white group-hover:rotate-12 transition-transform" />
          <span>Audit Log</span>
        </button>

        <button
          onClick={() => setFullScreenPanelOpen(true)}
          className="group flex items-center gap-1.5 px-4 py-3 rounded-full bg-[#0284c7] hover:bg-[#0369a1] text-white font-extrabold text-xs shadow-2xl active:scale-95 transition-all cursor-pointer border border-sky-400"
          title="Open Full Functional SMS Panel Dashboard"
        >
          <LayoutDashboard className="w-4 h-4 text-white group-hover:scale-110 transition-transform" />
          <span>SMS Panel</span>
        </button>

        <button
          onClick={() => setCartDrawerOpen(true)}
          className="group flex items-center gap-1.5 px-3.5 py-3 rounded-full bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs shadow-2xl active:scale-95 transition-all cursor-pointer border border-slate-700"
          title="Open Cart & Synced Orders"
        >
          <ShoppingCart className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform" />
          <span>Cart ({cartItems.length})</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        </button>

        <button
          onClick={() => {
            setSandboxServiceType('OTP SMS');
            setSandboxOpen(true);
          }}
          className="group flex items-center gap-1.5 px-4 py-3 rounded-full bg-[#e11d48] hover:bg-[#be123c] text-white font-extrabold text-xs shadow-2xl shadow-rose-500/35 active:scale-95 transition-all cursor-pointer"
          title="Open Live SMS Sandbox Tester"
        >
          <MessageSquare className="w-4 h-4 group-hover:scale-110 transition-transform" />
          <span>Sandbox</span>
        </button>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div
          id="global-toast-notification"
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-slate-900/95 text-white text-xs font-semibold shadow-2xl border border-slate-700 animate-bounce"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* FULL-SCREEN DYNAMIC SMS PANEL MODAL (MATCHING SCREENSHOT) */}
      {fullScreenPanelOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex flex-col p-2 sm:p-4 animate-fade-in">
          <div className="w-full h-full max-w-7xl mx-auto bg-white rounded-2xl overflow-hidden shadow-2xl border border-slate-800 flex flex-col">
            <SmsPanelDashboard
              isModal={true}
              onClose={() => setFullScreenPanelOpen(false)}
            />
          </div>
        </div>
      )}

      {/* CHANGES AUDIT & HOSTING PAGES LIST MODAL */}
      <ChangesAuditModal
        isOpen={auditModalOpen}
        onClose={() => setAuditModalOpen(false)}
        onNavigateToPage={(pageId) => {
          setCurrentPage(pageId as any);
          showToast(`✓ Opened ${pageId} hosting page.`);
        }}
      />

      {/* Dynamic Cart & MySQL/Panel Sync Drawer */}
      <CartSyncDrawer
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        cartItems={cartItems}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        onSuccessOrder={(msg) => showToast(msg)}
      />

      {/* Interactive Modals */}
      <OrderSmsModal
        isOpen={orderOpen}
        onClose={() => setOrderOpen(false)}
        planDetails={selectedPlan}
        onSuccess={(msg) => showToast(msg)}
      />

      <TestSmsSandboxModal
        isOpen={sandboxOpen}
        onClose={() => setSandboxOpen(false)}
        initialType={sandboxServiceType}
      />

      <ScheduleMeetingModal
        isOpen={scheduleOpen}
        onClose={() => setScheduleOpen(false)}
        onSuccess={(msg) => showToast(msg)}
      />
    </div>
  );
}

export default function App() {
  return (
    <ConfigProvider>
      <AppContent />
    </ConfigProvider>
  );
}
